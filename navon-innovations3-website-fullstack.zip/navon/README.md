# Navon Innovations — corporate website

A production-ready website for **Navon Innovations** with:

- **Light, premium design** with separate **Services** (10 pages) and **Products** (3 pages) sections, 4 solution pages, AI experiences, about, industries, case studies, contact, book a demo and the legal pages, using the same URLs as navoninnovations.com
- **Contact form** (contact page and footer of every page) and **Book a Demo** (dedicated page and popup), both saved to a database, with email notifications and spam protection
- **WhatsApp**: floating button on every page plus service-specific enquiry buttons using the official `wa.me` click-to-chat links
- **Admin dashboard**: enquiries, demo requests with statuses (New, Contacted, Scheduled, Completed, Cancelled), CSV export, blog CMS, settings
- **Blog**: listing, posts, categories, tags, search, related articles, Markdown editor with image upload and compression
- **Immersive 3D and motion design**: interactive Three.js hero, ten animated service visuals with 3D tilt, a scroll-driven attendee journey, an interactive platform globe, floating live dashboards, section transitions and a first-visit loading animation. Lighter on mobile, paused off-screen, and fully static when the visitor has reduced motion turned on
- **Technical SEO**: per-page titles and descriptions, canonical URLs, automatic XML sitemap, robots.txt, Open Graph and X cards, Organization, WebSite, Service, BlogPosting and BreadcrumbList structured data, breadcrumbs, custom 404

All company information comes from navoninnovations.com and the Navon Innovations company profile. See `src/content/site.js` (company facts), `src/content/catalog.js` (service, product and solution pages) and `src/content/legal.js` (policies).

---

## Requirements

- **Node.js 22.13 or newer** (uses Node's built-in SQLite; no database server needed)
- An SMTP account for email notifications (Google Workspace, Zoho, Amazon SES, SendGrid, Brevo, etc.)
- A server or platform that keeps files between restarts (for the SQLite database and uploaded images)

## Quick start (local)

```bash
npm install
cp .env.example .env        # then edit .env
npm start                   # http://localhost:3000
```

Sign in at **/admin/login** with the `ADMIN_EMAIL` / `ADMIN_PASSWORD` from `.env`. To create or reset an admin later:

```bash
npm run create-admin -- you@navoninnovations.com "a-long-password-here" "Your Name"
```

Run the test suite (uses a temporary database and a local test mail server):

```bash
npm test
```

## Configuration you must provide

| What | Where | Why |
|---|---|---|
| `SITE_URL` | `.env` | Canonical URLs, sitemap and structured data. Must be the live `https://` address. |
| `APP_SECRET` | `.env` | Signs anti-spam form tokens. Use a long random value. |
| `ADMIN_EMAIL`, `ADMIN_PASSWORD` | `.env` | First admin account. Remove the password after first sign-in. |
| `SMTP_HOST`, `SMTP_PORT`, `SMTP_SECURE`, `SMTP_USER`, `SMTP_PASS`, `MAIL_FROM` | `.env` | Email notifications. **Without these, no emails are sent**; submissions are still saved and the admin shows "not configured". |
| Notification email | Admin → Settings | Where enquiry and demo notifications go (default `sales@navoninnovations.com`). |
| WhatsApp number | Admin → Settings | Default `919899445735`, the WhatsApp number on navoninnovations.com. **Confirm this number is active on WhatsApp.** |
| Google Search Console code, GA4 ID | Admin → Settings (or `.env`) | Verification and analytics. See `docs/SEO-AND-LAUNCH.md`. |
| Turnstile keys (optional) | `.env` | Adds a Cloudflare CAPTCHA on top of the built-in spam checks. |

After setting SMTP, use **Admin → Settings → Send test email** to confirm delivery. Every enquiry and demo request records its email result (`sent`, `failed` with the error, or `not configured`), so nothing is silently lost.

**Email deliverability:** set up SPF, DKIM and DMARC records for the sending domain with your email provider, or notifications may land in spam.

## Deployment

### Option A: VPS (recommended), e.g. DigitalOcean, AWS Lightsail, Hostinger VPS

```bash
# On the server (Ubuntu), with Node 22 installed
git clone <your-repo> navon && cd navon
npm ci --omit=dev
cp .env.example .env && nano .env
npm install -g pm2
pm2 start server.js --name navon --node-args="--disable-warning=ExperimentalWarning"
pm2 save && pm2 startup
```

Nginx in front (with HTTPS from Let's Encrypt / Certbot):

```nginx
server {
  server_name navoninnovations.com www.navoninnovations.com;
  client_max_body_size 10m;
  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
  }
}
```

Redirect `www` to the bare domain (or the other way round) so there is one canonical host, and make sure `SITE_URL` matches it.

### Option B: Render, Railway or Fly.io

Use a Node web service with `npm ci --omit=dev` as the build command and `npm start` as the start command. **Attach a persistent disk** and point `DB_FILE` and `UPLOAD_DIR` at it (for example `/data/navon.db` and `/data/uploads`); otherwise data is lost on each deploy.

Shared hosting without Node.js support, and serverless platforms without a persistent disk, are not suitable.

### Backups

Everything lives in two places: the database file (`data/navon.db` or `DB_FILE`) and the uploads folder. Back up both daily, for example:

```bash
sqlite3 data/navon.db ".backup '/backups/navon-$(date +%F).db'"
```

## Project structure

```
server.js                 Starts the app
src/
  app.js                  Express setup, security headers, rendering helpers
  config.js               Environment configuration
  db.js                   SQLite schema and migrations
  forms.js                Contact/demo validation, storage, notifications
  mailer.js               SMTP email
  security.js             Passwords, sessions, CSRF, spam protection
  seo.js                  Metadata and structured data
  blog.js                 Blog queries and Markdown rendering
  seed.js                 Starter categories and articles (first run only)
  content/site.js         Company facts (single source of truth)
  content/catalog.js      Service, product and solution pages, AI experiences, industries
  content/legal.js        Privacy, cashless, refund, terms and GDPR pages
  routes/                 public, forms, blog, admin, seo (sitemap/robots)
views/                    EJS templates (pages, partials, admin)
public/                   CSS, JS, images, uploads
tests/site.test.js        End-to-end tests
docs/SEO-AND-LAUNCH.md    Search Console, Analytics, SEO launch checklist
```

## Quick start

- **Test on your computer:** install Node.js 22.13+, run `npm install`, copy `.env.example` to `.env`, set `ADMIN_EMAIL` and `ADMIN_PASSWORD`, then run `npm run local` and open http://localhost:3000 (admin at /admin).
- **Go live (Hostinger VPS or Node.js app):** see `docs/RUN-LOCALLY-AND-HOSTINGER.md` for step-by-step instructions.

## 3D and animation layer

- `client/fx/` holds the source: `hero3d.js` (Three.js hero scene), `network.js` (platform globe), `motion-fx.js` (scroll and UI motion built on [Motion](https://motion.dev), the framework-free build of Framer Motion) and `index.js`.
- The browser loads the bundled, minified output in `public/js/fx/`. **After changing anything in `client/fx/`, run `npm run build:fx`.** The built files are committed, so the server itself needs no build step.
- The Three.js scene is loaded only on the home page and only after the page content, so it never delays the first paint. If WebGL is unavailable the hero falls back to a static product image.
- Styles for this layer are in `public/css/fx.css`. Service visuals are CSS/SVG (`views/partials/svc-visual.ejs`) and only animate while on screen.
- The live dashboard on the home page uses sample data and is labelled as such. Connect it to real event data before presenting figures as actual results.

## SEO articles and AI visibility

- Keyword-focused guides live in `src/content/articles.js`. New articles are added to the blog automatically when the server starts; existing posts are never overwritten, so edits made in Admin → Blog are kept. Run `npm run articles:update` to replace posts with the versions in the code.
- `/llms.txt` gives AI assistants a plain-language summary of Navon. `robots.txt` explicitly allows search and AI crawlers.
- See `docs/SEO-AI-VISIBILITY-PLAN.md` for the off-site steps (Search Console, Google Business Profile, reviews, directories, social media) that decide rankings and AI recommendations.

## Editing content

- **Blog posts**: Admin → Blog posts. Three starter articles are included; review and edit them before launch.
- **Service, product and solution pages**: edit `src/content/catalog.js`. Each page has its title, meta description, H1, sections and related links. Bump `CONTENT_UPDATED` when you change copy so the sitemap shows the new date.
- **Company facts, team, clients, projects and FAQs**: `src/content/site.js`.
- **Legal pages**: `src/content/legal.js`. The GDPR page on the live site is a placeholder, so it is kept out of search (noindex) until real text is added.

## Security notes

- Admin passwords are hashed with scrypt; sessions are server-side, HttpOnly and expire after 12 hours.
- All admin actions require a CSRF token; sign-in is rate-limited.
- Public forms use a honeypot field, a signed timing token, per-IP rate limits and optional Turnstile.
- Blog Markdown is sanitised; scripts and unsafe links are removed.
- Security headers (CSP, HSTS in production, etc.) are set with Helmet.
- Visitor IPs are stored only as a salted hash.

**Privacy:** the forms collect names, emails and phone numbers. Publish a privacy policy that describes how Navon Innovations uses enquiry data (the site does not include one, because its contents are a business and legal decision), and link it in the footer.
