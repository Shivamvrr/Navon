'use strict';
/**
 * Create or reset an admin account.
 *   npm run create-admin -- you@company.com "a-long-password" "Your Name"
 */
const db = require('../src/db');
const { createAdmin } = require('../src/admin-bootstrap');

const [email, password, name] = process.argv.slice(2);
if (!email || !password) {
  console.error('Usage: npm run create-admin -- <email> <password> [name]');
  process.exit(1);
}
try {
  db.open();
  createAdmin(email, password, name || '');
  console.log(`Admin ${email} is ready. Sign in at /admin/login`);
} catch (e) {
  console.error(e.message);
  process.exit(1);
}
