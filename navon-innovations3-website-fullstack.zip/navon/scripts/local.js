'use strict';
/**
 * npm run local — run the site on your own computer for testing.
 * Uses development mode (plain http, no secure-only cookies) and points
 * SITE_URL at localhost, whatever is in .env. Works on Windows, macOS and Linux.
 */
process.env.NODE_ENV = 'development';
process.env.PORT = process.env.PORT || '3000';
process.env.SITE_URL = `http://localhost:${process.env.PORT}`;
process.env.TRUST_PROXY = 'false';
require('../server');
