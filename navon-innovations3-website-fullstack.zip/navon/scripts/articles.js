'use strict';
/** npm run articles:update — overwrite blog posts with the versions in src/content/articles.js. */
require('../src/config');
const { syncArticles } = require('../src/articles-sync');
const r = syncArticles({ update: process.argv.includes('--update') });
console.log(`Done: ${r.added} added, ${r.updated} updated.`);
