'use strict';
/** Builds the default Open Graph image (1200x630) and touch icon. Run: node scripts/build-og.js */
const path = require('node:path');
const sharp = require('sharp');
const img = (f) => path.join(__dirname, '..', 'public', 'img', f);

(async () => {
  const bg = Buffer.from(`<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630">
    <defs>
      <radialGradient id="a" cx="78%" cy="40%" r="50%"><stop offset="0" stop-color="#6A4CF5" stop-opacity=".55"/><stop offset="1" stop-color="#6A4CF5" stop-opacity="0"/></radialGradient>
      <radialGradient id="b" cx="95%" cy="95%" r="40%"><stop offset="0" stop-color="#2EC4E6" stop-opacity=".35"/><stop offset="1" stop-color="#2EC4E6" stop-opacity="0"/></radialGradient>
      <linearGradient id="t" x1="0" x2="1"><stop offset="0" stop-color="#8B73FF"/><stop offset=".6" stop-color="#4E7BFF"/><stop offset="1" stop-color="#2EC4E6"/></linearGradient>
    </defs>
    <rect width="1200" height="630" fill="#070B24"/><rect width="1200" height="630" fill="url(#a)"/><rect width="1200" height="630" fill="url(#b)"/>
    <rect x="72" y="70" width="230" height="94" rx="18" fill="#fff"/>
    <text x="72" y="300" font-family="DejaVu Sans, Arial, sans-serif" font-size="58" font-weight="700" fill="#fff">Empowering events,</text>
    <text x="72" y="372" font-family="DejaVu Sans, Arial, sans-serif" font-size="58" font-weight="700" fill="url(#t)">elevating experiences.</text>
    <text x="72" y="450" font-family="DejaVu Sans, Arial, sans-serif" font-size="27" fill="#A9B0D6">Smart Event Registration &amp; Technology Solutions</text>
    <text x="72" y="560" font-family="DejaVu Sans, Arial, sans-serif" font-size="24" fill="#2EC4E6">navoninnovations.com</text>
  </svg>`);
  const logo = await sharp(img('navon-innovations-logo.webp')).resize({ width: 206 }).png().toBuffer();
  const cardRaw = await sharp(img('navon-smart-event-badge-illustration.webp')).resize({ height: 560 }).png().toBuffer();
  const { width: cw, height: ch } = await sharp(cardRaw).metadata();
  const fade = Buffer.from(`<svg xmlns="http://www.w3.org/2000/svg" width="${cw}" height="${ch}"><defs><radialGradient id="m" cx="50%" cy="50%" r="50%"><stop offset=".6" stop-color="#fff"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient></defs><rect width="100%" height="100%" fill="url(#m)"/></svg>`);
  const card = await sharp(cardRaw).composite([{ input: fade, blend: 'dest-in' }]).png().toBuffer();
  await sharp(bg).composite([{ input: logo, left: 84, top: 80 }, { input: card, left: 760, top: 40 }])
    .jpeg({ quality: 84, mozjpeg: true }).toFile(img('og/navon-innovations-og.jpg'));
  await sharp(path.join(__dirname, '..', 'public', 'favicon.svg')).resize(180, 180).png().toFile(img('icons/apple-touch-icon.png'));
  console.log('Built og image and touch icon');
})();
