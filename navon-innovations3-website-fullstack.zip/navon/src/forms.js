'use strict';
/**
 * Contact enquiries and demo requests: validation, storage and notification.
 * Notification status is stored on each record ('sent', 'failed', 'not_configured')
 * so the admin dashboard shows the truth about email delivery.
 */
const db = require('./db');
const mailer = require('./mailer');
const { eventTypes, attendeeRanges } = require('./content/site');

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const TIME_SLOTS = ['10:00 – 12:00 IST', '12:00 – 15:00 IST', '15:00 – 18:00 IST', 'Any time'];
const DEMO_STATUSES = ['new', 'contacted', 'scheduled', 'completed', 'cancelled'];
const ENQ_STATUSES = ['new', 'read', 'archived'];

const clean = (v, max = 500) => String(v == null ? '' : v).replace(/\u0000/g, '').trim().slice(0, max);

function todayIST() {
  return new Date(Date.now() + 5.5 * 3600e3).toISOString().slice(0, 10);
}

function common(b, errors) {
  const d = {
    name: clean(b.name, 120),
    company: clean(b.company, 160),
    email: clean(b.email, 200).toLowerCase(),
    phone: clean(b.phone, 40),
    event_type: clean(b.event_type, 80)
  };
  if (d.name.length < 2) errors.name = 'Enter your full name.';
  if (d.company.length < 2) errors.company = 'Enter your company or organisation.';
  if (!EMAIL_RE.test(d.email)) errors.email = 'Enter a valid email address, like name@company.com.';
  if (d.phone.replace(/\D/g, '').length < 10) errors.phone = 'Enter a phone number with at least 10 digits, including country code if outside India.';
  else if (!/^[+\d\s().-]+$/.test(d.phone)) errors.phone = 'Use digits, spaces and + only.';
  if (!eventTypes.includes(d.event_type)) errors.event_type = 'Choose the type of event.';
  return d;
}

function validateEnquiry(b) {
  const errors = {};
  const d = common(b, errors);
  d.attendees = clean(b.attendees, 40);
  d.event_date = clean(b.event_date, 10);
  d.message = clean(b.message, 4000);
  if (d.attendees && !attendeeRanges.includes(d.attendees)) errors.attendees = 'Choose an attendee range.';
  if (d.event_date && !/^\d{4}-\d{2}-\d{2}$/.test(d.event_date)) errors.event_date = 'Enter a valid date.';
  if (d.message.length < 10) errors.message = 'Tell us a little about your event (at least 10 characters).';
  return { data: d, errors };
}

function validateDemo(b) {
  const errors = {};
  const d = common(b, errors);
  d.delegates = clean(b.delegates, 40);
  d.preferred_date = clean(b.preferred_date, 10);
  d.preferred_time = clean(b.preferred_time, 40);
  d.requirements = clean(b.requirements, 4000);
  if (d.delegates && !attendeeRanges.includes(d.delegates)) errors.delegates = 'Choose a delegate range.';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(d.preferred_date)) errors.preferred_date = 'Choose a preferred demo date.';
  else if (d.preferred_date < todayIST()) errors.preferred_date = 'Choose today or a future date.';
  if (d.preferred_time && !TIME_SLOTS.includes(d.preferred_time)) errors.preferred_time = 'Choose a time slot.';
  return { data: d, errors };
}

const ref = (prefix, id) => `${prefix}-${String(id).padStart(6, '0')}`;

async function saveEnquiry(d, meta) {
  const r = db.get().prepare(
    `INSERT INTO enquiries (name, company, email, phone, event_type, attendees, event_date, message, source_page, ip_hash, user_agent)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(d.name, d.company, d.email, d.phone, d.event_type, d.attendees, d.event_date, d.message, meta.source, meta.ipHash, meta.ua);
  const id = Number(r.lastInsertRowid);
  const mail = await mailer.notifyCompany({
    subject: `New enquiry from ${d.name} (${d.company}) [${ref('ENQ', id)}]`,
    title: 'New website enquiry',
    replyTo: d.email,
    adminPath: `/admin/enquiries/${id}`,
    rows: [['Reference', ref('ENQ', id)], ['Name', d.name], ['Company', d.company], ['Email', d.email], ['Phone', d.phone],
      ['Event type', d.event_type], ['Expected attendees', d.attendees], ['Event date', d.event_date], ['Message', d.message], ['Submitted from', meta.source]]
  });
  db.get().prepare('UPDATE enquiries SET email_status = ?, email_error = ? WHERE id = ?').run(mail.status, mail.error || '', id);
  return { id, ref: ref('ENQ', id), email: mail.status };
}

async function saveDemo(d, meta) {
  const r = db.get().prepare(
    `INSERT INTO demo_requests (name, company, email, phone, event_type, delegates, preferred_date, preferred_time, requirements, source_page, ip_hash, user_agent)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(d.name, d.company, d.email, d.phone, d.event_type, d.delegates, d.preferred_date, d.preferred_time, d.requirements, meta.source, meta.ipHash, meta.ua);
  const id = Number(r.lastInsertRowid);
  const mail = await mailer.notifyCompany({
    subject: `Demo request: ${d.company} on ${d.preferred_date} [${ref('DEMO', id)}]`,
    title: 'New demo request',
    replyTo: d.email,
    adminPath: `/admin/demo-requests/${id}`,
    rows: [['Reference', ref('DEMO', id)], ['Name', d.name], ['Company', d.company], ['Email', d.email], ['Phone', d.phone],
      ['Event type', d.event_type], ['Expected delegates', d.delegates], ['Preferred date', d.preferred_date], ['Preferred time', d.preferred_time],
      ['Requirements', d.requirements], ['Submitted from', meta.source]]
  });
  db.get().prepare('UPDATE demo_requests SET email_status = ?, email_error = ? WHERE id = ?').run(mail.status, mail.error || '', id);
  return { id, ref: ref('DEMO', id), email: mail.status };
}

module.exports = { validateEnquiry, validateDemo, saveEnquiry, saveDemo, ref, TIME_SLOTS, DEMO_STATUSES, ENQ_STATUSES, todayIST };
