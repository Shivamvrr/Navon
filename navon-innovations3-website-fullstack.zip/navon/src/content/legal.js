'use strict';
/**
 * Legal pages, reproduced from navoninnovations.com (last updated 28 July 2026).
 * Written in Markdown and rendered with the blog renderer.
 * Review with your legal adviser before changing.
 */
const CONTACT = '\n\nEmail: [sales@navoninnovations.com](mailto:sales@navoninnovations.com)  \nPhone: +91 96544 96952';

const legal = {
  'privacy-policy': {
    title: 'Privacy Policy', updated: '28 July 2026',
    description: 'How Navon Innovations collects, uses and protects attendee and customer data across our event registration, access control and AI engagement platforms.',
    body: `## 1. Introduction
Navon Innovations ("Navon", "we", "us" or "our") provides event technology solutions including registration platforms, self-service kiosks, badge printing, RFID/NFC access control, face recognition entry, cashless payments and AI-powered attendee engagement tools. This Privacy Policy explains how we collect, use, share and protect personal information when you register for or attend an event powered by Navon, use our mobile app, or interact with our website.

By registering for a Navon-powered event or using our products, you agree to the collection and use of information as described in this policy.

## 2. Information We Collect
Depending on how you interact with our services, we may collect:

- **Registration details**: name, email address, phone number, company/organization, job title, and any custom fields requested by the event organizer.
- **Identity & entry data**: a photograph for badge printing or face recognition entry, QR code or RFID/NFC tag identifiers linked to your registration.
- **Payment information**: for cashless/NFC payments at events, transaction amounts and wallet balances (card and bank details are processed by our payment partners, not stored directly by Navon).
- **Usage data**: session attendance, entry/exit timestamps, app interactions, and analytics from kiosks, gates and the event mobile app.
- **Device & technical data**: IP address, browser type and cookies when you use our website or app.

## 3. How We Use Information
We use collected information to:

- Process event registration, print badges, and manage check-in
- Verify identity for entry using QR code, RFID/NFC, or face recognition
- Process cashless payments and maintain wallet balances
- Provide the event mobile app experience: agenda, networking, notifications
- Generate attendance analytics and reports for event organizers
- Communicate updates, reminders and support messages via email, SMS or WhatsApp
- Improve our products and maintain the security of our platform

## 4. Face Recognition & Biometric Data
Where an event organizer enables face recognition entry, we generate an encrypted facial template from a photo you provide (uploaded during registration or captured onsite). This template is used solely to verify your identity at entry points for that event.

- Face recognition is only used with the event organizer's configuration and, where legally required, your consent.
- Facial templates are encrypted, access-controlled, and are not sold or used for any purpose beyond event access and attendance tracking.
- An alternative check-in method (QR code, registration ID, or manual verification) is always available for attendees who opt out.
- Biometric templates are deleted or anonymized after the retention period described in Section 7, unless a longer period is required for the specific event.

## 5. Data Sharing
We do not sell personal information. We may share data with:

- **Event organizers**, who own the attendee data for their event and use it for event management and communication.
- **Service providers**: payment processors, SMS/WhatsApp/email delivery partners, and cloud hosting providers who process data on our behalf under confidentiality obligations.
- **Legal authorities**, where required by law, court order, or to protect the rights, safety or property of Navon, our clients, or attendees.

## 6. Data Security
We apply encryption in transit and at rest, role-based access controls, and audit logging across our registration, access control and payment systems. While we take reasonable measures to protect your information, no system is 100% secure, and we cannot guarantee absolute security.

## 7. Data Retention
Attendee data is retained for the duration of the event and a reasonable period afterward for reporting and support purposes, typically up to 12 months, unless the event organizer requests earlier deletion or a longer period is required for legal or contractual reasons. Facial recognition templates are retained only as long as necessary for the event's access control needs.

## 8. Your Rights
Depending on your location, you may have the right to access, correct, export, or request deletion of your personal data, and to withdraw consent for face recognition or marketing communications. To exercise these rights, contact us using the details in Section 12.

## 9. Cookies
Our website uses cookies to remember your preferences and understand site usage. You can manage your cookie consent at any time through your browser settings.

## 10. Children's Privacy
Our services are intended for business and professional event use and are not directed at children under 16. We do not knowingly collect personal information from children.

## 11. Changes to This Policy
We may update this Privacy Policy from time to time. Material changes will be reflected by updating the "Last updated" date at the top of this page.

## 12. Contact Us
For privacy-related questions or requests, contact us at:${CONTACT}`
  },

  'cashless-policy': {
    title: 'Cashless Policy', updated: '28 July 2026',
    description: 'Navon Innovations\' cashless and NFC payment policy for event transactions, top-ups and refunds.',
    body: `## 1. Overview
Navon Innovations provides NFC-based cashless payment systems (wristbands, cards or badges) that event organizers can enable to allow attendees to pay for food, beverages, merchandise and other on-site purchases without cash or cards. This policy explains how top-ups, payments and refunds of unused balance work.

## 2. How It Works
Each attendee is issued an NFC wristband, card or badge linked to a prepaid wallet. Attendees tap their wristband/card at participating vendor counters to pay instantly. Balances and transaction history can typically be checked at self-service kiosks or through the event mobile app, where enabled by the organizer.

## 3. Top-Up & Payment Methods
Wallets can be topped up at designated top-up counters or kiosks using cash, card, or UPI, depending on what the event organizer has enabled. Card and UPI payments are processed securely through our payment partners. Navon does not store your full card details.

## 4. Refunds of Unused Balance
Refund availability and timelines for unused wallet balance are set by the event organizer for each specific event and will be communicated at the top-up counter or in event materials. Where refunds are offered, they are typically processed to the original payment method within 7–10 business days after the event concludes. Unclaimed balances after the organizer's stated refund window may be forfeited, as disclosed at the event.

## 5. Lost or Damaged Wristbands & Cards
If your NFC wristband or card is lost, damaged, or stops working, report it immediately at the event help desk or top-up counter. Depending on the event's configuration, your remaining balance may be transferable to a replacement wristband after identity verification. Navon and event organizers are not responsible for balance lost due to a wristband being lost, stolen, or not reported before the event ends.

## 6. Fees
Navon does not charge attendees a platform fee for standard top-ups or payments. Any processing fee charged by a payment gateway, or any event-specific service charge, will be disclosed by the event organizer at the point of payment.

## 7. Security of Funds
Wallet balances are held and reconciled through our secure payment infrastructure. Transactions are encrypted and logged for audit purposes. In the rare event of a technical discrepancy, contact the event help desk or Navon support with your wristband/card ID and we will investigate and resolve it.

## 8. Contact & Support
For cashless payment support, contact us at:${CONTACT}`
  },

  'refund-cancellation': {
    title: 'Refund & Cancellation Policy', updated: '28 July 2026',
    description: 'Navon Innovations\' refund and cancellation policy for event registration, ticketing and technology service bookings.',
    body: `## 1. Overview
Navon Innovations provides the technology platform and onsite services that power event registration, access control and attendee engagement. This policy explains how refunds and cancellations are handled for (a) event registration/ticketing made through a Navon-powered event, and (b) technology service bookings made directly with Navon by event organizers.

## 2. Event Registration & Ticketing
For events that use Navon's registration and ticketing platform, the specific event's organizer sets the refund and cancellation terms for attendee tickets, including deadlines, eligibility and any cancellation fee. Navon operates the platform on the organizer's behalf and processes refunds according to the instructions and policy set by that organizer. Please refer to the specific event's registration page or contact the event organizer directly for ticket refund eligibility.

## 3. Technology Service Bookings
For organizers who book Navon's kiosks, RFID/NFC systems, face recognition, flap barriers, badge printing or other onsite technology services directly:

- Cancellations made more than 15 business days before the event date are eligible for a full refund, less any non-refundable costs already incurred (see Section 5).
- Cancellations made 7–15 business days before the event date are eligible for a 50% refund of service fees.
- Cancellations made less than 7 business days before the event date are generally non-refundable, as hardware, staffing and logistics are already committed.

## 4. Cancellation Timelines & Fees
Where a cancellation fee applies, it will be calculated based on the stage of preparation reached (equipment dispatch, staff deployment, custom branding, or printed materials already produced) and communicated to you before being deducted from any refund.

## 5. Non-Refundable Items
The following are generally non-refundable once work has begun: custom-branded badges, lanyards or printed materials already produced; hardware shipping/logistics costs already incurred; and any third-party costs (payment gateway fees, SMS/WhatsApp credits) already used.

## 6. How to Request a Refund
To request a refund or cancellation, contact our team with your event name, booking reference and reason for cancellation using the details in Section 8. For attendee ticket refunds, please contact the event organizer directly, as Navon does not independently override an organizer's ticketing policy.

## 7. Processing Time
Approved refunds are processed to the original payment method within 7–10 business days. Bank or card processing times beyond this may vary depending on your payment provider.

## 8. Contact Us
For refund or cancellation requests, contact us at:${CONTACT}`
  },

  'terms-conditions': {
    title: 'Terms & Conditions', updated: '28 July 2026',
    description: 'Terms and conditions governing the use of Navon Innovations\' event technology platform, products and services.',
    body: `## 1. Acceptance of Terms
These Terms & Conditions ("Terms") govern your access to and use of Navon Innovations' website, event registration platform, mobile app, onsite hardware (kiosks, RFID/NFC systems, face recognition, flap barriers, badge printing) and any related services (collectively, the "Services"). By accessing or using our Services, you agree to be bound by these Terms. If you do not agree, do not use the Services.

## 2. Description of Services
Navon provides event technology solutions for event organizers, corporates, conference venues and their attendees, including but not limited to online registration and ticketing, onsite check-in and badge printing, access control (RFID, NFC, QR, face recognition, automated flap barriers), cashless payments, a mobile attendee app, and AI-powered engagement experiences.

## 3. User Accounts & Eligibility
Certain features require an account or event registration. You are responsible for providing accurate information and maintaining the confidentiality of any login credentials. You must be legally authorized to enter into these Terms on your own behalf or on behalf of the organization you represent.

## 4. Acceptable Use
You agree not to: misuse or attempt to disrupt our systems (kiosks, access gates, payment infrastructure); attempt unauthorized access to another attendee's registration, badge or wallet; upload false or fraudulent registration information; or use our Services for any unlawful purpose.

## 5. Payments & Fees
Fees for technology services booked directly with Navon are set out in the applicable service agreement or quote. Event ticket pricing is set by the event organizer. Cashless payment top-ups and NFC wallet transactions are governed by our [Cashless Policy](/cashless-policy). Refunds and cancellations are governed by our [Refund & Cancellation Policy](/refund-cancellation).

## 6. Intellectual Property
All software, platform designs, hardware configurations, branding and content provided by Navon remain the intellectual property of Navon Innovations or its licensors. You may not copy, modify, reverse-engineer or resell our Services without written permission.

## 7. Data & Privacy
Our collection and use of personal data, including registration details and biometric data used for face recognition, is governed by our [Privacy Policy](/privacy-policy), which forms part of these Terms.

## 8. Third-Party Services
Our Services may integrate with third-party providers (payment gateways, WhatsApp/SMS/email delivery, cloud hosting). We are not responsible for the availability or performance of third-party services outside our control.

## 9. Limitation of Liability
To the maximum extent permitted by law, Navon Innovations shall not be liable for any indirect, incidental, or consequential damages arising from the use of our Services, including but not limited to event disruptions caused by factors outside our reasonable control (power outages, venue issues, force majeure events, or third-party service failures).

## 10. Indemnification
You agree to indemnify and hold Navon Innovations harmless from any claims, damages or expenses arising from your misuse of the Services or violation of these Terms.

## 11. Termination
We reserve the right to suspend or terminate access to our Services for any user or organizer who violates these Terms, engages in fraudulent activity, or misuses our systems.

## 12. Governing Law
These Terms are governed by the laws of India. Any disputes arising from these Terms shall be subject to the exclusive jurisdiction of the courts located in Delhi, India.

## 13. Changes to These Terms
We may update these Terms from time to time. Continued use of our Services after changes are posted constitutes acceptance of the revised Terms. Material changes will be reflected by updating the "Last updated" date at the top of this page.

## 14. Contact Us
For questions about these Terms, contact us at:${CONTACT}`
  },

  gdpr: {
    title: 'GDPR Compliance', updated: '', noindex: true,
    description: 'How Navon Innovations handles personal data in line with GDPR for attendees and clients based in the European Union.',
    body: `We're finalizing the full page covering how Navon handles personal data for attendees and clients based in the European Union. This page will be published shortly. In the meantime, reach out to our team directly with any questions, and see our [Privacy Policy](/privacy-policy).${CONTACT}`
  }
};

module.exports = { legal };
