'use strict';
/**
 * Detail pages: services, products and solution pages.
 * Content comes from navoninnovations.com and the Navon company profile.
 * URLs match the live site so existing search rankings carry over.
 *
 * Block types (views/partials/blocks.ejs):
 *   features  heading, intro, items[{icon,title,text,tags}], cols
 *   steps     heading, intro, items[{title,text}]
 *   split     heading, paras[], checks[], image, alt, reverse
 *   compare   heading, left, right, rows[[before, after]]
 *   usecases  heading, intro, items[{title, tags[]}]
 *   formats   heading, intro, items[{tag,title,sub,text,image}]
 *   gallery   heading, intro, items[{image,alt,title,text}]
 *   chips     heading, intro, items[]
 *   table     heading, head[], rows[][]
 *   faq       heading, items[{q,a}]
 *   stats     items[{value,label}]
 *   projects / clients   (render shared company data)
 */
const IMG = (f) => '/img/' + f;

const pages = {
  /* =================================================================
     SERVICES
     ================================================================= */
  onsite: {
    path: '/event-registration-services', section: 'service', icon: 'desk',
    title: 'Onsite Event Registration Services | Kiosks, POS & RFID',
    description: 'Onsite event registration: self-registration kiosks, staffed desks, mobile POS badge printing, face recognition, QR and RFID tracking. Get attendees in under 10 seconds.',
    kicker: 'Onsite registration', h1: 'Zero queues. Every format covered.',
    lede: 'Self-registration kiosks, mobile POS, face recognition, QR tracking and RFID: five ways to get attendees through the door in under 10 seconds, no matter how they arrive.',
    heroImage: IMG('event-registration-counter-team.webp'), heroAlt: 'Navon onsite registration counter team at an event',
    heroChips: ['QR verified', 'Badge printed', 'Entry logged'],
    serviceType: 'Onsite event registration', whatsappTopic: 'onsite event registration',
    blocks: [
      { type: 'features', heading: 'Why smart event registration matters', intro: 'Every second an attendee waits at the gate is a worse first impression of your event.', cols: 4, items: [
        { icon: 'bolt', title: 'Fast entry', text: 'Reduce attendee wait time with automated QR scanning and instant badge printing.' },
        { icon: 'shield', title: 'Accurate verification', text: 'Secure access control by verifying attendee data instantly at the gate.' },
        { icon: 'layers', title: 'Centralised data', text: 'All registrations and entry data sync directly with the event management dashboard.' },
        { icon: 'chart', title: 'Live analytics', text: 'Track attendee movement, session attendance and distribution activities in real time.' }
      ] },
      { type: 'steps', heading: 'How the registration system works', intro: 'From the invite to the last scan at the exit gate: one continuous, trackable flow.', items: [
        { title: 'Pre-registration', text: 'Delegates register online ahead of the event; name, category and details are captured and validated upfront.' },
        { title: 'QR code via WhatsApp & email', text: 'A unique QR code e-badge is sent instantly to every delegate. No app to install, no printout needed.' },
        { title: 'Self check-in or desk', text: 'On arrival, delegates show their QR at a self-check-in kiosk, staffed counter or mobile POS device.' },
        { title: 'Instant badge printing', text: 'The system verifies the QR and prints the badge or label on the spot, with no manual data entry.' },
        { title: 'Face, QR or RFID verification', text: 'Choose the verification method that fits your event for secure, contactless entry.' },
        { title: 'Venue entry', text: 'Verified delegates pass straight through: no manual list-checking, no bottlenecks at the gate.' },
        { title: 'Session & zone tracking', text: 'The same badge tracks session attendance, restricted-zone access and gift or meal distribution.' },
        { title: 'Live analytics & reports', text: 'Organizers see check-ins, attendance and engagement live, with full reports after the event.' }
      ] },
      { type: 'formats', heading: 'Where attendees get their badge', intro: 'Three formats, one goal: verify the delegate and put a printed badge in their hand in seconds.', items: [
        { tag: 'Self-service', title: 'Smart kiosks', text: 'Dual-screen kiosks for self-registration and check-in without staff assistance.', href: '/smart-kiosks', image: IMG('self-service-registration-kiosk.webp') },
        { tag: 'Staffed', title: 'Registration desk', text: 'Trained staff verify registrations, print badges and assist walk-ins.', href: '/registration-desk', image: IMG('welcome-registration-desk.webp') },
        { tag: 'Handheld', title: 'Mobile POS', text: 'Portable devices with built-in label printing, anywhere in the venue.', href: '/mobile-pos', image: IMG('label-print-pos-mobile-check-in.webp') }
      ] },
      { type: 'features', heading: 'Where the system knows who\'s where', intro: 'Once badged, the same identity is verified and tracked at every gate, session and counter.', cols: 3, items: [
        { icon: 'qr', title: 'QR code tracking', text: 'One QR code, scanned everywhere: entry, sessions, gifts and distribution points.', tags: ['Fast gate entry', 'Session tracking', 'Live analytics'], href: '/qr-code-tracking' },
        { icon: 'face', title: 'Face recognition', text: 'The camera confirms identity against the registration photo and the gate opens, with no card, phone or queue.', tags: ['Contactless', 'Sub-second match', 'Fraud check'], href: '/face-recognition' },
        { icon: 'rfid', title: 'RFID registration', text: 'Badges and wristbands that tap and log automatically, without needing a line of sight.', tags: ['No line-of-sight', 'High-volume gates', 'Multi-day events'], href: '/rfid-tracking' }
      ] },
      { type: 'features', heading: 'Tracking beyond the entry gate', intro: 'The same badge tracks activity throughout the event using QR, RFID or NFC.', cols: 4, items: [
        { icon: 'gift', title: 'Gift distribution', text: 'Scan badges before distributing event kits to prevent duplicate collection.' },
        { icon: 'food', title: 'Food distribution', text: 'Attendees scan their badge before collecting food, ensuring controlled distribution.' },
        { icon: 'session', title: 'Session attendance', text: 'Track which sessions attendees join for accurate engagement analytics.' },
        { icon: 'shield', title: 'Access control', text: 'Allow entry only to authorised delegates in restricted event areas.' }
      ] },
      { type: 'split', heading: 'Everything, live, for organizers', paras: ['The event dashboard gives organizers complete visibility into performance and attendee activity in real time, while the event is still running, not just in a report afterward.'], checks: ['Live attendee count', 'Gate entry analytics', 'Session attendance', 'Gift distribution reports', 'Food distribution data', 'Post-event reports'], image: IMG('event-dashboard-combined-report.webp'), alt: 'Navon live event dashboard', reverse: true },
      { type: 'faq', heading: 'Onsite registration questions', items: [
        { q: 'How long does check-in take?', a: 'Self check-in via QR, RFID or face match takes under 10 seconds, and badges are printed on the spot.' },
        { q: 'Can you handle walk-in attendees?', a: 'Yes. Registration desks and mobile POS devices register walk-ins on the spot and print their badges immediately.' },
        { q: 'How quickly can you deploy?', a: 'Most deployments — kiosks, RFID gates and the registration platform — are configured and on-site within 5-10 business days of confirmation, depending on attendee scale and custom branding.' }
      ] }
    ],
    related: ['/smart-kiosks', '/badge-printing', '/face-recognition', '/rfid-tracking']
  },

  kiosks: {
    path: '/smart-kiosks', section: 'service', icon: 'kiosk',
    title: 'Smart Self-Registration Kiosks for Events | Navon',
    description: 'Dual-screen smart kiosks for event self-registration and check-in: QR scan, instant badge printing, AI photo capture and live database sync, branded for your event.',
    kicker: 'Smart kiosks', h1: 'Self-registration, in seconds.',
    lede: 'Dual-screen smart kiosks let attendees complete self-registration and check-in without staff assistance. The front screen guides the attendee while the rear screen shows organizers a live dashboard.',
    heroImage: IMG('self-service-registration-kiosk.webp'), heroAlt: 'Navon dual-screen self-registration kiosk',
    heroChips: ['QR scanned', 'Photo captured', 'Badge printed'],
    serviceType: 'Self-service registration kiosk', whatsappTopic: 'smart kiosks',
    blocks: [
      { type: 'features', heading: 'What the kiosk does', cols: 3, items: [
        { icon: 'qr', title: 'QR code scan check-in', text: 'Attendees scan the QR code they received by email or WhatsApp for quick access.' },
        { icon: 'print', title: 'Instant badge printing', text: 'Self-register and print badges and certificates on the spot.' },
        { icon: 'camera', title: 'AI photo capture', text: 'An integrated camera captures attendee photos instantly.' },
        { icon: 'sync', title: 'Live database sync', text: 'Check-in data stays in sync in real time across every kiosk and counter.' },
        { icon: 'people', title: 'User-friendly interface', text: 'Simple, intuitive screens that attendees use without help.' },
        { icon: 'brush', title: 'Customisable design', text: 'The interface matches your event branding.' }
      ] },
      { type: 'split', heading: 'Designed to eliminate queues', paras: ['Kiosks absorb the morning rush so your staffed counters can focus on walk-ins, VIPs and special cases. Every check-in lands in the same live dashboard as the rest of your event.'], checks: ['Front screen guides the attendee', 'Rear screen shows organizers a live dashboard', 'Badges and certificates printed on demand', 'Works alongside face recognition for touch-free check-in'], image: IMG('attendee-using-registration-kiosk.webp'), alt: 'Attendee using a Navon self-registration kiosk at an event' }
    ],
    related: ['/event-registration-services', '/face-recognition', '/badge-printing', '/registration-desk']
  },

  desk: {
    path: '/registration-desk', section: 'service', icon: 'people',
    title: 'Managed Event Registration Desk & Counters | Navon',
    description: 'Fully managed event registration desks: trained staff verify registrations, scan QR codes, print badges and handle walk-ins, VIPs and speakers across multi-counter setups.',
    kicker: 'Registration desk', h1: 'A fully managed front desk.',
    lede: 'Our trained staff verify registrations, scan QR codes, print badges instantly and assist walk-in attendees, using enterprise-grade hardware and cloud-based registration software.',
    heroImage: IMG('welcome-registration-desk.webp'), heroAlt: 'Navon managed registration desk at a corporate event',
    heroChips: ['Delegate found', 'Badge printed', 'Welcome!'],
    serviceType: 'Event registration desk services', whatsappTopic: 'registration desk services',
    blocks: [
      { type: 'features', heading: 'Everything at the counter', cols: 4, items: [
        { icon: 'search', title: 'Search by name, mobile or ID', text: 'Find any delegate in seconds, even without their QR code.' },
        { icon: 'user-plus', title: 'Walk-in registration', text: 'Register attendees on the spot and print their badge immediately.' },
        { icon: 'star', title: 'VIP & speaker registration', text: 'Dedicated handling for VIPs, speakers and faculty.' },
        { icon: 'desk', title: 'Multi-counter setup', text: 'Organised, event-branded counters scaled to your footfall.' }
      ] },
      { type: 'gallery', heading: 'Registration day, in photos', items: [
        { image: IMG('event-registration-counter-team.webp'), alt: 'Registration counter team at an event', title: 'Event-branded counters', text: 'Trained staff at organised, branded desks.' },
        { image: IMG('onsite-registration-desk-corporate-event.webp'), alt: 'Onsite registration desk at a corporate event', title: 'Corporate events', text: 'Fast check-in for delegates and guests.' },
        { image: IMG('github-2026-registration-desk-bengaluru.webp'), alt: 'Registration desk at GitHub 2026, Bengaluru', title: 'GitHub 2026, Bengaluru', text: '1,200 attendees.' }
      ] }
    ],
    related: ['/event-registration-services', '/mobile-pos', '/smart-kiosks', '/badge-printing']
  },

  pos: {
    path: '/mobile-pos', section: 'service', icon: 'print',
    title: 'Mobile POS Event Registration & Label Printing | Navon',
    description: 'Mobile POS registration: portable handheld devices with built-in label printing to register attendees anywhere in the venue, ideal for walk-ins and overflow queues.',
    kicker: 'Mobile POS', h1: 'Registration that walks the floor.',
    lede: 'Portable handheld devices with built-in instant label printing let your team register attendees anywhere in the venue, ideal for walk-ins and overflow queues at peak arrival times.',
    heroImage: IMG('label-print-pos-mobile-check-in.webp'), heroAlt: 'Navon mobile POS device with built-in label printer',
    heroChips: ['QR scanned', 'Label printed'],
    serviceType: 'Mobile POS event registration', whatsappTopic: 'mobile POS registration',
    blocks: [
      { type: 'features', heading: 'Built for peak arrival times', cols: 4, items: [
        { icon: 'phone', title: 'Portable device', text: 'Handheld registration anywhere on-site.' },
        { icon: 'print', title: 'Instant label printing', text: 'Accurate and cost-effective on-site printing.' },
        { icon: 'user-plus', title: 'Walk-in registration', text: 'Register new attendees on the spot.' },
        { icon: 'clock', title: '40-45 second registration', text: 'A complete walk-in registration in under a minute.' }
      ] },
      { type: 'split', heading: 'Take check-in to the queue', paras: ['Instead of moving attendees to the counter, mobile POS moves the counter to them: satellite entrances, overflow queues, session doors or VIP arrivals.'], checks: ['Scan QR e-badges', 'Search and verify delegates', 'Print labels on the spot', 'Synced with the live dashboard'], image: IMG('attendee-check-in-device-scan.webp'), alt: 'Attendee check-in on a handheld device' }
    ],
    related: ['/registration-desk', '/qr-code-tracking', '/event-registration-services', '/badge-printing']
  },

  face: {
    path: '/face-recognition', section: 'service', icon: 'face',
    title: 'Face Recognition Event Check-in & Access Control | Navon',
    description: 'AI face recognition for event check-in and access control: sub-second verification, contactless entry, automatic badge printing and turnstile access. No QR, no badge search.',
    kicker: 'Face recognition', h1: 'Walk in. Look at the camera. You\'re in.',
    lede: 'Replace QR codes, printed tickets and manual verification with AI-powered facial recognition. Attendees walk up to the entrance, the camera verifies their identity in under a second, and access is granted automatically.',
    heroImage: IMG('facial-recognition-check-in-tablet.webp'), heroAlt: 'Navon face recognition check-in device',
    heroChips: ['Face verified', 'Badge printed', 'Gate opened', 'Attendance recorded'],
    serviceType: 'Facial recognition event check-in', whatsappTopic: 'face recognition check-in',
    blocks: [
      { type: 'split', heading: 'What is face recognition for events?', paras: ['Navon Face Recognition is an AI-powered event access system that matches a live face with the attendee\'s registered profile in real time.'], checks: ['No ticket', 'No badge search', 'No mobile phone', 'No manual verification'], image: IMG('facial-recognition-check-in-tablet.webp'), alt: 'Face recognition verification screen' },
      { type: 'steps', heading: 'From registration to entry', items: [
        { title: 'Register online', text: 'Attendees register through your event website or registration portal.' },
        { title: 'Upload a selfie', text: 'During registration attendees upload a selfie or capture a photo.' },
        { title: 'AI creates a face profile', text: 'The system securely generates an encrypted facial template.' },
        { title: 'Arrive at the venue', text: 'The attendee simply walks to the entrance.' },
        { title: 'Face verification', text: 'AI verifies the attendee instantly.' },
        { title: 'Badge prints or gate opens', text: 'Automatically print a badge, open a turnstile or mark attendance.' }
      ] },
      { type: 'formats', heading: 'Multiple deployment options', intro: 'Face recognition adapts to the entry flow your event actually needs.', items: [
        { tag: 'Conferences', title: 'Face recognition + badge printing', text: 'Attendee walks in, camera verifies, badge prints automatically at the welcome desk.' },
        { tag: 'Exhibitions', title: 'Face recognition + turnstile', text: 'Camera verifies, the gate opens automatically and attendance is recorded.' },
        { tag: 'Self check-in', title: 'Face recognition + kiosk', text: 'Look at the camera, verify, print the badge. Done.' },
        { tag: 'VIP entry', title: 'Face recognition + volunteer tablet', text: 'A volunteer holds the tablet, the face is verified and entry is approved.' }
      ] },
      { type: 'features', heading: 'Enterprise features', cols: 3, items: [
        { icon: 'face', title: 'AI face matching', text: 'Sub-second, accurate verification, even in high-footfall lines, crowded halls or low light.', tags: ['< 0.5 s verification'] },
        { icon: 'hand', title: 'Contactless entry', text: 'No scanning, no touching, no paper: attendees just walk in.' },
        { icon: 'users', title: 'Role-based access', text: 'Each role gets different permissions.', tags: ['Delegate', 'VIP', 'Speaker', 'Media', 'Staff', 'Exhibitor'] },
        { icon: 'shield', title: 'Anti-spoofing / liveness AI', text: 'Detects photos, videos and masks so only real, live faces are verified.' },
        { icon: 'chart', title: 'Live dashboard & analytics', text: 'Live attendees, occupancy, gate-wise entries, peak entry time, failed verifications and VIP arrivals.' },
        { icon: 'print', title: 'Badge printing', text: 'After face verification, the badge prints automatically. No searching, no typing.' },
        { icon: 'sync', title: 'Multi-gate sync', text: 'Multiple entrances, a single database and real-time sync.' },
        { icon: 'wifi-off', title: 'Offline mode', text: 'Works even if the internet becomes unstable, and syncs automatically later.' },
        { icon: 'session', title: 'Session scan', text: 'Verify attendees before workshops, breakout rooms, VIP lounges and networking dinners.' }
      ] },
      { type: 'usecases', heading: 'Where you can use it', items: [
        { title: 'Conferences', tags: ['Delegate check-in', 'Speaker registration', 'VIP access', 'Workshop attendance'] },
        { title: 'Exhibitions', tags: ['Visitor entry', 'Exhibitor access', 'Business lounge', 'Restricted halls'] },
        { title: 'Corporate events', tags: ['Employee events', 'Annual meetings', 'Leadership summits', 'Training programmes'] },
        { title: 'Medical conferences', tags: ['Doctors', 'Faculty', 'Sponsors', 'International delegates', 'CME tracking'] },
        { title: 'Universities', tags: ['Graduation', 'Convocation', 'Student verification', 'Visitor management'] },
        { title: 'Government events', tags: ['Authorised entry', 'High security', 'VIP movement', 'Restricted access'] },
        { title: 'Stadiums & arenas', tags: ['VIP gates', 'Media', 'Backstage', 'Staff access'] },
        { title: 'Festivals', tags: ['Cashless zones', 'VIP lounge', 'Artist entry', 'Crew management'] }
      ] },
      { type: 'compare', heading: 'Why organizers love it', left: 'Traditional check-in', right: 'Navon face recognition', rows: [
        ['Search by name', 'Instant AI recognition'], ['Scan QR code', 'No QR required'], ['Manual verification', 'Automatic verification'], ['Queue formation', 'Fast-moving entry'],
        ['Paper lists', 'Digital dashboard'], ['Staff intensive', 'Minimal staff required'], ['Manual attendance', 'Real-time tracking'], ['Multiple systems', 'One unified platform']
      ] },
      { type: 'faq', heading: 'Face recognition questions', items: [
        { q: 'Do attendees need to upload a photo?', a: 'Yes. They can upload a selfie during registration or capture one at the help desk.' },
        { q: 'Can walk-in attendees use face recognition?', a: 'Yes. A photo can be captured instantly during onsite registration.' },
        { q: 'What if face recognition fails?', a: 'The system automatically falls back to QR code, mobile number, registration ID or manual verification.' },
        { q: 'Can it work with badge printing?', a: 'Yes. Face verification can trigger automatic badge printing without any manual search.' },
        { q: 'Does it work with turnstiles?', a: 'Yes. Verified attendees can automatically unlock access gates.' },
        { q: 'Is attendee data secure?', a: 'Facial data is stored securely using encrypted biometric templates with controlled access and audit logging.' }
      ] }
    ],
    related: ['/automated-flap-barriers', '/smart-kiosks', '/rfid-tracking', '/ai-photo-sharing']
  },

  rfid: {
    path: '/rfid-tracking', section: 'service', icon: 'rfid',
    title: 'RFID Registration & Contactless Event Tracking | Navon',
    description: 'RFID event registration and contactless tracking: check-in without line of sight, live attendee movement, session attendance, access control and duplicate-free meal and kit distribution.',
    kicker: 'RFID smart registration & tracking', h1: 'RFID registration & contactless tracking.',
    lede: 'Check attendees in without a line of sight, follow their movement across the venue, log session attendance automatically, lock down restricted areas and stop duplicate meal or kit collection: one RFID platform from check-in to check-out.',
    heroImage: IMG('rfid-smart-tracking-reader.webp'), heroAlt: 'Navon RFID smart tracking reader',
    heroChips: ['Badge verified', 'Zone logged', 'Live analytics'],
    serviceType: 'RFID event registration and tracking', whatsappTopic: 'RFID tracking',
    blocks: [
      { type: 'steps', heading: 'From badge to insight', items: [
        { title: 'Badge registration', text: 'Attendees register online or onsite and receive a personalised RFID badge or wristband linked to their profile.' },
        { title: 'Badge activation', text: 'Every badge is securely activated and tied to attendee details, access permissions and event activities.' },
        { title: 'Contactless scanning', text: 'Attendees walk past a reader or tap their badge at checkpoints for instant authentication.' },
        { title: 'Live tracking', text: 'Monitor movement, hall occupancy, booth visits, session attendance and access events in real time.' },
        { title: 'Analytics & reports', text: 'Detailed reports on attendance, session participation, meal distribution, visitor flow and event performance.' }
      ] },
      { type: 'features', heading: 'Everything onsite operations need', cols: 3, items: [
        { icon: 'chart', title: 'Command centre dashboard', text: 'Live attendees, active readers, check-ins, session attendance, meal consumption, access logs, occupancy and alerts.' },
        { icon: 'badge', title: 'RFID registration', text: 'Online & onsite registration, RFID badge printing, activation, instant check-in and duplicate prevention.' },
        { icon: 'hand', title: 'Contactless check-in', text: 'Fast entry with no manual verification, reduced queue times and multi-gate support.' },
        { icon: 'shield', title: 'Smart access control', text: 'Control access by attendee type across VIP areas, faculty lounges, exhibitor access, workshops and restricted zones.', tags: ['RFID readers', 'Flap barriers', 'Turnstiles & speed gates'] },
        { icon: 'food', title: 'Food & kit distribution', text: 'Eliminate duplicate collections across meals, welcome kits, conference bags and merchandise.' },
        { icon: 'map', title: 'Exhibition analytics', text: 'Booth visits, dwell time, popular exhibitors, visitor heatmaps and lead collection.' }
      ] },
      { type: 'split', heading: 'Session attendance without manual scanning', paras: ['Attendees tap in at session doors and their participation is recorded automatically: no clipboard, no manual sign-in sheet.'], checks: ['Session check-in', 'CME / CPD tracking', 'Workshop attendance', 'Speaker sessions', 'Attendance certificates'], image: IMG('delegate-tracking-checkpoint.webp'), alt: 'RFID tracking checkpoint at a conference venue' },
      { type: 'formats', heading: 'Choose the right RFID format', items: [
        { tag: 'Badge', title: 'RFID badge printing', sub: 'Printed onsite with attendee details', text: 'RFID-enabled badges carrying name, role and access level, printed at check-in.' },
        { tag: 'Wristband', title: 'RFID wristbands', sub: 'Waterproof, non-transferable', text: 'Ideal for festivals, concerts, sports events and cashless environments.' },
        { tag: 'Card', title: 'RFID cards', sub: 'Slim, badge-holder friendly', text: 'Perfect for conferences, exhibitions and corporate meetings.' },
        { tag: 'Reader', title: 'RFID readers', sub: 'Handheld and fixed options', text: 'From roaming staff checks to gate-mounted access control.' }
      ] },
      { type: 'usecases', heading: 'One RFID platform for every event type', items: [
        { title: 'Medical conferences', tags: ['Hall and workshop entry control', 'CME attendance per session', 'Separate faculty, delegate and sponsor zones'] },
        { title: 'Exhibitions & trade shows', tags: ['Booth visit and dwell-time heatmaps', 'Lead capture by badge scan', 'Separate visitor and exhibitor rules'] },
        { title: 'Corporate events', tags: ['Reception and visitor passes', 'Meeting and town hall attendance', 'Meal and kit counters without repeats'] },
        { title: 'Festivals', tags: ['Cashless spending on one wristband', 'Live crowd count per zone', 'VIP area and re-entry control'] },
        { title: 'Universities', tags: ['Lecture and exam attendance by tap', 'Hostel and library access', 'Convocation entry and seating'] }
      ] },
      { type: 'compare', heading: 'Why choose Navon RFID?', left: 'Traditional RFID systems', right: 'Navon RFID platform', rows: [
        ['Separate software required', 'Registration + RFID in one platform'], ['Basic entry logging', 'Live attendee tracking'], ['Manual attendance', 'Session attendance'], ['Manual coupon system', 'Food & kit distribution'],
        ['Limited integrations', 'Access control integration'], ['Basic reports', 'Real-time analytics'], ['Local software only', 'Cloud dashboard'], ['Single-event setup', 'Multi-event management']
      ] },
      { type: 'faq', heading: 'RFID questions', items: [
        { q: 'What is RFID event registration?', a: 'RFID event registration uses RFID-enabled badges or wristbands to automate attendee check-in, access control, attendance tracking and event operations.' },
        { q: 'How does RFID tracking work?', a: 'Each attendee receives an RFID badge or wristband. Readers detect the badge at checkpoints, recording attendance and movement without manual scanning.' },
        { q: 'Can RFID work with flap barriers and turnstiles?', a: 'Yes. Navon integrates RFID with flap barriers, speed gates and turnstiles for secure, contactless access control.' },
        { q: 'Can RFID manage food and kit distribution?', a: 'Yes. Every meal, welcome kit or merchandise item can be tracked so attendees receive items only once.' },
        { q: 'Does RFID work alongside QR codes and face recognition?', a: 'Yes. The platform supports RFID, QR code, NFC and face recognition within a single event ecosystem.' }
      ] }
    ],
    related: ['/nfc-payments', '/automated-flap-barriers', '/delegate-management', '/qr-code-tracking']
  },

  flap: {
    path: '/automated-flap-barriers', section: 'service', icon: 'gate',
    title: 'Automated Flap Barrier & Turnstile Access Control | Navon',
    description: 'Smart flap barrier and turnstile access control for events with face recognition, QR, NFC and RFID. Anti-tailgating, role-based zones, live occupancy and offline verification.',
    kicker: 'Smart access control', h1: 'Automated flap barriers. Intelligent access control.',
    lede: 'Automate attendee entry with AI-powered flap barriers integrated with face recognition, QR codes, NFC and RFID. Eliminate queues, enhance security and monitor every entry in real time from a single dashboard.',
    heroImage: IMG('flap-barrier-smart-entry-gates.webp'), heroAlt: 'Navon automated flap barrier gates',
    heroChips: ['Identity verified', 'Gate opened', 'Anti-tailgating active'],
    serviceType: 'Automated flap barrier access control', whatsappTopic: 'automated flap barriers',
    blocks: [
      { type: 'split', heading: 'What is an automated flap barrier?', paras: ['An automated flap barrier, also called a turnstile gate or speed gate, is a smart entrance gate that provides secure, fast and contactless entry for conferences, exhibitions, corporate offices, universities and high-security venues.', 'Integrated with Navon\'s access control platform, attendees are verified instantly before the glass flaps open, combining hardware, workflow, software and analytics in one system.'], image: IMG('flap-barrier-entry-event-venue.webp'), alt: 'Flap barrier gates installed at an event venue' },
      { type: 'steps', heading: 'From registration to entry', items: [
        { title: 'Register online', text: 'Attendees register through your event website or registration portal.' },
        { title: 'Receive a credential', text: 'A unique QR code, NFC card or facial profile.' },
        { title: 'Walk to the gate', text: 'No queue, no manual desk.' },
        { title: 'Identity verified', text: 'Face, QR, NFC or RFID authentication in an instant.' },
        { title: 'Flap barrier opens', text: 'Only for verified, authorised attendees.' },
        { title: 'Attendance recorded', text: 'Entry is logged against the attendee\'s profile and the dashboard updates live.' }
      ] },
      { type: 'formats', heading: 'Multiple authentication methods', intro: 'Run one method or all of them together; organizers choose what fits each attendee type.', items: [
        { tag: 'Face', title: 'Look. Walk. You\'re in.', text: 'No phone, no badge, no waiting: AI verifies identity as you approach.' },
        { tag: 'QR code', title: 'Scan & go', text: 'Instant scan-based entry for conferences, exhibitions and visitors.' },
        { tag: 'NFC', title: 'Tap & enter', text: 'NFC badge or card: instant authentication, zero friction.' },
        { tag: 'RFID', title: 'Wristband access', text: 'For festivals, VIP areas and multi-day events.' }
      ] },
      { type: 'split', heading: 'New: RFID parking barrier management', paras: ['The same platform also controls vehicle entry: multi-use access management for staff, VIP and visitor parking, with paid parking management for both RFID and non-RFID vehicles.'], checks: ['Multi-use access management', 'Paid parking management', 'Non-RFID vehicles supported'] },
      { type: 'features', heading: 'Enterprise features', cols: 3, items: [
        { icon: 'face', title: 'AI face recognition', text: 'Verify attendees in under 0.5 seconds, even in high-footfall lines.' },
        { icon: 'users', title: 'Anti-tailgating detection', text: 'Prevent multiple people entering on one authentication.' },
        { icon: 'chart', title: 'Live occupancy monitoring', text: 'Track how many attendees are inside every zone.' },
        { icon: 'sync', title: 'Multi-gate synchronisation', text: 'Control unlimited gates from one dashboard.' },
        { icon: 'wifi-off', title: 'Offline verification', text: 'Works during network interruptions and syncs later.' },
        { icon: 'lock', title: 'Security & audit logs', text: 'Encrypted, timestamped history of every entry and exit.' }
      ] },
      { type: 'chips', heading: 'Perfect for every entry point', items: ['Main event entrance', 'VIP entry', 'Faculty lounge', 'Speaker lounge', 'Exhibition hall', 'Workshop rooms', 'Networking dinner', 'Staff entrance'] },
      { type: 'table', heading: 'Supported hardware', head: ['Category', 'Options'], rows: [
        ['Flap barrier gates', 'Single lane, dual lane, speed gates, glass flap'],
        ['Authentication devices', 'Face terminal, QR scanner, NFC reader, RFID reader, tablet, touch kiosk'],
        ['Optional devices', 'Badge printer, LED display, visitor camera, ticket scanner, metal detector, turnstile']
      ] },
      { type: 'faq', heading: 'Flap barrier questions', items: [
        { q: 'Can flap barriers work without the internet?', a: 'Yes. Offline verification allows continued operation and syncs data automatically once the connection is restored.' },
        { q: 'Can attendees use face recognition, QR code and NFC together?', a: 'Yes. Multiple authentication methods can run simultaneously.' },
        { q: 'Can access be restricted to specific zones?', a: 'Yes. Assign permissions for VIP lounges, faculty rooms, workshops, speaker areas, exhibition halls and other restricted spaces.' },
        { q: 'Where have you deployed flap barriers?', a: 'Flap barrier and turnstile deployments across Delhi, Mumbai, Bangalore, Hyderabad, Chennai, Pune, Ahmedabad, Gurgaon and Noida.' }
      ] }
    ],
    related: ['/face-recognition', '/rfid-tracking', '/nfc-payments', '/smart-kiosks']
  },

  qr: {
    path: '/qr-code-tracking', section: 'service', icon: 'qr',
    title: 'QR Code Event Registration & Smart Tracking | Navon',
    description: 'QR code event registration and tracking: a unique QR e-badge by WhatsApp and email, fast gate entry, session tracking, gift and meal distribution, and live analytics.',
    kicker: 'QR code tracking', h1: 'One QR code. Scanned everywhere.',
    lede: 'Our core tracking method: one QR code per attendee, scanned at entry, sessions, gifts and distribution points. Fast, reliable and works on any phone camera or scanner.',
    heroImage: IMG('handheld-qr-code-scanner.webp'), heroAlt: 'Handheld QR code scanner',
    heroChips: ['QR verified', 'Session logged'],
    serviceType: 'QR code event registration and tracking', whatsappTopic: 'QR code tracking',
    blocks: [
      { type: 'split', heading: 'An e-badge in every pocket', paras: ['A unique QR code e-badge is sent instantly to every delegate by WhatsApp and email: no app to install, no printout needed before arrival.'], checks: ['Generated at registration', 'Delivered by WhatsApp & email', 'Scanned at check-in for instant badge printing', 'Re-used at every checkpoint'], image: IMG('personalised-e-badge-qr-code.webp'), alt: 'Personalised QR e-badge with registration ID' },
      { type: 'features', heading: 'What one QR code tracks', cols: 4, items: [
        { icon: 'gate', title: 'Fast gate entry', text: 'Scan and go at entrances and flap barriers.' },
        { icon: 'session', title: 'Session tracking', text: 'Track which sessions attendees join.' },
        { icon: 'gift', title: 'Gift & food distribution', text: 'Prevent duplicate collection at counters.' },
        { icon: 'chart', title: 'Live analytics', text: 'Movement tracking with reporting analytics.' }
      ] },
      { type: 'table', heading: 'QR, face or RFID?', head: ['Method', 'Best for'], rows: [
        ['QR code', 'Fast roll-out; works on any phone camera or scanner; entry, sessions and distribution'],
        ['Face recognition', 'Touch-free entry with no QR or badge search; VIPs and high security'],
        ['RFID', 'No line of sight needed; high-volume gates and multi-day events']
      ] }
    ],
    related: ['/event-registration-services', '/face-recognition', '/rfid-tracking', '/delegate-management']
  },

  nfc: {
    path: '/nfc-payments', section: 'service', icon: 'wallet',
    title: 'NFC Cashless Payments for Events | Tap, Pay & Enjoy | Navon',
    description: 'NFC cashless payments for events: tap-to-pay wristbands, cards and stickers, vendor POS, real-time sales dashboard, automatic refunds and offline mode. Scales to 50,000+ attendees.',
    kicker: 'NFC cashless payments', h1: 'Tap. Pay. Enjoy.',
    lede: 'Replace cash counters and card queues with tap-to-pay NFC wristbands, cards and stickers. Attendees top up once and spend instantly at every stall, while you get a real-time sales dashboard across the whole event.',
    heroImage: IMG('nfc-cashless-payment-device.webp'), heroAlt: 'Navon NFC cashless payment device',
    heroChips: ['Balance updated', 'Sale recorded', 'Payment successful'],
    serviceType: 'NFC cashless payments for events', whatsappTopic: 'NFC cashless payments',
    blocks: [
      { type: 'formats', heading: 'One wallet. Every tap format.', intro: 'Preload a wristband, card or sticker, then just tap. Run one format or mix all four across zones, all synced to the same wallet.', items: [
        { tag: 'POS device', title: 'Cashless NFC device', sub: 'With or without a built-in printer', text: 'The vendor-facing terminal that reads every tap format and settles the sale instantly.' },
        { tag: 'Card', title: 'NFC card', sub: 'Slim, pocket-friendly, reusable', text: 'Fits a badge wallet: the natural choice for conferences and corporate events.' },
        { tag: 'Sticker', title: 'NFC sticker', sub: 'Sticks to any badge or phone case', text: 'The lowest-cost option, turning what attendees already carry into a tap-to-pay tag.' },
        { tag: 'Wristband', title: 'NFC band', sub: 'Built for festivals & multi-day events', text: 'Waterproof and non-transferable, working for the whole event.' }
      ] },
      { type: 'steps', heading: 'From top-up to tap & pay', items: [
        { title: 'Top up balance', text: 'Online during registration or at an onsite top-up counter.' },
        { title: 'Get a wristband, card or sticker', text: 'Any format, linked to the same attendee profile.' },
        { title: 'Tap at any stall', text: 'F&B counters, bars and merchandise: one tap, no cash handling.' },
        { title: 'Instant confirmation', text: 'Payment verified and confirmed on the POS screen in under a second.' },
        { title: 'Real-time sales sync', text: 'Every transaction reflects instantly on organizer and vendor dashboards.' },
        { title: 'Post-event refund', text: 'Unused balance is refunded automatically to the original payment method.' }
      ] },
      { type: 'features', heading: 'Enterprise features', cols: 3, items: [
        { icon: 'chart', title: 'Real-time sales dashboard', text: 'Every tap, every stall, every rupee, visible live from any device.' },
        { icon: 'wifi-off', title: 'Offline mode', text: 'Payments keep working during network drops and sync once back online.' },
        { icon: 'store', title: 'Multi-vendor management', text: 'Every stall gets its own login and settlement, visible only to that vendor.' },
        { icon: 'shield', title: 'Fraud prevention', text: 'Balance is locked to the registered attendee; lost cards can be blocked instantly.' },
        { icon: 'refund', title: 'Instant refunds & settlement', text: 'Automatic post-event refunds and same-day vendor settlement reports.' },
        { icon: 'bell', title: 'Low-balance alerts', text: 'Attendees are notified before their balance runs out.' }
      ] },
      { type: 'usecases', heading: 'Where it can be used', items: [
        { title: 'Festivals', tags: ['Cashless bars', 'Food stalls', 'Merchandise across zones'] },
        { title: 'Corporate events', tags: ['Cafeteria and refreshment counters'] },
        { title: 'Exhibitions', tags: ['F&B courts', 'Vendor stalls', 'Unified sales tracking'] },
        { title: 'Concerts & sports', tags: ['Fast-moving crowds', 'No cash queues'] },
        { title: 'College fests', tags: ['Preloaded student wristbands'] },
        { title: 'VIP lounges', tags: ['Premium tap-to-pay hospitality'] },
        { title: 'Conferences', tags: ['Networking dinners', 'Refreshment breaks'] },
        { title: 'Medical conferences', tags: ['Delegate meal counters'] }
      ] },
      { type: 'compare', heading: 'Why choose Navon cashless?', left: 'Cash & card handling', right: 'Navon NFC cashless', rows: [
        ['Manual cash counting', 'Instant digital settlement'], ['Long queues', 'Tap & go in seconds'], ['No live sales data', 'Real-time dashboard'],
        ['Cash handling risk', 'Zero cash on site'], ['Manual refunds', 'Automatic post-event refunds'], ['Separate vendor systems', 'One unified platform']
      ] },
      { type: 'faq', heading: 'Cashless payment questions', items: [
        { q: 'Do attendees need a bank account or card?', a: 'No. Attendees top up their NFC wristband, card or sticker at any top-up counter or online before the event.' },
        { q: 'What happens to unused balance?', a: 'Unused balance can be refunded to the attendee\'s original payment method or UPI ID through the same system used for top-ups.' },
        { q: 'Does it work if the internet goes down?', a: 'Yes. POS devices support offline mode and sync all transactions once the connection is restored.' },
        { q: 'Can each vendor see their own sales?', a: 'Yes. Every vendor gets their own login showing only their stall\'s transactions, while organizers see consolidated sales.' },
        { q: 'How many attendees can it handle?', a: 'The platform scales to 50,000+ attendees with bank-grade security.' }
      ] }
    ],
    related: ['/rfid-tracking', '/event-mobile-app', '/automated-flap-barriers', '/platform']
  },

  badges: {
    path: '/badge-printing', section: 'service', icon: 'badge',
    title: 'Event Badge Printing | Materials, Methods & Lanyards | Navon',
    description: 'Event badge printing: PVC, thermal, fan fold and inkjet printing; ivory, eco, non-tearable, PVC, fan fold and transparent sticker badges; custom lanyards and AI art badges.',
    kicker: 'Badge printing', h1: 'The right badge, printed in seconds.',
    lede: 'Verified attendees get a printed badge on the spot at a kiosk, desk or mobile POS. Choose the print technology, material and lanyard that suit your event\'s scale, budget and brand.',
    heroImage: IMG('event-badge-designs.webp'), heroAlt: 'Event badge designs printed by Navon',
    heroChips: ['Verified', 'Printing…', 'Ready'],
    serviceType: 'Event badge printing', whatsappTopic: 'badge printing',
    blocks: [
      { type: 'features', heading: 'Printing methods', intro: 'The right print technology for your badge material and event scale.', cols: 4, items: [
        { icon: 'card', title: 'PVC printing', text: 'Direct-to-card printing for durable, premium plastic badges.' },
        { icon: 'bolt', title: 'Thermal printing', text: 'Fast, ink-free printing for high-volume, high-speed check-in lines.' },
        { icon: 'layers', title: 'Fan fold printing', text: 'Continuous-feed printing for the fastest, most cost-effective output.' },
        { icon: 'brush', title: 'Inkjet printing', text: 'High-resolution colour for detailed badges, passes and branding.' }
      ] },
      { type: 'features', heading: 'Event badge materials', intro: 'Six materials to match your event\'s budget, duration and durability needs.', cols: 3, items: [
        { icon: 'badge', title: 'Ivory paper badge', text: 'Premium matte finish for conferences and exhibitions.' },
        { icon: 'leaf', title: 'Eco-friendly badge', text: 'Sustainable paper for environmentally conscious events.' },
        { icon: 'shield', title: 'Non-tearable paper', text: 'Durable, waterproof paper for multi-day events.' },
        { icon: 'star', title: 'PVC badge', text: 'Premium plastic badges for VIP delegates and staff.' },
        { icon: 'layers', title: 'Fan fold paper', text: 'Continuous perforated badges for fast, low-cost high-volume check-in.' },
        { icon: 'sticker', title: 'Transparent sticker', text: 'Clear adhesive badges that stick to clothing: lightweight and tamper-evident.' }
      ] },
      { type: 'gallery', heading: 'Badges & lanyards we\'ve produced', items: [
        { image: IMG('event-badge-designs.webp'), alt: 'Category badge designs', title: 'Category badges', text: 'Media, partner, delegate and more.' },
        { image: IMG('delegate-all-access-badges.webp'), alt: 'Delegate and all-access badges', title: 'Access badges', text: 'Delegate, all-access and themed designs.' },
        { image: IMG('branded-event-lanyards.webp'), alt: 'Branded event lanyards', title: 'Custom lanyards', text: 'Printed with your event branding.' }
      ] },
      { type: 'features', heading: 'Custom event lanyards', intro: 'Four lanyard styles to match your badge material and brand.', cols: 4, items: [
        { icon: 'link', title: 'Standard lanyard', text: 'Simple, durable polyester for everyday conferences and exhibitions.' },
        { icon: 'brush', title: 'Printed branding lanyard', text: 'Full-colour sponsor and event branding along the full length.' },
        { icon: 'star', title: 'Premium fabric lanyard', text: 'Soft woven fabric for high-profile events.' },
        { icon: 'layers', title: 'Custom event lanyard', text: 'Custom width, colour and hardware built to your brand guide.' }
      ] },
      { type: 'split', heading: 'AI art badges', paras: ['Guests click a photo or scan a QR code to upload, and within seconds receive a hand-drawn style badge with their avatar, name, company and event branding, printed on an RFID or QR badge.'], checks: ['AI converts the photo into illustrated art in under 10 seconds', 'Portrait, name, designation and logo printed live', 'Event theme and sponsor logos blended into the artwork'], image: IMG('ai-art-badge-designs.webp'), alt: 'AI art badge designs', reverse: true }
    ],
    related: ['/smart-kiosks', '/registration-desk', '/mobile-pos', '/event-registration-services']
  },

  /* =================================================================
     PRODUCTS
     ================================================================= */
  platform: {
    path: '/platform', section: 'product', icon: 'layers',
    title: 'Event Management Platform | Registration, Ticketing & CRM',
    description: 'All-in-one event registration software and management platform: ticketing, scientific conference management, AI CRM, hotel and transport, attendee app and analytics on one attendee record.',
    kicker: 'Navon platform', h1: 'Run every event from one intelligent platform.',
    lede: 'From registrations and ticket sales to scientific conference management, AI-powered CRM, hotel bookings, transport coordination and attendee engagement: plan, manage and scale every event from a single cloud platform.',
    heroImage: IMG('event-registration-microsite-example.webp'), heroAlt: 'Event registration microsite built on the Navon platform',
    heroChips: ['Ticket sold', 'Room allocated', 'Reminder sent'],
    serviceType: 'Event registration and management software', whatsappTopic: 'registration & ticketing platform',
    blocks: [
      { type: 'features', heading: 'Every module your event actually needs', intro: 'Mix and match what you need; every module shares the same attendee record.', cols: 3, items: [
        { icon: 'ticket', title: 'Registration & ticketing', text: 'Event, medical conference, workshop, group and VIP registration with ticket selling and secure payments.', tags: ['Discount coupons', 'Promo codes', 'Affiliate links', 'Dynamic pricing'] },
        { icon: 'file', title: 'Scientific conference management', text: 'Built for academic and medical conferences.', tags: ['Abstract submission', 'Reviewer portal', 'Posters', 'Speakers & faculty', 'Scheduling', 'Certificates'] },
        { icon: 'hotel', title: 'Travel & hospitality', text: 'Coordinate every delegate\'s journey.', tags: ['Hotel accommodation', 'Room allocation', 'Airport pickup', 'Shuttles', 'Hospitality desk'] },
        { icon: 'bot', title: 'AI CRM & marketing', text: 'Automate follow-ups and close more leads.', tags: ['AI WhatsApp bot', 'AI voice calling', 'Email', 'SMS', 'Lead management', 'Reminders'] },
        { icon: 'phone', title: 'Attendee experience', text: 'Event mobile app and AI photo sharing, plus personalised agenda, networking, digital badges, push notifications and live polls.' },
        { icon: 'chart', title: 'Analytics & reporting', text: 'Registration dashboard, ticket sales, revenue, marketing performance, attendance and custom reports.' }
      ] },
      { type: 'compare', heading: 'Why run your event on one platform?', left: 'Without one platform', right: 'With Navon', rows: [
        ['Spreadsheets and manual re-entry', 'One attendee record, one source of truth'], ['Six logins to manage', 'One login for every module'], ['Same delegate data typed again and again', 'Enter data once, it syncs everywhere'], ['No single report across modules', 'One live dashboard and one support team']
      ] },
      { type: 'split', heading: 'Sell tickets. Book stays. Manage every journey.', paras: ['Simplify the entire attendee experience with online ticketing, hotel reservations, transport coordination and secure payments, designed for conferences, exhibitions and large-scale events.'], checks: ['Online ticket sales & registration', 'Hotel & accommodation booking', 'Airport pickup & shuttle management', 'Secure payment gateway integration', 'Discount coupons & dynamic pricing', 'WhatsApp AI assistant & notifications', 'Real-time dashboard & revenue analytics'], image: IMG('event-dashboard-combined-report.webp'), alt: 'Navon platform reporting dashboard', reverse: true },
      { type: 'chips', heading: 'Built for', items: ['Medical & scientific conferences', 'Corporate events', 'Exhibitions', 'Associations & universities'] },
      { type: 'faq', heading: 'Platform questions', items: [
        { q: 'Do we have to use every module?', a: 'No. Every module works independently. Most organizers start with one or two and add more as needed, all on the same attendee record.' },
        { q: 'Does data stay in sync across modules?', a: 'Yes. Registration, badge, travel and engagement data all link back to a single attendee profile.' },
        { q: 'Is it suitable for scientific and medical conferences?', a: 'Yes. Abstract submission, reviewer workflows, poster management, faculty and session scheduling, and certificate generation are built in.' },
        { q: 'What event sizes does it support?', a: 'The platform scales from a 500-attendee single-day event to a 20,000+ attendee multi-day, multi-venue conference.' }
      ] }
    ],
    related: ['/online-event-registration', '/event-mobile-app', '/ai-photo-sharing', '/event-registration-services']
  },

  app: {
    path: '/event-mobile-app', section: 'product', icon: 'phone',
    title: 'Event Mobile App | Branded Attendee App with Live Agenda',
    description: 'Navon event mobile app: personalised agenda, live polls and Q&A, AI networking, push notifications, exhibitor directory, gamification and offline access, fully branded for your event.',
    kicker: 'Event mobile app', h1: 'One app. Every attendee need.',
    lede: 'Give attendees a personalised agenda, live polls, networking and real-time updates in one fully branded event app. No generic marketplace download, no separate login for every feature.',
    heroImage: IMG('mobile-event-app-home-screen.webp'), heroAlt: 'Navon event mobile app home screen', heroPhone: true,
    heroChips: ['Session starting soon', 'New match found', 'Live poll results'],
    serviceType: 'Event mobile app', whatsappTopic: 'event mobile app',
    blocks: [
      { type: 'steps', heading: 'From setup to engagement', items: [
        { title: 'Setup', text: 'Organizers configure the agenda, speakers, sponsors and branding in the admin dashboard.' },
        { title: 'Download & access', text: 'Attendees download the branded app or open the lightweight web app via QR code.' },
        { title: 'Engage', text: 'Personalised agenda, live polls, networking and push notifications keep attendees engaged.' },
        { title: 'Analyse', text: 'Real-time engagement analytics and a full post-event report.' }
      ] },
      { type: 'features', heading: 'Everything an event app needs', cols: 3, items: [
        { icon: 'calendar', title: 'Personalised agenda', text: 'Every attendee sees only the sessions and tracks relevant to them.' },
        { icon: 'bell', title: 'Push notifications', text: 'Session reminders and last-minute changes reach every phone instantly.' },
        { icon: 'users', title: 'AI networking & matchmaking', text: 'Suggested connections based on interests, role or industry.' },
        { icon: 'chart', title: 'Live polls & Q&A', text: 'Real-time audience input without passing a microphone.' },
        { icon: 'qr', title: 'Digital badge & QR check-in sync', text: 'Profile and check-in status linked to the same record.' },
        { icon: 'store', title: 'Sponsor & exhibitor directory', text: 'Searchable directory with booth locations and enquiry buttons.' },
        { icon: 'star', title: 'Gamification & leaderboard', text: 'Points for check-ins, polls and booth visits.' },
        { icon: 'wifi-off', title: 'Offline access', text: 'Agenda, maps and speaker bios available without a connection.' },
        { icon: 'globe', title: 'Multi-language support', text: 'Serve a global or regional audience in their own language.' }
      ] },
      { type: 'compare', heading: 'Why the Navon event app?', left: 'Typical event apps', right: 'Navon', rows: [
        ['Generic templates', 'Fully branded app'], ['Static PDF agenda', 'Live personalised agenda'], ['No attendee insights', 'Real-time engagement analytics'], ['Manual networking', 'AI-matched networking'],
        ['Separate check-in system', 'Synced badge & QR check-in'], ['One-way notifications', 'Two-way live polls & Q&A'], ['No offline mode', 'Full offline access']
      ] },
      { type: 'usecases', heading: 'Built for every event format', items: [
        { title: 'Corporate conferences', tags: ['Multi-track agendas', 'Speaker bios', 'Session reminders'] },
        { title: 'Trade shows & exhibitions', tags: ['Exhibitor directory', 'Floor map'] },
        { title: 'Multi-day summits', tags: ['Full agenda and updates across days'] },
        { title: 'Hybrid & virtual events', tags: ['Live streams', 'Polls', 'Q&A'] },
        { title: 'University fests & convocations', tags: ['Schedules', 'Campus maps', 'Club directories'] },
        { title: 'Music festivals', tags: ['Set times', 'Stage maps', 'Live lineups'] }
      ] },
      { type: 'faq', heading: 'App questions', items: [
        { q: 'Do attendees need to create an account?', a: 'No. The app can log attendees in automatically using their existing registration details.' },
        { q: 'Does the app work offline?', a: 'Yes. Agenda, speaker bios and maps are available offline; live features like polls need a connection.' },
        { q: 'Can the app be fully branded?', a: 'Yes. Logo, colours, splash screen and app name are customised per event.' },
        { q: 'Is it on iOS and Android?', a: 'Yes, plus a lightweight web app for attendees who prefer not to install anything.' }
      ] }
    ],
    related: ['/platform', '/ai-photo-sharing', '/nfc-payments', '/online-event-registration']
  },

  photos: {
    path: '/ai-photo-sharing', section: 'product', icon: 'camera',
    title: 'AI Event Photo Sharing | Instant Selfie-Matched Galleries',
    description: 'AI event photo sharing: attendees scan a QR code, take a selfie and instantly get a private gallery of their event photos. No app, no scrolling. WhatsApp and email delivery.',
    kicker: 'AI photo sharing', h1: 'Every moment. Instantly found.',
    lede: 'Deliver personalised event photos in seconds with AI face recognition. Attendees scan a QR code, take a selfie and instantly access their private gallery: no app downloads, no endless scrolling.',
    heroGallery: true,
    heroChips: ['Scan & selfie', 'Face matched', 'Gallery delivered'],
    serviceType: 'AI event photo sharing', whatsappTopic: 'AI photo sharing',
    blocks: [
      { type: 'steps', heading: 'From capture to connection', items: [
        { title: 'Capture', text: 'Professional photographers capture moments throughout the event.' },
        { title: 'Upload', text: 'Photos sync automatically from camera, laptop or cloud to the Navon AI platform.' },
        { title: 'Find', text: 'Attendees scan a QR code, take a selfie, and AI securely matches their photos.' },
        { title: 'Share', text: 'Private galleries are instantly available to download, share or post.' }
      ] },
      { type: 'features', heading: 'Everything an event photo gallery needs', cols: 3, items: [
        { icon: 'face', title: 'AI face recognition', text: 'Find photos instantly with a selfie.' },
        { icon: 'qr', title: 'QR code access', text: 'No app installation: scan and go straight to the gallery.' },
        { icon: 'lock', title: 'Private galleries', text: 'Each attendee only sees their own photos.' },
        { icon: 'download', title: 'HD downloads', text: 'Original-quality downloads.' },
        { icon: 'monitor', title: 'Live event gallery', text: 'Curated highlights on event screens while personal galleries stay private.' },
        { icon: 'bolt', title: 'Real-time delivery', text: 'Within seconds, or after organizer review.' },
        { icon: 'users', title: 'Multi-photographer support', text: 'Uploads merged into one library.' },
        { icon: 'brush', title: 'Branded experience', text: 'Custom domain, logo, overlays and branded galleries.' },
        { icon: 'wa', title: 'WhatsApp & email delivery', text: 'Automatic notification when new photos are ready.' }
      ] },
      { type: 'chips', heading: 'Search any way attendees prefer', items: ['Face recognition', 'QR code', 'Registration ID', 'Badge number', 'Mobile number', 'Email'] },
      { type: 'features', heading: 'Privacy-first, consent-based', cols: 4, items: [
        { icon: 'check', title: 'Consent-based matching', text: 'Face matching only with consent.' },
        { icon: 'lock', title: 'Encrypted storage', text: 'Secure cloud infrastructure.' },
        { icon: 'users', title: 'Role-based access', text: 'Controlled access for organizers.' },
        { icon: 'clock', title: 'Retention controls', text: 'Automatic data retention controls.' }
      ] },
      { type: 'faq', heading: 'Photo sharing questions', items: [
        { q: 'Do attendees need an app?', a: 'No. They scan a QR code, take a selfie in their browser and their private gallery opens instantly.' },
        { q: 'Can other attendees see my photos?', a: 'No. Matching is consent-based and every gallery is private.' },
        { q: 'How fast are photos available?', a: 'Within seconds of upload, or after organizer review, depending on the delivery mode you choose.' },
        { q: 'How are attendees notified?', a: 'By WhatsApp and email the moment new matching photos are added.' }
      ] }
    ],
    related: ['/event-mobile-app', '/face-recognition', '/platform', '/ai-experiences']
  },

  /* =================================================================
     SOLUTION PAGES (search-intent pages)
     ================================================================= */
  online: {
    path: '/online-event-registration', section: 'solution', icon: 'form',
    title: 'Online Event Registration | Forms, Ticketing & QR E-badges',
    description: 'Online event registration with custom forms, event microsites, medical and corporate registration, ticketing and payments, and QR e-badges delivered by WhatsApp and email.',
    kicker: 'Online event registration', h1: 'Online registration that runs itself.',
    lede: 'A dedicated event microsite enables quick, hassle-free registration with automated confirmations, and every delegate receives a unique QR e-badge before they arrive.',
    heroImage: IMG('e-badge-invitation-qr-code.webp'), heroAlt: 'Personalised e-badge invitation with QR code', heroPhone: true,
    heroChips: ['Registered', 'QR sent on WhatsApp'],
    serviceType: 'Online event registration', whatsappTopic: 'online event registration',
    blocks: [
      { type: 'features', heading: 'Registration types', cols: 3, items: [
        { icon: 'med', title: 'Medical registration', text: 'Forms for medical events with council compliance, attendance tracking and certification points.' },
        { icon: 'ticket', title: 'Corporate ticketing', text: 'Personalised categories, secure payments and automated confirmations.' },
        { icon: 'form', title: 'General events', text: 'Customisable forms, quick sign-up and session selection.' },
        { icon: 'users', title: 'Group & VIP registration', text: 'Register groups and VIPs with their own flows.' },
        { icon: 'calendar', title: 'Workshop registration', text: 'Workshop and session selection at registration.' },
        { icon: 'percent', title: 'Coupons & dynamic pricing', text: 'Discount coupons, promo codes, affiliate links and dynamic pricing.' }
      ] },
      { type: 'split', heading: 'Pre-event communication, built in', paras: ['Registration doesn\'t end at the submit button. Attendees get what they need on the channels they already use.'], checks: ['Unique QR e-badge by WhatsApp & email', 'Pre-event instructions and event details', 'Real-time updates and reminders', 'AI WhatsApp assistant for attendee questions'], image: IMG('personalised-e-badge-qr-code.webp'), alt: 'Personalised e-badge with QR code', reverse: true }
    ],
    related: ['/platform', '/qr-code-tracking', '/event-registration-services', '/event-mobile-app']
  },

  checkin: {
    path: '/event-check-in-software', section: 'solution', icon: 'check',
    title: 'Event Check-in Software | QR, Face, RFID & Kiosk Check-in',
    description: 'Event check-in software compared: self-service kiosks, staffed desks, mobile POS, QR codes, face recognition, RFID and flap barriers. Under 10-second check-in on one platform.',
    kicker: 'Event check-in', h1: 'Choose how attendees check in.',
    lede: 'Kiosk, desk, handheld, QR, face or RFID: Navon runs every check-in method on one platform, so you can mix them by entrance and attendee type, with every scan in the same live dashboard.',
    heroImage: IMG('attendee-using-registration-kiosk.webp'), heroAlt: 'Attendee checking in at a Navon kiosk',
    heroChips: ['Under 10 seconds'],
    serviceType: 'Event check-in software', whatsappTopic: 'event check-in',
    blocks: [
      { type: 'table', heading: 'Check-in methods compared', head: ['Method', 'How it works', 'Best for'], rows: [
        ['Smart kiosk', 'Attendee scans QR and prints their own badge on a dual-screen kiosk', 'Morning rush, self-service'],
        ['Registration desk', 'Trained staff search, verify and print badges', 'Walk-ins, VIPs, speakers'],
        ['Mobile POS', 'Handheld device with built-in label printer', 'Overflow queues, satellite entrances'],
        ['QR code', 'Unique e-badge scanned at entry and checkpoints', 'Fast roll-out for any event'],
        ['Face recognition', 'Camera matches the registered face in under a second', 'Touch-free, high-security entry'],
        ['RFID', 'Badge or wristband read without line of sight', 'High-volume and multi-day events'],
        ['Flap barriers', 'Gates open only for verified attendees', 'Controlled zones and venues']
      ] },
      { type: 'gallery', heading: 'Check-in hardware', items: [
        { image: IMG('self-service-registration-kiosk.webp'), alt: 'Smart kiosk', title: 'Smart kiosks', text: 'Self check-in with instant badges.' },
        { image: IMG('facial-recognition-check-in-tablet.webp'), alt: 'Face recognition device', title: 'Face recognition', text: 'Sub-second AI verification.' },
        { image: IMG('flap-barrier-smart-entry-gates.webp'), alt: 'Flap barrier gates', title: 'Flap barriers', text: 'Smart access control.' }
      ] }
    ],
    related: ['/smart-kiosks', '/face-recognition', '/qr-code-tracking', '/registration-desk']
  },

  delegate: {
    path: '/delegate-management', section: 'solution', icon: 'route',
    title: 'Delegate Management | Attendance, Meals, Kits & Certificates',
    description: 'Delegate management for conferences: session and CME attendance, duplicate-free food and kit distribution, gift tracking, certificates and restricted-zone access with QR, RFID or NFC.',
    kicker: 'Delegate management', h1: 'Every delegate, accounted for.',
    lede: 'Once badged, the same identity tracks sessions, meals, kits, gifts and certificates. Organizers see exactly who received what, and where delegates are, while the event is still running.',
    heroImage: IMG('delegate-tracking-checkpoint.webp'), heroAlt: 'Delegate tracking checkpoint at a conference',
    heroChips: ['Kit collected', 'Lunch scanned', 'Session logged'],
    serviceType: 'Delegate management', whatsappTopic: 'delegate management',
    blocks: [
      { type: 'features', heading: 'What delegate management covers', cols: 3, items: [
        { icon: 'session', title: 'Session & hall attendance', text: 'Attendees tap or scan at session doors; participation is recorded automatically.' },
        { icon: 'cert', title: 'CME / CPD & certificates', text: 'Attendance per session for CME tracking and attendance certificates.' },
        { icon: 'food', title: 'Food distribution', text: 'Controlled meal access across breakfast, lunch and dinner.' },
        { icon: 'kit', title: 'Kit distribution', text: 'Welcome kits and conference bags collected once per delegate.' },
        { icon: 'gift', title: 'Gift & merchandise', text: 'Duplicate collection prevented at every counter.' },
        { icon: 'shield', title: 'Restricted zones', text: 'Faculty lounges, VIP areas and workshops for authorised delegates only.' }
      ] },
      { type: 'stats', items: [{ value: 'QR · RFID · NFC', label: 'Any badge technology' }, { value: 'Live', label: 'Attendance and distribution data' }, { value: '1', label: 'Attendee record across the event' }] }
    ],
    related: ['/rfid-tracking', '/qr-code-tracking', '/event-registration-services', '/platform']
  },

  corporate: {
    path: '/corporate-event-technology', section: 'solution', icon: 'building',
    title: 'Corporate Event Technology | Registration to Engagement',
    description: 'Corporate event technology from Navon: ticketing, branded microsites, kiosks and face recognition check-in, AI engagement experiences and live reporting for summits and annual meets.',
    kicker: 'For corporate events', h1: 'Corporate events, handled end to end.',
    lede: 'Corporate summits, town halls, product launches and annual meetings run on one platform: registration and ticketing, fast check-in, engagement experiences and live reporting.',
    heroImage: IMG('onsite-registration-desk-corporate-event.webp'), heroAlt: 'Registration at a corporate event',
    heroChips: ['Welcome, delegate'],
    serviceType: 'Corporate event technology', whatsappTopic: 'corporate event technology',
    blocks: [
      { type: 'features', heading: 'Built for business events', cols: 3, items: [
        { icon: 'ticket', title: 'Registration & ticketing', text: 'Corporate ticketing with categories, payments and confirmations.', href: '/platform' },
        { icon: 'kiosk', title: 'Fast check-in', text: 'Kiosks, desks and face recognition at the door.', href: '/event-check-in-software' },
        { icon: 'phone', title: 'Event mobile app', text: 'Agenda, networking and live polls.', href: '/event-mobile-app' },
        { icon: 'bot', title: 'AI experiences', text: 'AI robot anchor, hologram box, AI photo booth and more.', href: '/ai-experiences' },
        { icon: 'camera', title: 'AI photo sharing', text: 'Every guest gets their own photos the same day.', href: '/ai-photo-sharing' },
        { icon: 'chart', title: 'Live reporting', text: 'Attendance and engagement while the event runs.', href: '/event-registration-services' }
      ] },
      { type: 'clients', heading: 'Trusted by corporate and technology teams', sectors: ['Technology', 'Corporate'] }
    ],
    related: ['/platform', '/ai-experiences', '/face-recognition', '/case-studies']
  }
};

/** AI experiences (live site: "Beyond check-in"). Shown on the AI Experiences page. */
const experiences = [
  { id: 'ai-robot-anchor', name: 'AI robot anchor', sub: 'Interactive robotics', text: 'An interactive AI robot host that welcomes, guides and engages event attendees. It anchors, speaks and engages audiences.', image: IMG('next-gen-ai-robot.webp') },
  { id: 'hologram-box', name: 'Hologram box', sub: 'Holographic display', text: 'A holographic character that represents your brand, welcoming guests and presenting sponsors.', image: IMG('hologram-box-brand-character.webp') },
  { id: 'ai-photo-booth', name: 'AI photo booth', sub: 'Instant prints', text: 'AI-powered photo booth with virtual backgrounds, avatars and social media sharing.', image: IMG('ai-photo-booth.webp') },
  { id: 'sketch-ai-robot', name: 'Sketch AI robot', sub: 'AI illustration', text: 'Turns a guest\'s photo into an AI-generated sketch to take home.', image: IMG('sketch-ai-robot.webp') },
  { id: 'digital-mosaic-wall', name: 'Digital mosaic wall', sub: 'Live photo mosaic', text: 'A live photo mosaic wall displaying attendee photos and social media posts in real time.', image: IMG('digital-mosaic-wall-conference.webp') },
  { id: 'social-media-wall', name: 'Social media wall', sub: 'Live feed', text: 'Display live social media posts, hashtags and attendee interactions on large screens.', image: null },
  { id: 'ar-vr-gaming', name: 'AR / VR gaming', sub: 'Immersive play', text: 'Immersive AR and VR games designed to attract crowds and increase booth engagement.', image: null },
  { id: 'digital-lucky-draw', name: 'Digital lucky draw', sub: 'On-screen draws', text: 'Instant, fair, on-screen prize draws.', image: IMG('digital-lucky-draw-screen.webp') },
  { id: 'virtual-catalogue', name: 'Virtual catalogue', sub: 'Digital showcase', text: 'A digital showcase of products and sponsors.', image: IMG('virtual-catalogue-display.webp') },
  { id: 'freezing-photo-booth', name: 'Freezing photo booth', sub: 'Bullet-time capture', text: 'Bullet-time photo capture for a shareable, crowd-pulling moment.', image: null },
  { id: 'podcast-kiosk', name: 'Podcast kiosk', sub: 'Branded content', text: 'A podcast recording kiosk for branded content.', image: null },
  { id: 'branded-games', name: 'Branded games', sub: 'Touch-screen play', text: 'Touch-screen quizzes, spin-to-win and more.', image: IMG('branded-touchscreen-game.webp') }
];

/** Industries, combined from use-case sections across navoninnovations.com. */
const industries = [
  { title: 'Conferences', icon: 'mic', uses: ['Delegate check-in', 'Speaker registration', 'VIP access', 'Workshop attendance'] },
  { title: 'Medical conferences', icon: 'med', uses: ['CME tracking', 'Faculty & delegate access', 'Abstracts & posters', 'Meal counters'] },
  { title: 'Exhibitions & trade shows', icon: 'store', uses: ['Visitor entry', 'Booth analytics & heatmaps', 'Lead retrieval', 'Exhibitor access'] },
  { title: 'Corporate events', icon: 'building', uses: ['Annual meetings', 'Leadership summits', 'Town halls', 'Training programmes'] },
  { title: 'Government events', icon: 'shield', uses: ['Authorised entry', 'High-security gates', 'VIP movement', 'Restricted access'] },
  { title: 'Universities', icon: 'cap', uses: ['Convocation', 'Student verification', 'Exam attendance', 'Visitor management'] },
  { title: 'Festivals & concerts', icon: 'music', uses: ['Cashless wristbands', 'Crowd counts per zone', 'VIP & artist entry', 'Re-entry control'] },
  { title: 'Stadiums & sports', icon: 'trophy', uses: ['Gate entry', 'Media & backstage access', 'Cashless counters', 'Live scores in the app'] }
];

const byPath = Object.fromEntries(Object.values(pages).map((p) => [p.path, p]));
const CONTENT_UPDATED = '2026-11-16';


/* Home and services hub: the ten core capabilities, each with its own animated visual */
const showcase = [
  { kind: 'online', title: 'Online event registration', text: 'Custom forms, event microsites, ticketing and QR e-badges delivered by WhatsApp and email.', href: '/online-event-registration' },
  { kind: 'onsite', title: 'Onsite registration', text: 'Self-service kiosks, staffed desks and mobile POS get attendees in within 10 seconds.', href: '/event-registration-services' },
  { kind: 'face', title: 'Facial recognition', text: 'Sub-second, contactless verification at the gate. No QR, no badge search, no manual checks.', href: '/face-recognition', size: 'wide' },
  { kind: 'qr', title: 'QR code check-in', text: 'A unique QR e-badge for fast gate entry at kiosks, counters and flap barriers.', href: '/event-check-in-software' },
  { kind: 'rfid', title: 'RFID & NFC technology', text: 'Check-in without line of sight, live movement tracking and tap-to-pay cashless wristbands.', href: '/rfid-tracking' },
  { kind: 'badge', title: 'Smart badge printing', text: 'PVC, thermal and inkjet badges printed on the spot, with custom lanyards and AI art badges.', href: '/badge-printing' },
  { kind: 'delegate', title: 'Delegate tracking', text: 'Session attendance, zone movement and restricted-area access on one attendee record.', href: '/delegate-management' },
  { kind: 'food', title: 'Food & session scanning', text: 'Duplicate-free meal, kit and gift distribution, plus session and hall attendance.', href: '/qr-code-tracking' },
  { kind: 'app', title: 'Event apps', text: 'A branded attendee app with live agenda, polls, AI networking and push notifications.', href: '/event-mobile-app' },
  { kind: 'analytics', title: 'Real-time analytics', text: 'Live dashboards for registrations, entries, sessions and zones while the event is running.', href: '/platform', size: 'wide' }
];

/* Homepage: the eight-step event ecosystem */
const ecosystem = [
  { kind: 'online', icon: 'layers', title: 'Registration & Ticketing', text: 'Custom forms, ticketing and payments on a branded event microsite.', href: '/online-event-registration' },
  { kind: 'badge', icon: 'print', title: 'Smart Badge Printing', text: 'Badges printed on the spot at kiosks, staffed desks or mobile POS.', href: '/badge-printing' },
  { kind: 'face', icon: 'face', title: 'QR & Face Recognition Check-in', text: 'Entry in under 10 seconds with a QR e-badge or a face match.', href: '/event-check-in-software' },
  { kind: 'rfid', icon: 'rfid', title: 'RFID & NFC Access', text: 'Contactless zone access, live movement tracking and cashless payments.', href: '/rfid-tracking' },
  { kind: 'app', icon: 'phone', title: 'Attendee Engagement', text: 'A branded app with agenda, live polls, AI networking and AI experiences.', href: '/event-mobile-app' },
  { kind: 'photos', icon: 'camera', title: 'AI Photo Sharing', text: 'Selfie-matched photo galleries delivered on WhatsApp and email.', href: '/ai-photo-sharing' },
  { kind: 'food', icon: 'food', title: 'Session & Food Tracking', text: 'Session attendance plus duplicate-free meal, kit and gift distribution.', href: '/delegate-management' },
  { kind: 'analytics', icon: 'chart', title: 'Live Analytics & Reporting', text: 'Live dashboards while the event runs, and full reports after it.', href: '/platform' }
];

/* Homepage: technology cards */
const technology = [
  { kind: 'online', title: 'Smart Registration', text: 'Custom registration forms, branded microsites, ticketing and payments, with QR e-badges sent by WhatsApp and email.', href: '/online-event-registration' },
  { kind: 'onsite', title: 'Smart Kiosks', text: 'Dual-screen self-registration kiosks: scan a QR code, print a badge instantly and sync to the live database.', href: '/smart-kiosks' },
  { kind: 'face', title: 'Face Recognition', text: 'Sub-second AI verification for contactless check-in, automatic badge printing and turnstile access.', href: '/face-recognition' },
  { kind: 'rfid', title: 'RFID Solutions', text: 'Check-in without line of sight, live attendee movement, session attendance and duplicate-free distribution.', href: '/rfid-tracking' },
  { kind: 'nfc', title: 'NFC Technology', text: 'Tap-to-pay wristbands, cards and stickers with vendor POS, automatic refunds and a live sales dashboard.', href: '/nfc-payments' },
  { kind: 'gate', title: 'Access Control', text: 'Flap barriers and turnstiles with face, QR, NFC and RFID, anti-tailgating and role-based zones.', href: '/automated-flap-barriers' },
  { kind: 'app', title: 'Event Mobile Application', text: 'Personalised agenda, live polls and Q&A, AI networking and push notifications in a fully branded app.', href: '/event-mobile-app' },
  { kind: 'photos', title: 'AI Photo Sharing', text: 'Attendees scan a QR code, take a selfie and instantly get a private gallery of their event photos.', href: '/ai-photo-sharing' },
  { kind: 'assistant', title: 'AI Event Assistant', text: 'A WhatsApp AI assistant built into the Navon platform to answer attendee questions around the clock.', href: '/platform' },
  { kind: 'analytics', title: 'Live Event Analytics', text: 'Real-time dashboards for registrations, entries, sessions and zones, plus post-event reports.', href: '/platform' }
];

/* Homepage: industries with event photography from Navon deployments */
const homeIndustries = [
  { title: 'Medical & Healthcare Conferences', anchor: 'medical-conferences', image: IMG('attendee-using-registration-kiosk.webp'), alt: 'Delegate using a Navon self-registration kiosk', uses: ['CME tracking', 'Faculty & delegate access', 'Meal counters'] },
  { title: 'Corporate Events', anchor: 'corporate-events', image: IMG('event-registration-counter-team.webp'), alt: 'Navon onsite registration team at a corporate summit', uses: ['Leadership summits', 'Annual meetings', 'Town halls'] },
  { title: 'Exhibitions & Trade Shows', anchor: 'exhibitions-trade-shows', image: IMG('infocom-2025-event.webp'), alt: 'INFOCOM 2025 event powered by Navon', uses: ['Visitor entry', 'Booth analytics', 'Lead retrieval'] },
  { title: 'Government Events', anchor: 'government-events', image: IMG('flap-barrier-entry-event-venue.webp'), alt: 'Automated flap barriers at an event entrance', uses: ['Authorised entry', 'High-security gates', 'VIP movement'] },
  { title: 'Technology Summits', anchor: 'conferences', image: IMG('github-2026-registration-desk-bengaluru.webp'), alt: 'Registration desk at GitHub 2026, Bengaluru', uses: ['Delegate check-in', 'Speaker registration', 'Workshop attendance'] },
  { title: 'Concerts & Large-Scale Events', anchor: 'festivals-concerts', image: IMG('attendee-check-in-device-scan.webp'), alt: 'Handheld device scanning an attendee pass', uses: ['Cashless wristbands', 'Crowd counts per zone', 'Re-entry control'] }
];

module.exports = { showcase, ecosystem, technology, homeIndustries, pages, experiences, industries, byPath, CONTENT_UPDATED };
