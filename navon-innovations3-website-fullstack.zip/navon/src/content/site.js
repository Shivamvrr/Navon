'use strict';
/**
 * Navon Innovations company facts — single source of truth for page copy and
 * structured data. Sources: navoninnovations.com (live site, November 2026) and the
 * Navon Innovations company profile. Do not add claims that are not documented there.
 */
const company = {
  name: 'Navon Innovations',
  legalName: 'Navon Innovations',
  tagline: 'Powering smarter events.',
  descriptor: 'Event registration, access control and AI engagement technology',
  description: 'Navon Innovations is a technology-driven event solutions company delivering registration, ticketing, badge printing, RFID/NFC, kiosks, mobile apps and onsite operations on one unified platform.',
  vision: 'To become India\'s most trusted event technology partner by delivering innovative, scalable and reliable solutions that transform the way events are planned and executed.',
  mission: 'To simplify event management through intelligent technology, experienced people and exceptional execution — helping every organizer deliver outstanding event experiences from registration to completion.',
  website: 'https://navoninnovations.com',
  logo: '/img/navon-innovations-logo.webp',
  areaServed: 'India',
  foundingDate: '2025-01-01',
  social: [
    { name: 'LinkedIn', url: 'https://www.linkedin.com/company/navon-innovation/' },
    { name: 'Instagram', url: 'https://www.instagram.com/navoninnovation/' }
  ],
  address: {
    street: 'Ground Floor, Meer Singh Complex, Plot No 04, Block A, Sector 08, Dwarka',
    city: 'New Delhi',
    region: 'Delhi',
    postalCode: '110075',
    country: 'IN',
    display: 'Ground Floor, Meer Singh Complex, Plot No 04, Block A, Sector 08, Dwarka, New Delhi 110075'
  },
  phones: ['+91 96544 96952'],
  emails: ['sales@navoninnovations.com', 'naveen@navoninnovations.com', 'aftab@navoninnovations.com']
};

/** Headline numbers as published on navoninnovations.com */
const stats = [
  { value: '350+', count: 350, suffix: '+', label: 'Enterprise events delivered' },
  { value: '3.5L+', count: 3.5, suffix: 'L+', decimals: 1, label: 'Attendees processed' },
  { value: '< 10 sec', label: 'Self check-in via QR, RFID or face match' },
  { value: 'Pan India', label: 'Deployments' }
];

const timeline = [
  { when: 'Nov 2024', what: 'Platform development began' },
  { when: '5', what: 'Pilot projects delivered under real event conditions' },
  { when: '1 Jan 2025', what: 'Official launch of operations' }
];

const team = {
  leadership: [
    { name: 'Naveen Kumar', role: 'CEO & Co-Founder', text: 'Leads business strategy, enterprise partnerships, client success and overall organizational growth.' },
    { name: 'Aftab Khan', role: 'CTO & Co-Founder', text: 'Leads technology strategy, product development, cloud infrastructure, platform innovation and enterprise integrations.' }
  ],
  core: [
    { name: 'Ahmed Ali', role: 'Sales Manager', text: 'Enterprise sales, business development, client relationships and strategic partnerships.' },
    { name: 'Vishal Chandeliya', role: 'Project & Operations Manager', text: 'Project planning, onsite execution, logistics coordination and operational delivery.' },
    { name: 'Sameer Malik', role: 'Operations Manager', text: 'Field operations, registration teams, deployment planning and event execution.' },
    { name: 'Vivek Tiwari', role: 'Senior Full Stack Developer', text: 'Enterprise web applications, registration platforms, APIs, dashboards and backend systems.' },
    { name: 'Prashant Yadav', role: 'Mobile Application Developer', text: 'Android and iOS event applications, attendee engagement features and mobile solutions.' }
  ],
  extended: 'Behind every event is an extended operations team of project coordinators, registration executives, badge printing specialists, RFID engineers, kiosk operators, technical support engineers, quality assurance specialists, logistics coordinators and onsite deployment staff.'
};

const projects = {
  featured: [
    { name: 'AHAR 2026', attendees: '2,50,000', count: 250000, city: 'New Delhi' },
    { name: 'Global Garba Festival 2025', attendees: '12,000', count: 12000, city: 'New Delhi' },
    { name: 'India International Science Festival 2025', attendees: '10,000', count: 10000, city: 'Panchkula, Haryana' }
  ],
  recent: [
    { name: 'AWS 2026', city: 'New Delhi', attendees: '1,500' },
    { name: 'GitHub 2026', city: 'Bengaluru', attendees: '1,200' },
    { name: 'Cisco 2026', city: 'Mumbai', attendees: '1,200' },
    { name: 'KPMG 2025', city: 'New Delhi', attendees: '1,200' },
    { name: 'Vodafone 2026', city: 'Mumbai', attendees: '700' },
    { name: 'INFOCOM 2025', city: 'Mumbai, Delhi, Kolkata', attendees: '500' }
  ],
  note: 'Selected projects. Event details and attendee figures as listed in Navon Innovations\' project records.'
};

/** Clients and events, as listed on navoninnovations.com and in the company profile. */
const clients = [
  { sector: 'Technology', icon: 'chip', names: ['Google', 'Google Startup Summit', 'AWS', 'Cisco', 'GitHub Universe', 'Shiprocket', 'Elite CISOs', 'INFOCOM ABP'] },
  { sector: 'Corporate', icon: 'building', names: ['HSBC', 'KPMG', 'Vodafone', 'Lenovo', 'Carrier Midea India', 'SIS', 'NAREDCO', 'BTPT Ignite'] },
  { sector: 'Medical', icon: 'med', names: ['ERS', 'ESR India Summit', 'MIDCIPS 2025', 'Winter IIRSI', 'RGCON', 'Cancer Connect', 'Oncology Update', 'UPORTHOCON'] },
  { sector: 'Exhibitions & festivals', icon: 'globe', names: ['AHAR', 'IISF', 'Global Garba Festival', 'Lucknow Architecture Festival', 'National Education Conclave', 'Startup Conclave'] },
  { sector: 'Event agency partners', icon: 'people', names: ['Wizcraft', 'Fusion Eventz', 'CWS Events & Exhibitions', 'Expression360', 'IMFervent', 'XPERIA Group', 'Crazy Nib'] }
];

const faqs = [
  { q: 'How fast can Navon deploy for our event?', a: 'Most deployments — kiosks, RFID gates and the registration platform — are configured and on-site within 5-10 business days of confirmation, depending on attendee scale and custom branding requirements.' },
  { q: 'Can it handle 50,000+ attendees across multiple days?', a: 'Yes. The platform is built for multi-day, multi-track enterprise events and has processed 3.5L+ attendees across 350+ events, including large-scale exhibitions and government summits.' },
  { q: 'Do you integrate with our existing CRM or payment gateway?', a: 'Yes — the registration platform supports CRM automation, WhatsApp bots, and secure payment gateway integrations, so attendee data flows straight into the systems your sales and operations teams already use.' },
  { q: 'What happens to attendee data after the event?', a: 'You retain full ownership. Data is exportable to your dashboard and CRM, with real-time analytics available during the event and full reports afterward.' },
  { q: 'Can you support events outside Delhi NCR?', a: 'Yes — we deploy pan-India, including multi-city and multi-day exhibitions and conferences.' }
];

const eventTypes = ['Corporate event', 'Conference', 'Medical conference', 'Exhibition / trade show', 'Government event', 'University / convocation', 'Festival / concert', 'Other'];
const attendeeRanges = ['Up to 500', '500 – 2,000', '2,000 – 10,000', '10,000 – 50,000', '50,000+'];

/** Navigation. Services, Products and AI Experiences are separate sections. */
const nav = {
  services: [
    { group: 'Registration & check-in', items: [
      { href: '/event-registration-services', label: 'Onsite registration', desc: 'The complete check-in and badge system', icon: 'desk' },
      { href: '/smart-kiosks', label: 'Smart kiosks', desc: 'Self check-in with instant badge printing', icon: 'kiosk' },
      { href: '/registration-desk', label: 'Registration desk', desc: 'Staffed counters for fast onsite check-in', icon: 'people' },
      { href: '/mobile-pos', label: 'Mobile POS', desc: 'Handheld registration, anywhere on-site', icon: 'print' },
      { href: '/badge-printing', label: 'Badge printing', desc: 'Printing methods, materials and lanyards', icon: 'badge' }
    ] },
    { group: 'Access control & tracking', items: [
      { href: '/face-recognition', label: 'Face recognition', desc: 'Sub-second AI verification at entry', icon: 'face' },
      { href: '/rfid-tracking', label: 'RFID tracking', desc: 'Tap-based access and session tracking', icon: 'rfid' },
      { href: '/automated-flap-barriers', label: 'Automated flap barriers', desc: 'AI-powered gates for high-traffic entry', icon: 'gate' },
      { href: '/qr-code-tracking', label: 'QR code tracking', desc: 'Scan-based check-in and attendance', icon: 'qr' },
      { href: '/nfc-payments', label: 'NFC payments', desc: 'Cashless, tap-to-pay at every counter', icon: 'wallet' }
    ] }
  ],
  products: [
    { href: '/platform', label: 'Registration & ticketing platform', desc: 'Ticketing, hotel, transport and payments — one login', icon: 'layers' },
    { href: '/event-mobile-app', label: 'Event mobile app', desc: 'Agenda, networking and live polls in one branded app', icon: 'phone' },
    { href: '/ai-photo-sharing', label: 'AI photo sharing', desc: 'Selfie-matched private photo galleries', icon: 'camera' }
  ],
  primary: [
    { href: '/services', label: 'Services', mega: 'services' },
    { href: '/products', label: 'Products', mega: 'products' },
    { href: '/ai-experiences', label: 'AI Experiences' },
    { href: '/industries', label: 'Industries' },
    { href: '/about', label: 'About' },
    { href: '/blog', label: 'Blog' },
    { href: '/contact', label: 'Contact' }
  ],
  footer: {
    Solutions: [
      ['/event-registration-services', 'Onsite registration'], ['/online-event-registration', 'Online event registration'], ['/registration-desk', 'Registration desk'],
      ['/mobile-pos', 'Mobile POS'], ['/qr-code-tracking', 'QR code tracking'], ['/badge-printing', 'Badge printing'],
      ['/event-check-in-software', 'Event check-in'], ['/delegate-management', 'Delegate management'], ['/corporate-event-technology', 'Corporate event technology']
    ],
    Products: [
      ['/platform', 'Registration & ticketing platform'], ['/event-mobile-app', 'Event mobile app'], ['/smart-kiosks', 'Smart kiosks'],
      ['/face-recognition', 'Face recognition'], ['/rfid-tracking', 'RFID tracking'], ['/nfc-payments', 'NFC payments'],
      ['/automated-flap-barriers', 'Flap barriers & access control'], ['/ai-photo-sharing', 'AI photo sharing'], ['/ai-experiences', 'AI experiences']
    ],
    Company: [
      ['/about', 'About us'], ['/industries', 'Industries'], ['/case-studies', 'Case studies'], ['/contact', 'Contact us'], ['/demo', 'Book a demo']
    ],
    'Resources & Legal': [
      ['/blog', 'Blog & resources'], ['/privacy-policy', 'Privacy policy'], ['/terms-conditions', 'Terms & conditions'],
      ['/cashless-policy', 'Cashless policy'], ['/refund-cancellation', 'Refund & cancellation'], ['/gdpr', 'GDPR']
    ]
  }
};

module.exports = { company, stats, timeline, team, projects, clients, faqs, eventTypes, attendeeRanges, nav };
