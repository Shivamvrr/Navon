'use strict';
/** Admin-editable settings stored in the database, falling back to env defaults. */
const db = require('./db');
const config = require('./config');

const KEYS = Object.keys(config.defaults);
let cache = null;

function all() {
  if (cache) return cache;
  const rows = db.get().prepare('SELECT key, value FROM settings').all();
  const stored = Object.fromEntries(rows.map((r) => [r.key, r.value]));
  cache = {};
  KEYS.forEach((k) => { cache[k] = stored[k] !== undefined && stored[k] !== '' ? stored[k] : config.defaults[k]; });
  return cache;
}

function get(key) { return all()[key]; }

function save(values) {
  const stmt = db.get().prepare(
    `INSERT INTO settings (key, value, updated_at) VALUES (?, ?, datetime('now'))
     ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`
  );
  db.tx(() => {
    KEYS.forEach((k) => { if (values[k] !== undefined) stmt.run(k, String(values[k]).trim()); });
  });
  cache = null;
}

/** WhatsApp number as digits only, with country code, for wa.me links. */
function whatsappDigits() { return String(get('whatsapp_number') || '').replace(/\D/g, ''); }

function whatsappUrl(message) {
  const digits = whatsappDigits();
  if (!digits) return '';
  return `https://wa.me/${digits}?text=${encodeURIComponent(message || get('whatsapp_message'))}`;
}

function clearCache() { cache = null; }

module.exports = { KEYS, all, get, save, whatsappDigits, whatsappUrl, clearCache };
