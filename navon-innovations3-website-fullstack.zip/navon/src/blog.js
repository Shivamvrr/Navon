'use strict';
/** Blog data access and Markdown rendering. */
const { marked } = require('marked');
const sanitizeHtml = require('sanitize-html');
const db = require('./db');
const config = require('./config');

marked.setOptions({ gfm: true, breaks: false });

function slugify(s) {
  return String(s || '').toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '')
    .replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 90);
}

/**
 * Markdown → safe HTML. H1 is demoted to H2 (the page already has an H1),
 * external links open in a new tab with rel="noopener", images lazy-load.
 */
function renderMarkdown(md) {
  const raw = marked.parse(String(md || ''));
  const siteHost = (() => { try { return new URL(config.siteUrl).host; } catch (_e) { return ''; } })();
  return sanitizeHtml(raw, {
    allowedTags: ['h2', 'h3', 'h4', 'p', 'br', 'hr', 'ul', 'ol', 'li', 'a', 'strong', 'em', 'b', 'i', 'blockquote', 'code', 'pre',
      'img', 'figure', 'figcaption', 'table', 'thead', 'tbody', 'tr', 'th', 'td', 'del', 'sup', 'sub'],
    allowedAttributes: { a: ['href', 'title', 'rel', 'target'], img: ['src', 'alt', 'title', 'width', 'height', 'loading', 'decoding'], th: ['align'], td: ['align'], h2: ['id'], h3: ['id'], h4: ['id'] },
    allowedSchemes: ['http', 'https', 'mailto', 'tel'],
    transformTags: {
      h1: 'h2',
      a: (tagName, attribs) => {
        const href = attribs.href || '';
        let external = false;
        try { const u = new URL(href, config.siteUrl); external = /^https?:$/.test(u.protocol) && u.host !== siteHost; } catch (_e) { /* relative */ }
        return { tagName, attribs: external ? { ...attribs, target: '_blank', rel: 'noopener' } : attribs };
      },
      img: (tagName, attribs) => ({ tagName, attribs: { ...attribs, loading: 'lazy', decoding: 'async' } })
    }
  }).replace(/<(h[23])>([^<]+)<\/h[23]>/g, (_m, tag, text) => `<${tag} id="${slugify(text)}">${text}</${tag}>`);
}

/** Table of contents from H2 headings in rendered HTML. */
function toc(html) {
  const out = [];
  String(html).replace(/<h2 id="([^"]+)">([^<]+)<\/h2>/g, (_m, id, text) => { out.push({ id, text }); return ''; });
  return out;
}

function readingMinutes(md) { return Math.max(1, Math.round(String(md || '').split(/\s+/).length / 200)); }

const POST_COLS = `p.*, c.name AS category_name, c.slug AS category_slug`;

function attachTags(posts) {
  if (!posts.length) return posts;
  const ids = posts.map((p) => p.id);
  const rows = db.get().prepare(
    `SELECT pt.post_id, t.name, t.slug FROM post_tags pt JOIN tags t ON t.id = pt.tag_id WHERE pt.post_id IN (${ids.map(() => '?').join(',')}) ORDER BY t.name`
  ).all(...ids);
  posts.forEach((p) => { p.tags = rows.filter((r) => r.post_id === p.id).map((r) => ({ name: r.name, slug: r.slug })); });
  return posts;
}

function listPublished({ page = 1, perPage = 9, category, tag, q } = {}) {
  const where = [`p.status = 'published'`, `p.published_at <= datetime('now')`];
  const args = [];
  if (category) { where.push('c.slug = ?'); args.push(category); }
  if (tag) { where.push('p.id IN (SELECT pt.post_id FROM post_tags pt JOIN tags t ON t.id = pt.tag_id WHERE t.slug = ?)'); args.push(tag); }
  if (q) {
    where.push(`(p.title LIKE ? ESCAPE '\\' OR p.excerpt LIKE ? ESCAPE '\\' OR p.content_md LIKE ? ESCAPE '\\')`);
    const like = '%' + q.replace(/[\\%_]/g, (c) => '\\' + c) + '%';
    args.push(like, like, like);
  }
  const w = 'WHERE ' + where.join(' AND ');
  const total = db.get().prepare(`SELECT COUNT(*) AS n FROM posts p LEFT JOIN categories c ON c.id = p.category_id ${w}`).get(...args).n;
  const posts = db.get().prepare(
    `SELECT ${POST_COLS} FROM posts p LEFT JOIN categories c ON c.id = p.category_id ${w}
     ORDER BY p.published_at DESC LIMIT ? OFFSET ?`
  ).all(...args, perPage, (page - 1) * perPage);
  return { posts: attachTags(posts), total, pages: Math.max(1, Math.ceil(total / perPage)), page };
}

function getBySlug(slug, { includeDrafts = false } = {}) {
  const p = db.get().prepare(
    `SELECT ${POST_COLS} FROM posts p LEFT JOIN categories c ON c.id = p.category_id WHERE p.slug = ?
     ${includeDrafts ? '' : `AND p.status = 'published' AND p.published_at <= datetime('now')`}`
  ).get(slug);
  return p ? attachTags([p])[0] : null;
}

function getById(id) {
  const p = db.get().prepare(`SELECT ${POST_COLS} FROM posts p LEFT JOIN categories c ON c.id = p.category_id WHERE p.id = ?`).get(id);
  return p ? attachTags([p])[0] : null;
}

function related(post, limit = 3) {
  const rows = db.get().prepare(
    `SELECT ${POST_COLS},
       (CASE WHEN p.category_id = ? THEN 2 ELSE 0 END) +
       (SELECT COUNT(*) FROM post_tags a JOIN post_tags b ON a.tag_id = b.tag_id WHERE a.post_id = p.id AND b.post_id = ?) AS score
     FROM posts p LEFT JOIN categories c ON c.id = p.category_id
     WHERE p.status = 'published' AND p.published_at <= datetime('now') AND p.id != ?
     ORDER BY score DESC, p.published_at DESC LIMIT ?`
  ).all(post.category_id || -1, post.id, post.id, limit);
  return attachTags(rows);
}

function categoriesWithCounts() {
  return db.get().prepare(
    `SELECT c.*, (SELECT COUNT(*) FROM posts p WHERE p.category_id = c.id AND p.status = 'published' AND p.published_at <= datetime('now')) AS n
     FROM categories c ORDER BY c.name`
  ).all();
}

function tagsWithCounts() {
  return db.get().prepare(
    `SELECT t.*, COUNT(p.id) AS n FROM tags t JOIN post_tags pt ON pt.tag_id = t.id
     JOIN posts p ON p.id = pt.post_id AND p.status = 'published' AND p.published_at <= datetime('now')
     GROUP BY t.id ORDER BY n DESC, t.name`
  ).all();
}

function setTags(postId, tagNames) {
  const d = db.get();
  d.prepare('DELETE FROM post_tags WHERE post_id = ?').run(postId);
  const names = [...new Set(String(tagNames || '').split(',').map((t) => t.trim()).filter(Boolean))].slice(0, 15);
  names.forEach((name) => {
    const slug = slugify(name);
    if (!slug) return;
    d.prepare('INSERT INTO tags (name, slug) VALUES (?, ?) ON CONFLICT(slug) DO NOTHING').run(name, slug);
    const tag = d.prepare('SELECT id FROM tags WHERE slug = ?').get(slug);
    d.prepare('INSERT OR IGNORE INTO post_tags (post_id, tag_id) VALUES (?, ?)').run(postId, tag.id);
  });
  // Remove tags no longer used by any post
  d.prepare('DELETE FROM tags WHERE id NOT IN (SELECT tag_id FROM post_tags)').run();
}

/** Create or update a post. Returns the post id. */
function save(id, f) {
  const html = renderMarkdown(f.content_md);
  return db.tx((d) => {
    let postId = id;
    if (id) {
      d.prepare(
        `UPDATE posts SET title=?, slug=?, excerpt=?, content_md=?, content_html=?, seo_title=?, meta_description=?, og_title=?, og_description=?,
         featured_image=?, featured_image_alt=?, author=?, category_id=?, status=?, published_at=?, updated_at=datetime('now') WHERE id=?`
      ).run(f.title, f.slug, f.excerpt, f.content_md, html, f.seo_title, f.meta_description, f.og_title, f.og_description,
        f.featured_image, f.featured_image_alt, f.author, f.category_id, f.status, f.published_at, id);
    } else {
      const r = d.prepare(
        `INSERT INTO posts (title, slug, excerpt, content_md, content_html, seo_title, meta_description, og_title, og_description,
         featured_image, featured_image_alt, author, category_id, status, published_at)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
      ).run(f.title, f.slug, f.excerpt, f.content_md, html, f.seo_title, f.meta_description, f.og_title, f.og_description,
        f.featured_image, f.featured_image_alt, f.author, f.category_id, f.status, f.published_at);
      postId = Number(r.lastInsertRowid);
    }
    setTags(postId, f.tags);
    return postId;
  });
}

function remove(id) {
  db.tx((d) => {
    d.prepare('DELETE FROM posts WHERE id = ?').run(id);
    d.prepare('DELETE FROM tags WHERE id NOT IN (SELECT tag_id FROM post_tags)').run();
  });
}

module.exports = { slugify, renderMarkdown, toc, readingMinutes, listPublished, getBySlug, getById, related, categoriesWithCounts, tagsWithCounts, setTags, save, remove };
