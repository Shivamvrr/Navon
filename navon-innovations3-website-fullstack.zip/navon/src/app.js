'use strict';
const path = require('node:path');
const express = require('express');
const helmet = require('helmet');
const compression = require('compression');
const ejs = require('ejs');

const config = require('./config');
const db = require('./db');
const settings = require('./settings');
const security = require('./security');
const seo = require('./seo');
const site = require('./content/site');
const { TIME_SLOTS } = require('./forms');

function createApp() {
  db.open();
  const app = express();

  app.set('views', path.join(__dirname, '..', 'views'));
  app.set('view engine', 'ejs');
  app.set('trust proxy', config.trustProxy ? 1 : false);
  app.disable('x-powered-by');
  if (config.isProd) app.set('view cache', true);

  app.use(helmet({
    contentSecurityPolicy: {
      useDefaults: true,
      directives: {
        'default-src': ["'self'"],
        'script-src': ["'self'", "'unsafe-inline'", 'https://www.googletagmanager.com', 'https://challenges.cloudflare.com'],
        'style-src': ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
        'font-src': ["'self'", 'https://fonts.gstatic.com'],
        'img-src': ["'self'", 'data:', 'https://www.googletagmanager.com', 'https://*.google-analytics.com'],
        'connect-src': ["'self'", 'https://*.google-analytics.com', 'https://*.analytics.google.com', 'https://www.googletagmanager.com', 'https://challenges.cloudflare.com'],
        'frame-src': ['https://challenges.cloudflare.com', 'https://www.googletagmanager.com'],
        'upgrade-insecure-requests': config.isProd ? [] : null
      }
    },
    crossOriginEmbedderPolicy: false
  }));
  app.use(compression());

  // Static files: long cache for images/uploads, shorter for CSS/JS (versioned by query string).
  app.use(express.static(path.join(__dirname, '..', 'public'), {
    maxAge: config.isProd ? '7d' : 0,
    setHeaders(res, p) { if (/\/(img|uploads)\//.test(p)) res.setHeader('Cache-Control', 'public, max-age=2592000'); }
  }));

  // Uploaded blog images (may live outside /public when UPLOAD_DIR is set)
  app.use('/uploads', express.static(config.uploadDir, { maxAge: '30d' }));

  app.use(express.urlencoded({ extended: false, limit: '200kb' }));
  app.use(express.json({ limit: '200kb' }));
  app.use(security.loadSession);

  // Optional staging guard: tells crawlers not to index a non-production copy.
  if (config.noindexSite) app.use((_req, res, next) => { res.setHeader('X-Robots-Tag', 'noindex, nofollow'); next(); });

  // Locals available to every view
  const assetVersion = Date.now().toString(36);
  app.use((req, res, next) => {
    const s = settings.all();
    Object.assign(res.locals, {
      site, settings: s, config: { siteUrl: config.siteUrl, turnstileSiteKey: config.turnstile.siteKey },
      path: req.path, admin: req.admin || null, csrfToken: req.csrfToken || '',
      assetVersion, timeSlots: TIME_SLOTS,
      whatsappUrl: (msg) => settings.whatsappUrl(msg),
      whatsappFor: (topic) => settings.whatsappUrl(topic ? `Hi Navon Innovations, I am interested in your ${topic}${/(solutions?|services)$/i.test(topic) ? '' : ' solutions'}.` : null),
      formToken: () => security.issueFormToken(),
      seoIso: (d) => seo.toIso(d),
      fmtDate: (d) => { if (!d) return ''; const x = new Date(String(d).replace(' ', 'T') + 'Z'); return isNaN(x) ? d : x.toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Asia/Kolkata' }); },
      fmtDateTime: (d) => { if (!d) return ''; const x = new Date(String(d).replace(' ', 'T') + 'Z'); return isNaN(x) ? d : x.toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Kolkata' }); }
    });

    /** Render a page view inside the public layout. */
    res.page = (view, data = {}) => {
      const locals = { ...res.locals, ...data };
      ejs.renderFile(path.join(app.get('views'), 'pages', view + '.ejs'), locals, { cache: config.isProd }, (err, body) => {
        if (err) return next(err);
        res.render('layout', { ...locals, body });
      });
    };
    /** Render an admin view inside the admin layout. */
    res.adminPage = (view, data = {}) => {
      const locals = { ...res.locals, ...data };
      ejs.renderFile(path.join(app.get('views'), 'admin', view + '.ejs'), locals, { cache: config.isProd }, (err, body) => {
        if (err) return next(err);
        res.setHeader('X-Robots-Tag', 'noindex, nofollow');
        res.setHeader('Cache-Control', 'no-store');
        res.render('admin/layout', { ...locals, body });
      });
    };
    next();
  });

  // Redirect trailing slashes to the canonical URL (except root)
  app.use((req, res, next) => {
    if (req.path.length > 1 && req.path.endsWith('/') && req.method === 'GET') {
      const q = req.url.slice(req.path.length);
      return res.redirect(301, req.path.replace(/\/+$/, '') + q);
    }
    next();
  });

  app.use(require('./routes/seo'));
  app.use(require('./routes/forms'));
  app.use(require('./routes/blog'));
  app.use('/admin', require('./routes/admin'));
  app.use(require('./routes/public'));

  // 404
  app.use((req, res) => {
    res.status(404);
    if (req.accepts('html')) {
      return res.page('404', { meta: seo.meta({ title: 'Page not found | Navon Innovations', rawTitle: true, description: 'The page you are looking for does not exist.', path: req.path, noindex: true }) });
    }
    res.json({ ok: false, message: 'Not found' });
  });

  // Errors
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, _next) => {
    console.error('[error]', err);
    if (err.type === 'entity.too.large') return res.status(413).send('The submission is too large.');
    res.status(500);
    if (req.path.startsWith('/admin')) return res.send('Something went wrong. Check the server log for details.');
    try {
      res.page('error', { meta: seo.meta({ title: 'Something went wrong | Navon Innovations', rawTitle: true, description: 'An unexpected error occurred.', path: req.path, noindex: true }) });
    } catch (_e) { res.send('Something went wrong.'); }
  });

  // Housekeeping
  security.purgeExpiredSessions();
  return app;
}

module.exports = { createApp };
