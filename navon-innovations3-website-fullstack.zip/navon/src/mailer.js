'use strict';
/**
 * Email notifications via SMTP (Nodemailer).
 * If SMTP is not configured, nothing is sent and the caller records
 * email_status = 'not_configured' so the admin can see it honestly.
 */
const nodemailer = require('nodemailer');
const config = require('./config');
const settings = require('./settings');

let transport = null;

function isConfigured() { return !!config.smtp.host; }

function getTransport() {
  if (!isConfigured()) return null;
  if (!transport) {
    transport = nodemailer.createTransport({
      host: config.smtp.host,
      port: config.smtp.port,
      secure: config.smtp.secure,
      ignoreTLS: config.smtp.ignoreTLS,
      auth: config.smtp.user ? { user: config.smtp.user, pass: config.smtp.pass } : undefined
    });
  }
  return transport;
}

const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function renderTable(title, rows, adminUrl) {
  const trs = rows.map(([k, v]) => `<tr><td style="padding:8px 12px;color:#5A6185;vertical-align:top;white-space:nowrap">${esc(k)}</td><td style="padding:8px 12px;color:#121A4A">${esc(v || '—').replace(/\n/g, '<br>')}</td></tr>`).join('');
  return `<div style="font-family:Arial,sans-serif;max-width:640px">
    <h2 style="color:#121A4A;margin:0 0 12px">${esc(title)}</h2>
    <table style="border-collapse:collapse;width:100%;background:#F6F7FC;border-radius:8px">${trs}</table>
    ${adminUrl ? `<p style="margin-top:16px"><a href="${esc(adminUrl)}" style="color:#6A4CF5">Open in the admin dashboard</a></p>` : ''}
  </div>`;
}

/**
 * Send a notification to the configured company address.
 * @returns {Promise<{status: 'sent'|'failed'|'not_configured', error?: string}>}
 */
async function notifyCompany({ subject, title, rows, replyTo, adminPath }) {
  const t = getTransport();
  if (!t) return { status: 'not_configured', error: 'SMTP is not configured (set SMTP_HOST and related variables).' };
  const to = settings.get('notify_email');
  if (!to) return { status: 'not_configured', error: 'No notification email address is set in Admin → Settings.' };
  try {
    await t.sendMail({
      from: config.smtp.from || config.smtp.user,
      to,
      replyTo,
      subject,
      text: rows.map(([k, v]) => `${k}: ${v || '—'}`).join('\n') + (adminPath ? `\n\nAdmin: ${config.siteUrl}${adminPath}` : ''),
      html: renderTable(title, rows, adminPath ? config.siteUrl + adminPath : '')
    });
    return { status: 'sent' };
  } catch (e) {
    console.error('[mailer] send failed:', e.message);
    return { status: 'failed', error: e.message.slice(0, 500) };
  }
}

/** Used by Admin → Settings → "Send test email". */
async function sendTest(to) {
  const t = getTransport();
  if (!t) return { status: 'not_configured', error: 'SMTP is not configured.' };
  try {
    await t.sendMail({ from: config.smtp.from || config.smtp.user, to, subject: 'Navon Innovations website: test email', text: 'SMTP is working. Enquiry and demo notifications will be delivered to this address.' });
    return { status: 'sent' };
  } catch (e) { return { status: 'failed', error: e.message }; }
}

function resetTransport() { transport = null; }

module.exports = { isConfigured, notifyCompany, sendTest, resetTransport };
