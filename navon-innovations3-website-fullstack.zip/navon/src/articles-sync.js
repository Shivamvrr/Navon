'use strict';
/**
 * Adds the SEO articles in content/articles.js to the blog.
 * - syncArticles(): inserts any article whose slug is not in the database yet.
 *   Existing posts are left alone, so edits made in Admin → Blog are kept.
 * - syncArticles({ update: true }): also overwrites existing posts with the
 *   same slug (used by `npm run articles:update`).
 */
const db = require('./db');
const blog = require('./blog');
const { ARTICLES } = require('./content/articles');
const { CATEGORIES } = require('./seed');

function syncArticles({ update = false, log = true } = {}) {
  const d = db.get();
  const insCat = d.prepare('INSERT OR IGNORE INTO categories (name, slug, description) VALUES (?, ?, ?)');
  CATEGORIES.forEach((c) => insCat.run(c.name, c.slug, c.description));
  let added = 0, updated = 0;
  ARTICLES.forEach((a, i) => {
    const existing = d.prepare('SELECT id, published_at, status FROM posts WHERE slug = ?').get(a.slug);
    if (existing && !update) return;
    const cat = d.prepare('SELECT id FROM categories WHERE slug = ?').get(a.category);
    // Spread first publication dates over recent days so the blog reads as a series.
    const published = existing ? existing.published_at
      : new Date(Date.now() - (ARTICLES.length - i) * 86400e3).toISOString().slice(0, 19).replace('T', ' ');
    blog.save(existing ? existing.id : null, {
      title: a.title, slug: a.slug, excerpt: a.excerpt, content_md: a.content_md, seo_title: a.seo_title,
      meta_description: a.meta_description, og_title: '', og_description: '', featured_image: a.featured_image,
      featured_image_alt: a.featured_image_alt, author: 'Navon Innovations', category_id: cat ? cat.id : null,
      status: existing ? existing.status : 'published', published_at: published, tags: a.tags
    });
    if (existing) updated++; else added++;
  });
  if (log && (added || updated)) console.log(`[articles] ${added} added, ${updated} updated.`);
  return { added, updated };
}

module.exports = { syncArticles };
