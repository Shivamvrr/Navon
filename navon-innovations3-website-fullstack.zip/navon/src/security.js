'use strict';
/**
 * Security helpers: password hashing (scrypt), admin sessions, CSRF,
 * and spam protection for public forms (honeypot, signed timing token,
 * optional Cloudflare Turnstile).
 */
const crypto = require('node:crypto');
const db = require('./db');
const config = require('./config');

const SESSION_COOKIE = 'nv_admin';
const SESSION_TTL_MS = 1000 * 60 * 60 * 12; // 12 hours

/* ---------- Passwords ---------- */
function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(password, salt, 64, { N: 16384, r: 8, p: 1 });
  return `scrypt$${salt.toString('base64')}$${hash.toString('base64')}`;
}

function verifyPassword(password, stored) {
  const [scheme, saltB64, hashB64] = String(stored).split('$');
  if (scheme !== 'scrypt' || !saltB64 || !hashB64) return false;
  const expected = Buffer.from(hashB64, 'base64');
  const actual = crypto.scryptSync(password, Buffer.from(saltB64, 'base64'), expected.length, { N: 16384, r: 8, p: 1 });
  return crypto.timingSafeEqual(expected, actual);
}

/* ---------- Cookies ---------- */
function parseCookies(header) {
  const out = {};
  String(header || '').split(';').forEach((part) => {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  });
  return out;
}

const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');

/* ---------- Sessions ---------- */
function createSession(res, adminId) {
  const token = crypto.randomBytes(32).toString('base64url');
  const csrf = crypto.randomBytes(24).toString('base64url');
  db.get().prepare('INSERT INTO sessions (id, admin_id, csrf, expires_at) VALUES (?, ?, ?, ?)')
    .run(sha256(token), adminId, csrf, Date.now() + SESSION_TTL_MS);
  res.cookie(SESSION_COOKIE, token, {
    httpOnly: true, sameSite: 'lax', secure: config.isProd, maxAge: SESSION_TTL_MS, path: '/'
  });
}

function destroySession(req, res) {
  const token = parseCookies(req.headers.cookie)[SESSION_COOKIE];
  if (token) db.get().prepare('DELETE FROM sessions WHERE id = ?').run(sha256(token));
  res.clearCookie(SESSION_COOKIE, { path: '/' });
}

/** Middleware: attaches req.admin and req.csrfToken when a valid session exists. */
function loadSession(req, _res, next) {
  const token = parseCookies(req.headers.cookie)[SESSION_COOKIE];
  if (token) {
    const row = db.get().prepare(
      `SELECT s.csrf, s.expires_at, a.id, a.email, a.name FROM sessions s
       JOIN admins a ON a.id = s.admin_id WHERE s.id = ?`
    ).get(sha256(token));
    if (row && row.expires_at > Date.now()) {
      req.admin = { id: row.id, email: row.email, name: row.name };
      req.csrfToken = row.csrf;
    }
  }
  next();
}

function requireAdmin(req, res, next) {
  if (req.admin) return next();
  return res.redirect('/admin/login?next=' + encodeURIComponent(req.originalUrl));
}

/** Middleware: rejects state-changing admin requests without a valid CSRF token. */
function verifyCsrf(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const sent = (req.body && req.body._csrf) || req.get('x-csrf-token') || (req.query && req.query._csrf);
  if (req.csrfToken && sent && sent.length === req.csrfToken.length &&
      crypto.timingSafeEqual(Buffer.from(sent), Buffer.from(req.csrfToken))) return next();
  return res.status(403).send('Your session has expired or the form is invalid. Go back, refresh the page and try again.');
}

function purgeExpiredSessions() {
  db.get().prepare('DELETE FROM sessions WHERE expires_at < ?').run(Date.now());
}

/* ---------- Public form spam protection ---------- */
const MIN_FILL_MS = 3000;            // humans take longer than 3 seconds
const MAX_TOKEN_AGE_MS = 1000 * 60 * 60 * 24;

function sign(value) { return crypto.createHmac('sha256', config.appSecret).update(value).digest('base64url'); }

/** Token embedded in each public form: issue time + HMAC. */
function issueFormToken(now = Date.now()) {
  const t = now.toString(36);
  return `${t}.${sign(t)}`;
}

/**
 * Returns null if the submission looks human, otherwise a reason string.
 * Checks: honeypot field left empty, valid signed token, minimum fill time.
 */
function checkSpam(body) {
  if (body.website) return 'honeypot';
  const tok = String(body._ft || '');
  const [t, sig] = tok.split('.');
  if (!t || !sig || sign(t) !== sig) return 'bad-token';
  const age = Date.now() - parseInt(t, 36);
  if (age < MIN_FILL_MS) return 'too-fast';
  if (age > MAX_TOKEN_AGE_MS) return 'expired';
  return null;
}

/** Optional Cloudflare Turnstile verification. Returns true when not configured. */
async function verifyTurnstile(token, ip) {
  if (!config.turnstile.secretKey) return true;
  if (!token) return false;
  try {
    const r = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ secret: config.turnstile.secretKey, response: token, remoteip: ip || '' })
    });
    const data = await r.json();
    return !!data.success;
  } catch (e) {
    console.error('[turnstile] verification failed', e.message);
    return false;
  }
}

/** Store a one-way hash of the IP (privacy) for abuse investigation. */
function hashIp(ip) { return sha256(`${config.appSecret}:${ip || ''}`).slice(0, 32); }

module.exports = {
  hashPassword, verifyPassword, parseCookies, createSession, destroySession, loadSession,
  requireAdmin, verifyCsrf, purgeExpiredSessions, issueFormToken, checkSpam, verifyTurnstile, hashIp,
  SESSION_COOKIE
};
