'use strict';
/**
 * SQLite database (Node's built-in node:sqlite, no native build needed).
 * Schema is created and migrated on start.
 */
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const config = require('./config');

let db;

const MIGRATIONS = [
  `CREATE TABLE IF NOT EXISTS settings (
     key TEXT PRIMARY KEY,
     value TEXT NOT NULL,
     updated_at TEXT NOT NULL DEFAULT (datetime('now'))
   );
   CREATE TABLE IF NOT EXISTS admins (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     email TEXT NOT NULL UNIQUE COLLATE NOCASE,
     name TEXT NOT NULL DEFAULT '',
     password_hash TEXT NOT NULL,
     created_at TEXT NOT NULL DEFAULT (datetime('now')),
     last_login_at TEXT
   );
   CREATE TABLE IF NOT EXISTS sessions (
     id TEXT PRIMARY KEY,
     admin_id INTEGER NOT NULL REFERENCES admins(id) ON DELETE CASCADE,
     csrf TEXT NOT NULL,
     expires_at INTEGER NOT NULL,
     created_at TEXT NOT NULL DEFAULT (datetime('now'))
   );
   CREATE TABLE IF NOT EXISTS enquiries (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     name TEXT NOT NULL,
     company TEXT NOT NULL,
     email TEXT NOT NULL,
     phone TEXT NOT NULL,
     event_type TEXT NOT NULL,
     attendees TEXT NOT NULL DEFAULT '',
     event_date TEXT NOT NULL DEFAULT '',
     message TEXT NOT NULL DEFAULT '',
     source_page TEXT NOT NULL DEFAULT '',
     status TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new','read','archived')),
     email_status TEXT NOT NULL DEFAULT 'pending',
     email_error TEXT NOT NULL DEFAULT '',
     ip_hash TEXT NOT NULL DEFAULT '',
     user_agent TEXT NOT NULL DEFAULT '',
     created_at TEXT NOT NULL DEFAULT (datetime('now'))
   );
   CREATE TABLE IF NOT EXISTS demo_requests (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     name TEXT NOT NULL,
     company TEXT NOT NULL,
     email TEXT NOT NULL,
     phone TEXT NOT NULL,
     event_type TEXT NOT NULL,
     delegates TEXT NOT NULL DEFAULT '',
     preferred_date TEXT NOT NULL DEFAULT '',
     preferred_time TEXT NOT NULL DEFAULT '',
     requirements TEXT NOT NULL DEFAULT '',
     source_page TEXT NOT NULL DEFAULT '',
     status TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new','contacted','scheduled','completed','cancelled')),
     admin_notes TEXT NOT NULL DEFAULT '',
     email_status TEXT NOT NULL DEFAULT 'pending',
     email_error TEXT NOT NULL DEFAULT '',
     ip_hash TEXT NOT NULL DEFAULT '',
     user_agent TEXT NOT NULL DEFAULT '',
     created_at TEXT NOT NULL DEFAULT (datetime('now')),
     updated_at TEXT NOT NULL DEFAULT (datetime('now'))
   );
   CREATE TABLE IF NOT EXISTS categories (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     name TEXT NOT NULL,
     slug TEXT NOT NULL UNIQUE,
     description TEXT NOT NULL DEFAULT ''
   );
   CREATE TABLE IF NOT EXISTS tags (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     name TEXT NOT NULL,
     slug TEXT NOT NULL UNIQUE
   );
   CREATE TABLE IF NOT EXISTS posts (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     title TEXT NOT NULL,
     slug TEXT NOT NULL UNIQUE,
     excerpt TEXT NOT NULL DEFAULT '',
     content_md TEXT NOT NULL DEFAULT '',
     content_html TEXT NOT NULL DEFAULT '',
     seo_title TEXT NOT NULL DEFAULT '',
     meta_description TEXT NOT NULL DEFAULT '',
     og_title TEXT NOT NULL DEFAULT '',
     og_description TEXT NOT NULL DEFAULT '',
     featured_image TEXT NOT NULL DEFAULT '',
     featured_image_alt TEXT NOT NULL DEFAULT '',
     author TEXT NOT NULL DEFAULT 'Navon Innovations',
     category_id INTEGER REFERENCES categories(id) ON DELETE SET NULL,
     status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published')),
     published_at TEXT,
     created_at TEXT NOT NULL DEFAULT (datetime('now')),
     updated_at TEXT NOT NULL DEFAULT (datetime('now'))
   );
   CREATE TABLE IF NOT EXISTS post_tags (
     post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
     tag_id INTEGER NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
     PRIMARY KEY (post_id, tag_id)
   );
   CREATE INDEX IF NOT EXISTS idx_posts_status ON posts(status, published_at);
   CREATE INDEX IF NOT EXISTS idx_enq_created ON enquiries(created_at);
   CREATE INDEX IF NOT EXISTS idx_demo_status ON demo_requests(status, created_at);`
];

function open(file = config.dbFile) {
  if (db) return db;
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');
  db.exec('CREATE TABLE IF NOT EXISTS _migrations (id INTEGER PRIMARY KEY)');
  const done = new Set(db.prepare('SELECT id FROM _migrations').all().map((r) => r.id));
  MIGRATIONS.forEach((sql, i) => {
    if (done.has(i)) return;
    db.exec('BEGIN');
    try { db.exec(sql); db.prepare('INSERT INTO _migrations (id) VALUES (?)').run(i); db.exec('COMMIT'); }
    catch (e) { db.exec('ROLLBACK'); throw e; }
  });
  return db;
}

function get() { if (!db) open(); return db; }
function close() { if (db) { db.close(); db = undefined; } }

/** Run fn inside a transaction. */
function tx(fn) {
  const d = get();
  d.exec('BEGIN');
  try { const r = fn(d); d.exec('COMMIT'); return r; }
  catch (e) { d.exec('ROLLBACK'); throw e; }
}

module.exports = { open, get, close, tx };
