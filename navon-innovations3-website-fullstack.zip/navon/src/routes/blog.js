'use strict';
const express = require('express');
const blog = require('../blog');
const seo = require('../seo');
const db = require('../db');

const router = express.Router();
const PER_PAGE = 9;

const crumbs = (...extra) => [{ name: 'Home', href: '/' }, { name: 'Blog', href: '/blog' }, ...extra];

function listing(req, res, { category, tag }) {
  const page = Math.max(1, parseInt(req.query.page, 10) || 1);
  const q = String(req.query.q || '').trim().slice(0, 80);
  const result = blog.listPublished({ page, perPage: PER_PAGE, category: category && category.slug, tag: tag && tag.slug, q });
  if (page > result.pages && page > 1) return res.redirect(301, req.path);

  let title = 'Event Technology Blog & Resources | Navon Innovations';
  let description = 'Guides and insights on event registration, check-in, QR, RFID and NFC tracking, facial recognition and event reporting from Navon Innovations.';
  let h1 = 'Blog & resources';
  let base = '/blog';
  let c = crumbs();
  if (category) {
    title = `${category.name} | Navon Innovations Blog`;
    description = category.description || `Articles about ${category.name.toLowerCase()} from Navon Innovations.`;
    h1 = category.name; base = `/blog/category/${category.slug}`;
    c = crumbs({ name: category.name, href: base });
  } else if (tag) {
    title = `Articles tagged “${tag.name}” | Navon Innovations Blog`;
    description = `Articles from Navon Innovations about ${tag.name}: guides and insights on event registration, check-in and attendee tracking.`;
    h1 = `Tagged: ${tag.name}`; base = `/blog/tag/${tag.slug}`;
    c = crumbs({ name: tag.name, href: base });
  }
  const canonicalPath = page > 1 ? `${base}?page=${page}` : base;
  res.page('blog-list', {
    ...result, q, category, tag, h1, base,
    categories: blog.categoriesWithCounts(), tags: blog.tagsWithCounts().slice().sort((a, b) => (b.n || b.count || 0) - (a.n || a.count || 0)).slice(0, 14),
    // Search results and tag archives are noindex,follow (thin/overlapping listings); the blog index and categories are indexable.
    meta: seo.meta({ title: page > 1 ? `${title} (page ${page})` : title, rawTitle: true, description, path: base, canonicalPath, crumbs: c, noindex: !!q || !!tag, follow: !!tag })
  });
}

router.get('/blog', (req, res) => listing(req, res, {}));

router.get('/blog/category/:slug', (req, res, next) => {
  const category = db.get().prepare('SELECT * FROM categories WHERE slug = ?').get(req.params.slug);
  if (!category) return next();
  listing(req, res, { category });
});

router.get('/blog/tag/:slug', (req, res, next) => {
  const tag = db.get().prepare('SELECT * FROM tags WHERE slug = ?').get(req.params.slug);
  if (!tag) return next();
  listing(req, res, { tag });
});

router.get('/blog/:slug', (req, res, next) => {
  // Admins can preview drafts at the same URL (marked noindex).
  const post = blog.getBySlug(req.params.slug, { includeDrafts: !!req.admin });
  if (!post) return next();
  const isDraft = post.status !== 'published';
  const path = `/blog/${post.slug}`;
  const c = crumbs();
  if (post.category_slug) c.push({ name: post.category_name, href: `/blog/category/${post.category_slug}` });
  c.push({ name: post.title, href: path });
  res.page('blog-post', {
    post, related: blog.related(post), toc: blog.toc(post.content_html), minutes: blog.readingMinutes(post.content_md), isDraft,
    meta: seo.meta({
      title: post.seo_title || `${post.title} | Navon Innovations`, rawTitle: !!post.seo_title,
      description: post.meta_description || post.excerpt, path, type: 'article',
      image: post.featured_image || undefined, imageAlt: post.featured_image_alt || post.title,
      crumbs: c, schema: [seo.article(post), seo.faqPage(seo.faqFromMarkdown(post.content_md), path)].filter(Boolean), noindex: isDraft,
      article: {
        published: seo.toIso(post.published_at), modified: seo.toIso(post.updated_at), author: post.author,
        section: post.category_name || '', tags: (post.tags || []).map((t) => t.name),
        ogTitle: post.og_title || post.seo_title || post.title, ogDescription: post.og_description || post.meta_description || post.excerpt
      }
    })
  });
});

module.exports = router;
