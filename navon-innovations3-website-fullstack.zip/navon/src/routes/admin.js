'use strict';
const path = require('node:path');
const fs = require('node:fs');
const crypto = require('node:crypto');
const express = require('express');
const rateLimit = require('express-rate-limit');
const multer = require('multer');
const sharp = require('sharp');

const db = require('../db');
const config = require('../config');
const settings = require('../settings');
const security = require('../security');
const mailer = require('../mailer');
const blog = require('../blog');
const forms = require('../forms');

const router = express.Router();
const PER_PAGE = 25;

/* ---------------- Auth ---------------- */
const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: 'draft-7', legacyHeaders: false,
  handler: (_req, res) => res.status(429).send('Too many sign-in attempts. Wait 15 minutes and try again.') });

router.get('/login', (req, res) => {
  if (req.admin) return res.redirect('/admin');
  res.adminPage('login', { title: 'Sign in', error: '', email: '', next: safeNext(req.query.next), bare: true });
});

router.post('/login', loginLimiter, (req, res) => {
  const email = String(req.body.email || '').trim();
  const password = String(req.body.password || '');
  const next = safeNext(req.body.next);
  const admin = db.get().prepare('SELECT * FROM admins WHERE email = ?').get(email);
  // Always run a hash comparison to keep timing similar for unknown emails.
  const ok = admin ? security.verifyPassword(password, admin.password_hash) : (security.verifyPassword(password, 'scrypt$AAAAAAAAAAAAAAAAAAAAAA==$' + 'A'.repeat(86)), false);
  if (!ok) return res.status(401).adminPage('login', { title: 'Sign in', error: 'The email or password is incorrect.', email, next, bare: true });
  db.get().prepare(`UPDATE admins SET last_login_at = datetime('now') WHERE id = ?`).run(admin.id);
  security.createSession(res, admin.id);
  res.redirect(next || '/admin');
});

function safeNext(n) { const s = String(n || ''); return s.startsWith('/admin') && !s.startsWith('//') ? s : ''; }

router.use(security.requireAdmin);

/* ---------------- Image upload (before CSRF body check: multipart; token sent in header) ---------------- */
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 8 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => cb(null, /^image\/(jpeg|png|webp|gif|avif)$/.test(file.mimetype))
});

router.post('/upload', upload.single('image'), security.verifyCsrf, async (req, res) => {
  if (!req.file) return res.status(400).json({ ok: false, message: 'Choose a JPG, PNG, WebP, GIF or AVIF image up to 8 MB.' });
  try {
    const base = blog.slugify(String(req.body.name || path.parse(req.file.originalname).name)) || 'image';
    const fileName = `${base}-${crypto.randomBytes(3).toString('hex')}.webp`;
    fs.mkdirSync(config.uploadDir, { recursive: true });
    const info = await sharp(req.file.buffer).rotate().resize({ width: 1600, withoutEnlargement: true }).webp({ quality: 80 }).toFile(path.join(config.uploadDir, fileName));
    res.json({ ok: true, url: `/uploads/${fileName}`, width: info.width, height: info.height, bytes: info.size });
  } catch (e) {
    console.error('[upload]', e.message);
    res.status(400).json({ ok: false, message: 'That file could not be processed as an image.' });
  }
});

router.use(security.verifyCsrf);

router.post('/logout', (req, res) => { security.destroySession(req, res); res.redirect('/admin/login'); });

/* ---------------- Dashboard ---------------- */
router.get('/', (_req, res) => {
  const d = db.get();
  const count = (sql, ...a) => d.prepare(sql).get(...a).n;
  const demoByStatus = Object.fromEntries(forms.DEMO_STATUSES.map((s) => [s, count('SELECT COUNT(*) AS n FROM demo_requests WHERE status = ?', s)]));
  res.adminPage('dashboard', {
    title: 'Dashboard',
    stats: {
      newEnquiries: count(`SELECT COUNT(*) AS n FROM enquiries WHERE status = 'new'`),
      totalEnquiries: count('SELECT COUNT(*) AS n FROM enquiries'),
      demoByStatus,
      published: count(`SELECT COUNT(*) AS n FROM posts WHERE status = 'published'`),
      drafts: count(`SELECT COUNT(*) AS n FROM posts WHERE status = 'draft'`),
      emailFailures: count(`SELECT COUNT(*) AS n FROM (SELECT email_status FROM enquiries UNION ALL SELECT email_status FROM demo_requests) WHERE email_status = 'failed'`)
    },
    recentDemos: d.prepare('SELECT * FROM demo_requests ORDER BY id DESC LIMIT 6').all(),
    recentEnquiries: d.prepare('SELECT * FROM enquiries ORDER BY id DESC LIMIT 6').all(),
    smtpConfigured: mailer.isConfigured()
  });
});

/* ---------------- Shared list helper ---------------- */
function listRecords(table, req, statuses) {
  const page = Math.max(1, parseInt(req.query.page, 10) || 1);
  const status = statuses.includes(req.query.status) ? req.query.status : '';
  const q = String(req.query.q || '').trim().slice(0, 80);
  const where = []; const args = [];
  if (status) { where.push('status = ?'); args.push(status); }
  if (q) { where.push('(name LIKE ? OR company LIKE ? OR email LIKE ? OR phone LIKE ?)'); const l = `%${q}%`; args.push(l, l, l, l); }
  const w = where.length ? 'WHERE ' + where.join(' AND ') : '';
  const total = db.get().prepare(`SELECT COUNT(*) AS n FROM ${table} ${w}`).get(...args).n;
  const rows = db.get().prepare(`SELECT * FROM ${table} ${w} ORDER BY id DESC LIMIT ? OFFSET ?`).all(...args, PER_PAGE, (page - 1) * PER_PAGE);
  return { rows, total, page, pages: Math.max(1, Math.ceil(total / PER_PAGE)), status, q };
}

function csv(res, filename, rows, cols) {
  const escCsv = (v) => { const s = String(v == null ? '' : v); return /[",\n\r]/.test(s) || /^[=+\-@]/.test(s) ? `"${(/^[=+\-@]/.test(s) ? "'" : '') + s.replace(/"/g, '""')}"` : s; };
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  res.send('﻿' + [cols.join(','), ...rows.map((r) => cols.map((c) => escCsv(r[c])).join(','))].join('\r\n'));
}

/* ---------------- Enquiries ---------------- */
router.get('/enquiries', (req, res) => {
  res.adminPage('enquiries', { title: 'Enquiries', ...listRecords('enquiries', req, forms.ENQ_STATUSES), statuses: forms.ENQ_STATUSES, ref: forms.ref });
});

router.get('/enquiries.csv', (_req, res) => {
  const rows = db.get().prepare('SELECT * FROM enquiries ORDER BY id DESC').all();
  csv(res, 'navon-enquiries.csv', rows, ['id', 'created_at', 'status', 'name', 'company', 'email', 'phone', 'event_type', 'attendees', 'event_date', 'message', 'source_page', 'email_status']);
});

router.get('/enquiries/:id', (req, res, next) => {
  const row = db.get().prepare('SELECT * FROM enquiries WHERE id = ?').get(req.params.id);
  if (!row) return next();
  if (row.status === 'new') { db.get().prepare(`UPDATE enquiries SET status = 'read' WHERE id = ?`).run(row.id); row.status = 'read'; }
  res.adminPage('enquiry', { title: `Enquiry ${forms.ref('ENQ', row.id)}`, row, ref: forms.ref, statuses: forms.ENQ_STATUSES, whatsappTo: waTo(row.phone) });
});

router.post('/enquiries/:id/status', (req, res) => {
  const s = forms.ENQ_STATUSES.includes(req.body.status) ? req.body.status : 'read';
  db.get().prepare('UPDATE enquiries SET status = ? WHERE id = ?').run(s, req.params.id);
  res.redirect(`/admin/enquiries/${req.params.id}?saved=1`);
});

router.post('/enquiries/:id/delete', (req, res) => {
  db.get().prepare('DELETE FROM enquiries WHERE id = ?').run(req.params.id);
  res.redirect('/admin/enquiries?deleted=1');
});

/* ---------------- Demo requests ---------------- */
router.get('/demo-requests', (req, res) => {
  const counts = Object.fromEntries(forms.DEMO_STATUSES.map((s) => [s, db.get().prepare('SELECT COUNT(*) AS n FROM demo_requests WHERE status = ?').get(s).n]));
  res.adminPage('demos', { title: 'Demo requests', ...listRecords('demo_requests', req, forms.DEMO_STATUSES), statuses: forms.DEMO_STATUSES, counts, ref: forms.ref });
});

router.get('/demo-requests.csv', (_req, res) => {
  const rows = db.get().prepare('SELECT * FROM demo_requests ORDER BY id DESC').all();
  csv(res, 'navon-demo-requests.csv', rows, ['id', 'created_at', 'status', 'name', 'company', 'email', 'phone', 'event_type', 'delegates', 'preferred_date', 'preferred_time', 'requirements', 'admin_notes', 'source_page', 'email_status']);
});

router.get('/demo-requests/:id', (req, res, next) => {
  const row = db.get().prepare('SELECT * FROM demo_requests WHERE id = ?').get(req.params.id);
  if (!row) return next();
  res.adminPage('demo', { title: `Demo request ${forms.ref('DEMO', row.id)}`, row, ref: forms.ref, statuses: forms.DEMO_STATUSES, saved: !!req.query.saved, whatsappTo: waTo(row.phone) });
});

router.post('/demo-requests/:id', (req, res) => {
  const s = forms.DEMO_STATUSES.includes(req.body.status) ? req.body.status : null;
  if (!s) return res.status(400).send('Invalid status.');
  db.get().prepare(`UPDATE demo_requests SET status = ?, admin_notes = ?, updated_at = datetime('now') WHERE id = ?`)
    .run(s, String(req.body.admin_notes || '').slice(0, 4000), req.params.id);
  if (req.body.back === 'list') return res.redirect('/admin/demo-requests?saved=1');
  res.redirect(`/admin/demo-requests/${req.params.id}?saved=1`);
});

router.post('/demo-requests/:id/delete', (req, res) => {
  db.get().prepare('DELETE FROM demo_requests WHERE id = ?').run(req.params.id);
  res.redirect('/admin/demo-requests?deleted=1');
});

function waTo(phone) {
  let digits = String(phone || '').replace(/\D/g, '');
  if (digits.length === 10) digits = '91' + digits; // assume India for 10-digit numbers
  return digits ? `https://wa.me/${digits}` : '';
}

/* ---------------- Blog posts ---------------- */
router.get('/posts', (req, res) => {
  const status = ['draft', 'published'].includes(req.query.status) ? req.query.status : '';
  const posts = db.get().prepare(
    `SELECT p.id, p.title, p.slug, p.status, p.published_at, p.updated_at, c.name AS category_name FROM posts p
     LEFT JOIN categories c ON c.id = p.category_id ${status ? 'WHERE p.status = ?' : ''} ORDER BY p.updated_at DESC`
  ).all(...(status ? [status] : []));
  res.adminPage('posts', { title: 'Blog posts', posts, status, flash: req.query.flash || '' });
});

function emptyPost() {
  return { id: null, title: '', slug: '', excerpt: '', content_md: '', seo_title: '', meta_description: '', og_title: '', og_description: '', featured_image: '', featured_image_alt: '', author: 'Navon Innovations', category_id: null, status: 'draft', published_at: '', tags: [] };
}

function postForm(res, post, errors = {}, status = 200) {
  res.status(status).adminPage('post-form', {
    title: post.id ? 'Edit post' : 'New post', post, errors,
    categories: db.get().prepare('SELECT * FROM categories ORDER BY name').all(),
    tagString: Array.isArray(post.tags) ? post.tags.map((t) => t.name || t).join(', ') : post.tags || ''
  });
}

// datetime-local value (IST) <-> stored UTC 'YYYY-MM-DD HH:MM:SS'
const istToUtc = (v) => { if (!v) return null; const d = new Date(v + ':00+05:30'); return isNaN(d) ? null : d.toISOString().slice(0, 19).replace('T', ' '); };
const utcToIst = (v) => { if (!v) return ''; const d = new Date(String(v).replace(' ', 'T') + 'Z'); return isNaN(d) ? '' : new Date(d.getTime() + 5.5 * 3600e3).toISOString().slice(0, 16); };

function readPostForm(body, id) {
  const f = {
    title: String(body.title || '').trim().slice(0, 200),
    slug: blog.slugify(body.slug || body.title),
    excerpt: String(body.excerpt || '').trim().slice(0, 400),
    content_md: String(body.content_md || '').slice(0, 200000),
    seo_title: String(body.seo_title || '').trim().slice(0, 120),
    meta_description: String(body.meta_description || '').trim().slice(0, 320),
    og_title: String(body.og_title || '').trim().slice(0, 120),
    og_description: String(body.og_description || '').trim().slice(0, 320),
    featured_image: String(body.featured_image || '').trim().slice(0, 300),
    featured_image_alt: String(body.featured_image_alt || '').trim().slice(0, 200),
    author: String(body.author || '').trim().slice(0, 100) || 'Navon Innovations',
    category_id: parseInt(body.category_id, 10) || null,
    status: body.status === 'published' ? 'published' : 'draft',
    published_at: istToUtc(body.published_at),
    tags: String(body.tags || '')
  };
  const errors = {};
  if (f.title.length < 5) errors.title = 'Enter a title of at least 5 characters.';
  if (!f.slug) errors.slug = 'Enter a URL slug using letters, numbers and hyphens.';
  else if (db.get().prepare('SELECT id FROM posts WHERE slug = ? AND id != ?').get(f.slug, id || 0)) errors.slug = 'Another post already uses this URL. Choose a different slug.';
  if (f.featured_image && !/^(\/uploads\/|\/img\/|https:\/\/)/.test(f.featured_image)) errors.featured_image = 'Upload an image or use a path starting with /uploads/ or /img/.';
  if (f.featured_image && !f.featured_image_alt) errors.featured_image_alt = 'Describe the featured image for screen readers and search engines.';
  if (f.status === 'published') {
    if (f.content_md.trim().length < 200) errors.content_md = 'Published posts need at least 200 characters of content.';
    if (!f.meta_description) errors.meta_description = 'Add a meta description before publishing (aim for 120–160 characters).';
    if (!f.excerpt) errors.excerpt = 'Add a short excerpt before publishing.';
    if (!f.published_at) f.published_at = new Date().toISOString().slice(0, 19).replace('T', ' ');
  }
  return { f, errors };
}

router.get('/posts/new', (_req, res) => postForm(res, emptyPost()));

router.post('/posts', (req, res) => {
  const { f, errors } = readPostForm(req.body, null);
  if (Object.keys(errors).length) return postForm(res, { ...f, id: null, published_at: req.body.published_at }, errors, 422);
  const id = blog.save(null, f);
  res.redirect(`/admin/posts/${id}/edit?flash=${f.status === 'published' ? 'published' : 'saved'}`);
});

router.get('/posts/:id/edit', (req, res, next) => {
  const post = blog.getById(req.params.id);
  if (!post) return next();
  post.published_at = utcToIst(post.published_at);
  res.locals.flash = req.query.flash || '';
  postForm(res, post);
});

router.post('/posts/:id', (req, res, next) => {
  const existing = blog.getById(req.params.id);
  if (!existing) return next();
  const { f, errors } = readPostForm(req.body, existing.id);
  if (Object.keys(errors).length) return postForm(res, { ...f, id: existing.id, published_at: req.body.published_at }, errors, 422);
  blog.save(existing.id, f);
  res.redirect(`/admin/posts/${existing.id}/edit?flash=saved`);
});

router.post('/posts/:id/publish', (req, res, next) => {
  const p = blog.getById(req.params.id);
  if (!p) return next();
  if (!p.meta_description || !p.excerpt || p.content_md.trim().length < 200) {
    return res.redirect(`/admin/posts/${p.id}/edit?flash=incomplete`);
  }
  db.get().prepare(`UPDATE posts SET status = 'published', published_at = COALESCE(published_at, datetime('now')), updated_at = datetime('now') WHERE id = ?`).run(p.id);
  res.redirect('/admin/posts?flash=published');
});

router.post('/posts/:id/unpublish', (req, res) => {
  db.get().prepare(`UPDATE posts SET status = 'draft', updated_at = datetime('now') WHERE id = ?`).run(req.params.id);
  res.redirect('/admin/posts?flash=unpublished');
});

router.post('/posts/:id/delete', (req, res) => {
  blog.remove(req.params.id);
  res.redirect('/admin/posts?flash=deleted');
});

router.post('/preview', (req, res) => res.json({ html: blog.renderMarkdown(req.body.content_md || '') }));

/* ---------------- Categories ---------------- */
router.get('/categories', (req, res) => {
  const cats = db.get().prepare('SELECT c.*, (SELECT COUNT(*) FROM posts p WHERE p.category_id = c.id) AS n FROM categories c ORDER BY c.name').all();
  res.adminPage('categories', { title: 'Categories', cats, error: req.query.error || '' });
});

router.post('/categories', (req, res) => {
  const name = String(req.body.name || '').trim().slice(0, 80);
  const slug = blog.slugify(req.body.slug || name);
  if (!name || !slug) return res.redirect('/admin/categories?error=Enter+a+category+name');
  try {
    db.get().prepare('INSERT INTO categories (name, slug, description) VALUES (?, ?, ?)').run(name, slug, String(req.body.description || '').slice(0, 300));
  } catch (_e) { return res.redirect('/admin/categories?error=That+slug+is+already+used'); }
  res.redirect('/admin/categories');
});

router.post('/categories/:id', (req, res) => {
  const name = String(req.body.name || '').trim().slice(0, 80);
  const slug = blog.slugify(req.body.slug || name);
  try {
    db.get().prepare('UPDATE categories SET name = ?, slug = ?, description = ? WHERE id = ?').run(name, slug, String(req.body.description || '').slice(0, 300), req.params.id);
  } catch (_e) { return res.redirect('/admin/categories?error=That+slug+is+already+used'); }
  res.redirect('/admin/categories');
});

router.post('/categories/:id/delete', (req, res) => {
  db.get().prepare('DELETE FROM categories WHERE id = ?').run(req.params.id);
  res.redirect('/admin/categories');
});

/* ---------------- Settings ---------------- */
router.get('/settings', (req, res) => {
  res.adminPage('settings', {
    title: 'Settings', values: settings.all(), flash: req.query.flash || '', testResult: req.query.test || '', testError: req.query.err || '',
    env: { smtp: mailer.isConfigured(), smtpHost: config.smtp.host, turnstile: !!config.turnstile.secretKey, siteUrl: config.siteUrl, noindex: config.noindexSite, secretSet: !config.appSecret.startsWith('dev-only') }
  });
});

router.post('/settings', (req, res) => {
  const v = {};
  settings.KEYS.forEach((k) => { if (req.body[k] !== undefined) v[k] = String(req.body[k]).slice(0, 500); });
  if (v.whatsapp_number !== undefined) v.whatsapp_number = v.whatsapp_number.replace(/[^\d+]/g, '');
  if (v.ga4_id && !/^G-[A-Z0-9]+$/i.test(v.ga4_id)) return res.redirect('/admin/settings?flash=bad-ga4');
  if (v.gtm_id && !/^GTM-[A-Z0-9]+$/i.test(v.gtm_id)) return res.redirect('/admin/settings?flash=bad-gtm');
  if (v.google_site_verification) v.google_site_verification = v.google_site_verification.replace(/.*content="([^"]+)".*/, '$1').trim();
  if (v.bing_site_verification) v.bing_site_verification = v.bing_site_verification.replace(/.*content="([^"]+)".*/, '$1').trim();
  settings.save(v);
  res.redirect('/admin/settings?flash=saved');
});

router.post('/settings/test-email', async (req, res) => {
  const r = await mailer.sendTest(settings.get('notify_email'));
  res.redirect(`/admin/settings?test=${r.status}${r.error ? '&err=' + encodeURIComponent(r.error.slice(0, 200)) : ''}#email`);
});

/* ---------------- Account ---------------- */
router.get('/account', (req, res) => res.adminPage('account', { title: 'Account', error: '', flash: req.query.flash || '' }));

router.post('/account', (req, res) => {
  const admin = db.get().prepare('SELECT * FROM admins WHERE id = ?').get(req.admin.id);
  const { current, password, confirm } = req.body;
  let error = '';
  if (!security.verifyPassword(String(current || ''), admin.password_hash)) error = 'Your current password is incorrect.';
  else if (String(password || '').length < 12) error = 'Use a new password of at least 12 characters.';
  else if (password !== confirm) error = 'The new passwords don\'t match.';
  if (error) return res.status(422).adminPage('account', { title: 'Account', error, flash: '' });
  db.get().prepare('UPDATE admins SET password_hash = ? WHERE id = ?').run(security.hashPassword(password), admin.id);
  db.get().prepare('DELETE FROM sessions WHERE admin_id = ?').run(admin.id);
  security.createSession(res, admin.id);
  res.redirect('/admin/account?flash=changed');
});

module.exports = router;
