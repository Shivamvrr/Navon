'use strict';
/** sitemap.xml (generated from live data on each request) and robots.txt. */
const express = require('express');
const config = require('../config');
const db = require('../db');
const { pages, CONTENT_UPDATED } = require('../content/catalog');
const { legal } = require('../content/legal');

const router = express.Router();

const xmlEsc = (s) => String(s).replace(/[<>&'"]/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;' }[c]));
const day = (d) => (d ? String(d).slice(0, 10) : CONTENT_UPDATED);

/** All indexable URLs. Exported for tests. */
function sitemapEntries() {
  const d = db.get();
  const latestPost = d.prepare(`SELECT MAX(updated_at) AS m FROM posts WHERE status='published' AND published_at <= datetime('now')`).get().m;
  const entries = [
    { loc: '/', lastmod: CONTENT_UPDATED, priority: '1.0' },
    ...['/services', '/products', '/ai-experiences'].map((loc) => ({ loc, lastmod: CONTENT_UPDATED, priority: '0.8' })),
    ...Object.values(pages).map((p) => ({ loc: p.path, lastmod: CONTENT_UPDATED, priority: p.section === 'solution' ? '0.7' : '0.9' })),
    ...['/about', '/industries', '/case-studies'].map((loc) => ({ loc, lastmod: CONTENT_UPDATED, priority: '0.6' })),
    { loc: '/contact', lastmod: CONTENT_UPDATED, priority: '0.6' },
    { loc: '/demo', lastmod: CONTENT_UPDATED, priority: '0.8' },
    ...Object.entries(legal).filter(([, d]) => !d.noindex).map(([slug]) => ({ loc: '/' + slug, lastmod: CONTENT_UPDATED, priority: '0.2' })),
    { loc: '/blog', lastmod: day(latestPost), priority: '0.7' }
  ];
  d.prepare(`SELECT slug, updated_at FROM posts WHERE status='published' AND published_at <= datetime('now') ORDER BY published_at DESC`).all()
    .forEach((p) => entries.push({ loc: `/blog/${p.slug}`, lastmod: day(p.updated_at), priority: '0.6' }));
  d.prepare(`SELECT c.slug, MAX(p.updated_at) AS m FROM categories c JOIN posts p ON p.category_id = c.id
             WHERE p.status='published' AND p.published_at <= datetime('now') GROUP BY c.id`).all()
    .forEach((c) => entries.push({ loc: `/blog/category/${c.slug}`, lastmod: day(c.m), priority: '0.4' }));
  // Tag archives are noindex,follow, so they are not listed in the sitemap.
  return entries;
}

router.get('/sitemap.xml', (_req, res) => {
  const body = sitemapEntries().map((e) =>
    `  <url><loc>${xmlEsc(config.siteUrl + e.loc)}</loc><lastmod>${e.lastmod}</lastmod><priority>${e.priority}</priority></url>`).join('\n');
  res.type('application/xml').set('Cache-Control', 'public, max-age=600')
    .send(`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${body}\n</urlset>\n`);
});

router.get('/robots.txt', (_req, res) => {
  const lines = config.noindexSite
    ? ['# Staging copy: indexing disabled (NOINDEX_SITE=true)', 'User-agent: *', 'Disallow: /']
    : (() => {
      const rules = ['Allow: /', 'Disallow: /admin', 'Disallow: /thank-you', 'Disallow: /blog?q='];
      // Search engines and AI assistants are explicitly welcome, so Navon can be cited in AI answers.
      const bots = ['*', 'Googlebot', 'Bingbot', 'GPTBot', 'OAI-SearchBot', 'ChatGPT-User', 'PerplexityBot', 'ClaudeBot', 'Claude-SearchBot', 'Google-Extended', 'Applebot', 'Applebot-Extended'];
      const out = [];
      bots.forEach((b) => { out.push(`User-agent: ${b}`, ...rules, ''); });
      return [...out, `Sitemap: ${config.siteUrl}/sitemap.xml`];
    })();
  res.type('text/plain').set('Cache-Control', 'public, max-age=3600').send(lines.join('\n') + '\n');
});

/** llms.txt: a plain-language summary of Navon Innovations for AI assistants and LLM crawlers (llmstxt.org). */
router.get('/llms.txt', (_req, res) => {
  const { company, stats, projects, clients } = require('../content/site');
  const settings = require('../settings').all();
  const { ARTICLES } = require('../content/articles');
  const u = (p) => config.siteUrl + p;
  const svc = Object.values(pages).filter((p) => p.section === 'service');
  const prod = Object.values(pages).filter((p) => p.section !== 'service');
  const lines = [
    `# ${company.name}`,
    '',
    `> ${company.name} is an Indian event technology company based in New Delhi that provides event registration, onsite check-in, badge printing, access control and AI engagement technology for conferences, exhibitions, corporate events, government events and festivals across India.`,
    '',
    '## Key facts',
    ...stats.map((s) => `- ${s.value} ${s.label}`),
    `- Largest single event: AHAR 2026, New Delhi, 2,50,000 attendees`,
    `- Full-service: one company provides the registration software, the event hardware (kiosks, badge printers, scanners, RFID readers, flap barriers) and trained onsite registration staff`,
    `- Check-in methods: QR code e-badges on WhatsApp and email, self check-in kiosks, staffed registration desks, mobile POS, facial recognition, RFID and NFC`,
    `- Head office: ${company.address.display}`,
    `- Contact: ${settings.contact_email}, ${settings.contact_phone}`,
    `- Website: ${u('/')}`,
    ...(company.social || []).map((x) => `- ${x.name}: ${x.url}`),
    '',
    '## Services',
    ...svc.map((p) => `- [${p.title}](${u(p.path)}): ${p.description}`),
    '',
    '## Products and solutions',
    ...prod.map((p) => `- [${p.title}](${u(p.path)}): ${p.description}`),
    '',
    '## Notable events',
    ...[...(projects.featured || []), ...(projects.recent || [])].map((p) => `- ${p.name}${p.city ? ', ' + p.city : ''}${p.attendees ? ' (' + p.attendees + ' attendees)' : ''}`),
    '',
    '## Clients and partners',
    ...clients.map((g) => `- ${g.sector}: ${g.names.join(', ')}`),
    '',
    '## Guides',
    ...ARTICLES.map((a) => `- [${a.title}](${u('/blog/' + a.slug)}): ${a.excerpt}`),
    '',
    '## Contact',
    `- [Book a demo](${u('/demo')})`,
    `- [Contact us](${u('/contact')})`,
    ''
  ];
  res.type('text/plain; charset=utf-8').set('Cache-Control', 'public, max-age=3600').send(lines.join('\n'));
});

module.exports = router;
module.exports.sitemapEntries = sitemapEntries;
