'use strict';
const express = require('express');
const seo = require('../seo');
const blog = require('../blog');
const blogLib = require('../blog');
const { showcase, ecosystem, technology, homeIndustries, pages, experiences, industries, byPath } = require('../content/catalog');
const { legal } = require('../content/legal');
const site = require('../content/site');

const router = express.Router();
const HOME = { name: 'Home', href: '/' };

/** Turn an internal path into a related-link card. */
function resolveLink(href) {
  const p = byPath[href];
  if (p) return { href, title: p.h1, label: navLabel(href) || p.kicker, text: p.description, icon: p.icon };
  const statics = {
    '/ai-experiences': { title: 'AI experiences', text: 'AI robot anchor, hologram box, AI photo booth, digital mosaic and more.', icon: 'bot' },
    '/case-studies': { title: 'Case studies', text: 'Events from corporate summits to 2,50,000-attendee exhibitions.', icon: 'trophy' }
  };
  return statics[href] ? { href, label: statics[href].title, ...statics[href] } : null;
}

function navLabel(href) {
  for (const g of site.nav.services) for (const i of g.items) if (i.href === href) return i.label;
  for (const i of site.nav.products) if (i.href === href) return i.label;
  return null;
}

/* ---------------- Home ---------------- */
router.get('/', (_req, res) => {
  res.page('home', {
    latest: blog.listPublished({ perPage: 3 }).posts, experiences, industries, showcase, ecosystem, technology, homeIndustries,
    meta: seo.meta({
      title: 'Navon Innovations | Event Registration & AI Engagement Tech', rawTitle: true,
      description: 'Event registration, badge printing, face recognition, RFID and NFC access control, attendee apps, AI engagement and live analytics on one platform. 350+ events delivered.',
      path: '/'
    })
  });
});

/* ---------------- Hubs ---------------- */
router.get('/services', (_req, res) => {
  res.page('hub', {
    hub: 'services', heading: 'Onsite event technology services', kicker: 'Services',
    lede: 'Onsite hardware, access control and expert operations for events of every size, from a 200-person conference to a 50,000-attendee exhibition.',
    groups: site.nav.services.map((g) => ({ name: g.group, items: g.items.map((i) => ({ ...i, page: byPath[i.href] })) })),
    meta: seo.meta({
      title: 'Event Technology Services | Registration, Access & Tracking', rawTitle: true,
      description: 'Navon event technology services: onsite registration, smart kiosks, registration desks, mobile POS, badge printing, face recognition, RFID, flap barriers, QR tracking and NFC payments.',
      path: '/services', crumbs: [HOME, { name: 'Services', href: '/services' }]
    })
  });
});

router.get('/products', (_req, res) => {
  res.page('hub', {
    hub: 'products', heading: 'Register. Run. Relive.', kicker: 'Products',
    lede: 'One platform sells the ticket, one app runs the ground, and AI finds every photo afterward, all under one login.',
    groups: [{ name: 'Navon software suite', items: site.nav.products.map((i) => ({ ...i, page: byPath[i.href] })) }],
    meta: seo.meta({
      title: 'Event Software Products | Platform, App & AI Photo Sharing', rawTitle: true,
      description: 'Navon event software: registration and ticketing platform with CRM, travel and analytics; branded event mobile app; and AI face-matched event photo sharing.',
      path: '/products', crumbs: [HOME, { name: 'Products', href: '/products' }]
    })
  });
});

router.get('/ai-experiences', (_req, res) => {
  res.page('experiences', {
    experiences,
    page: { whatsappTopic: 'AI engagement experiences' },
    meta: seo.meta({
      title: 'AI Event Experiences | Robot Anchor, Hologram & Photo Booth', rawTitle: true,
      description: 'AI engagement experiences for events and brand activations: AI robot anchor, hologram box, AI photo booth, sketch AI robot, digital mosaic and social media walls, AR/VR gaming and more.',
      path: '/ai-experiences', crumbs: [HOME, { name: 'AI experiences', href: '/ai-experiences' }],
      schema: [seo.service({ name: 'AI event engagement experiences', description: 'AI robot anchor, hologram box, AI photo booth, sketch AI robot, digital mosaic wall and more for events.', path: '/ai-experiences', serviceType: 'Event engagement experiences' })]
    })
  });
});

/* ---------------- Detail pages ---------------- */
Object.values(pages).forEach((page) => {
  router.get(page.path, (_req, res) => {
    const parent = page.section === 'service' ? { name: 'Services', href: '/services' } : page.section === 'product' ? { name: 'Products', href: '/products' } : null;
    const crumbs = [HOME, ...(parent ? [parent] : []), { name: navLabel(page.path) || page.kicker, href: page.path }];
    res.page('detail', {
      page,
      related: (page.related || []).map(resolveLink).filter(Boolean),
      preloadImage: page.heroImage,
      meta: seo.meta({
        title: page.title, rawTitle: true, description: page.description, path: page.path, crumbs,
        image: page.heroImage, imageAlt: page.heroAlt,
        schema: page.serviceType ? [seo.service({ name: navLabel(page.path) || page.kicker, description: page.description, path: page.path, serviceType: page.serviceType })] : []
      })
    });
  });
});

/* ---------------- Company ---------------- */
router.get('/about', (_req, res) => {
  res.page('about', {
    page: { whatsappTopic: 'event technology' },
    meta: seo.meta({
      title: 'About Navon Innovations | Event Technology Company, New Delhi', rawTitle: true,
      description: 'Navon Innovations builds a unified event technology platform: registration, ticketing, badge printing, RFID/NFC, kiosks, apps and onsite operations. Founded 2025, New Delhi.',
      path: '/about', crumbs: [HOME, { name: 'About', href: '/about' }],
      schema: [{ '@type': 'AboutPage', url: seo.abs('/about'), name: 'About Navon Innovations', about: { '@id': seo.abs('/') + '#organization' } }]
    })
  });
});

router.get('/industries', (_req, res) => {
  res.page('industries', {
    industries,
    meta: seo.meta({
      title: 'Industries We Serve | Conferences, Exhibitions & Festivals', rawTitle: true,
      description: 'Event technology for conferences, medical congresses, exhibitions, corporate events, government programmes, universities, festivals and stadiums, deployed pan-India.',
      path: '/industries', crumbs: [HOME, { name: 'Industries', href: '/industries' }]
    })
  });
});

router.get('/case-studies', (_req, res) => {
  res.page('case-studies', {
    meta: seo.meta({
      title: 'Case Studies & Projects | Navon Innovations', rawTitle: true,
      description: 'Navon Innovations projects: AHAR 2026 (2,50,000 attendees), Global Garba Festival, India International Science Festival, AWS, GitHub, Cisco, KPMG and 350+ events.',
      path: '/case-studies', crumbs: [HOME, { name: 'Case studies', href: '/case-studies' }]
    })
  });
});

/* ---------------- Legal ---------------- */
Object.entries(legal).forEach(([slug, doc]) => {
  const html = blogLib.renderMarkdown(doc.body);
  router.get('/' + slug, (_req, res) => {
    res.page('legal', {
      doc, html, toc: blogLib.toc(html), hideFooterForm: true,
      meta: seo.meta({ title: `${doc.title} | Navon Innovations`, rawTitle: true, description: doc.description, path: '/' + slug, crumbs: [HOME, { name: doc.title, href: '/' + slug }], noindex: !!doc.noindex })
    });
  });
});

/* ---------------- Redirects (earlier URLs → current pages) ---------------- */
const redirects = {
  '/book-a-demo': '/demo', '/solutions': '/services', '/onsite-event-registration': '/event-registration-services',
  '/facial-recognition-event-registration': '/face-recognition', '/rfid-nfc-event-solutions': '/rfid-tracking',
  '/event-badge-printing': '/badge-printing', '/delegate-management-solutions': '/delegate-management',
  '/event-management-dashboard': '/platform', '/event-management-technology': '/platform',
  '/event-registration-software': '/platform', '/qr-code-event-registration': '/qr-code-tracking',
  '/mobile-event-app': '/event-mobile-app', '/why-navon-innovations': '/about', '/event-workflow': '/event-registration-services',
  '/ai-event-engagement': '/ai-experiences', '/platform-overview': '/platform'
};
Object.entries(redirects).forEach(([from, to]) => router.get(from, (_req, res) => res.redirect(301, to)));
router.get('/products/:slug', (req, res, next) => {
  const map = { 'self-service-registration-kiosk': '/smart-kiosks', 'facial-recognition-check-in': '/face-recognition', 'flap-barrier-smart-entry': '/automated-flap-barriers',
    'label-print-pos-mobile-check-in': '/mobile-pos', 'rfid-smart-tracking-reader': '/rfid-tracking', 'nfc-cashless-payment-device': '/nfc-payments', 'qr-code-scanner': '/qr-code-tracking',
    'mobile-event-app': '/event-mobile-app', 'event-badges-and-lanyards': '/badge-printing', 'ai-art-badges': '/badge-printing' };
  if (map[req.params.slug]) return res.redirect(301, map[req.params.slug]);
  if (experiences.some((x) => x.id === req.params.slug) || ['ai-photo-booth-and-mosaic', 'robots-and-holograms', 'ai-sketch-robot'].includes(req.params.slug)) return res.redirect(301, '/ai-experiences');
  next();
});

module.exports = router;
module.exports.resolveLink = resolveLink;
