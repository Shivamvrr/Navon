'use strict';
/**
 * Public form endpoints. Each works without JavaScript (POST + redirect)
 * and with JavaScript (fetch with Accept: application/json → JSON response).
 */
const express = require('express');
const rateLimit = require('express-rate-limit');
const security = require('../security');
const forms = require('../forms');
const seo = require('../seo');
const config = require('../config');

const router = express.Router();

const limiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: config.formRateLimit,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  handler: (req, res) => respondError(req, res, 429, 'Too many submissions from your network. Wait a few minutes and try again, or contact us on WhatsApp or by phone.', {})
});

const wantsJson = (req) => (req.get('accept') || '').includes('application/json');

function respondError(req, res, status, message, errors, view, values) {
  if (wantsJson(req) || !view) return res.status(status).json({ ok: false, message, errors });
  return view(res.status(status), { message, errors, values });
}

function meta(req) {
  const src = String(req.body._source || req.get('referer') || '').slice(0, 300);
  let source = src;
  try { source = new URL(src).pathname; } catch (_e) { /* keep as-is */ }
  return { source, ipHash: security.hashIp(req.ip), ua: String(req.get('user-agent') || '').slice(0, 300) };
}

async function handle(req, res, { validate, save, view, kind }) {
  const values = req.body || {};
  const spam = security.checkSpam(values);
  if (spam) {
    // Do not reveal which check failed; ask the person to retry.
    return respondError(req, res, 400, 'We couldn\'t verify this submission. Refresh the page and try again, or contact us on WhatsApp or by phone.', {}, view, values);
  }
  if (!(await security.verifyTurnstile(values['cf-turnstile-response'], req.ip))) {
    return respondError(req, res, 400, 'Complete the verification check and submit again.', {}, view, values);
  }
  const { data, errors } = validate(values);
  if (Object.keys(errors).length) {
    return respondError(req, res, 422, 'Some details need attention. Check the highlighted fields.', errors, view, values);
  }
  let result;
  try {
    result = await save(data, meta(req));
  } catch (e) {
    console.error(`[forms] could not save ${kind}`, e);
    return respondError(req, res, 500, 'Your request could not be saved because of a server error. Try again, or contact us on WhatsApp or by phone.', {}, view, values);
  }
  const message = kind === 'demo'
    ? `Thank you, ${data.name.split(' ')[0]}. Your demo request ${result.ref} has been received. Our team will contact you to confirm a time.`
    : `Thank you, ${data.name.split(' ')[0]}. Your enquiry ${result.ref} has been received. Our team will get back to you.`;
  if (wantsJson(req)) return res.json({ ok: true, ref: result.ref, message });
  return res.redirect(303, `/thank-you?type=${kind}&ref=${encodeURIComponent(result.ref)}`);
}

const contactView = (res, state) => res.page('contact', {
  meta: seo.meta({ title: 'Contact Navon Innovations | Get a Custom Quote', rawTitle: true, description: 'Talk to Navon Innovations about smart event registration, RFID tracking, face recognition and AI engagement. Office in Dwarka, New Delhi; pan-India deployments.', path: '/contact', crumbs: [{ name: 'Home', href: '/' }, { name: 'Contact', href: '/contact' }] }),
  formState: state, hideFooterForm: true
});
const demoView = (res, state) => res.page('book-a-demo', {
  meta: seo.meta({ title: 'Book a Live Demo | Navon Innovations', rawTitle: true, description: 'Book a 30-minute live demo of Navon\'s smart registration, RFID access, face recognition and AI engagement platform, tailored to your event.', path: '/demo', crumbs: [{ name: 'Home', href: '/' }, { name: 'Book a demo', href: '/demo' }] }),
  formState: state, hideFooterForm: true
});

router.get('/contact', (_req, res) => contactView(res, null));
router.get('/demo', (_req, res) => demoView(res, null));

router.post('/contact', limiter, (req, res, next) =>
  handle(req, res, { validate: forms.validateEnquiry, save: forms.saveEnquiry, view: contactView, kind: 'contact' }).catch(next));

router.post(['/demo', '/book-a-demo'], limiter, (req, res, next) =>
  handle(req, res, { validate: forms.validateDemo, save: forms.saveDemo, view: demoView, kind: 'demo' }).catch(next));

router.get('/thank-you', (req, res) => {
  const type = req.query.type === 'demo' ? 'demo' : 'contact';
  const ref = /^(ENQ|DEMO)-\d{6}$/.test(String(req.query.ref || '')) ? req.query.ref : '';
  res.page('thank-you', {
    type, ref, hideFooterForm: true,
    meta: seo.meta({ title: 'Thank you | Navon Innovations', rawTitle: true, description: 'Your request has been received.', path: '/thank-you', noindex: true })
  });
});

module.exports = router;
