'use strict';
/**
 * First-run seed: blog categories and three starter articles written from
 * Navon Innovations' documented services. Runs only when the posts table is empty.
 * Review and edit these in Admin → Blog before launch.
 */
const db = require('./db');
const blog = require('./blog');

const CATEGORIES = [
  { name: 'Event technology', slug: 'event-technology', description: 'How QR, RFID, NFC, facial recognition and AI are used at events.' },
  { name: 'Event registration', slug: 'event-registration', description: 'Guides to online registration, forms, ticketing and pre-event communication.' },
  { name: 'Onsite operations', slug: 'onsite-operations', description: 'Practical guidance for registration counters, check-in, badges and delegate tracking.' },
  { name: 'Buying guides', slug: 'buying-guides', description: 'Checklists and comparisons for choosing event registration and event technology partners in India.' }
];

const POSTS = [
  {
    title: 'QR, RFID and NFC at events: how they work together',
    slug: 'qr-rfid-nfc-at-events',
    category: 'event-technology',
    tags: 'QR code, RFID, NFC, Delegate tracking',
    excerpt: 'QR codes, RFID and NFC each solve a different problem at an event. Here is where each one fits, and why running them on one platform matters.',
    seo_title: 'QR vs RFID vs NFC at Events: How They Work Together',
    meta_description: 'Where QR codes, RFID and NFC each fit at an event, from check-in to meal and kit tracking, and why running them on one connected platform matters.',
    featured_image: '/img/blog/qr-rfid-nfc-at-events.webp',
    featured_image_alt: 'Illustration of an NFC wristband tapping a payment terminal, for QR, RFID and NFC at events',
    content_md: `Event organisers are often asked to choose between QR codes, RFID and NFC. In practice, the most effective events use more than one, because each technology is suited to a different moment in the attendee journey.

## QR codes: the fastest way to get started

A QR code is generated for every attendee at registration and delivered with their e-badge by email and WhatsApp. Because attendees already carry it on their phone, QR is the quickest technology to roll out.

QR codes are well suited to:

- **Check-in at the registration counter**, where a scan pulls up the attendee's record and a badge can be printed within 15 seconds
- **Self-service kiosks**, where attendees scan their own code and print badges and certificates
- **Checkpoints** such as meal counters, kit distribution and session entry

Learn more about [QR code event registration](/qr-code-tracking).

## RFID: contactless tracking at busy points

RFID badges can be read without the attendee taking anything out of a pocket. That makes RFID useful wherever queues build up or where you want to log movement without slowing people down.

Typical RFID uses include:

- Session and hall entry, feeding **session and hall attendance** reports
- Meal access, feeding the **food and beverage report**
- Gift and kit collection, so organisers can confirm items were allocated correctly

## NFC: tap-to-pay and tap-to-track

[Near-field communication](https://en.wikipedia.org/wiki/Near-field_communication) works over a very short range, so it suits deliberate actions such as paying or confirming a handover. At events, NFC is used for **cashless payment and tracking** at counters and checkpoints.

## Why one platform matters

The technology matters less than where the data goes. When QR, RFID and NFC scans all land in the same system, every scan updates the same attendee record and the same live dashboard:

1. The registration ID created online is the one scanned at check-in.
2. Every checkpoint scan, whatever the technology, is recorded against that attendee.
3. Reports for registration, attendance, sessions, food, kits and gifts update as scans happen.

That is the approach behind Navon's [event management technology platform](/platform): register, check in, then track and analyse, in one connected ecosystem.

## Choosing the right mix

| Touchpoint | Common choice |
| --- | --- |
| Check-in counter | QR code, or facial recognition for 2-second entry |
| Halls and sessions | RFID or QR scanning |
| Meals, kits and gifts | QR, RFID or NFC scans |
| Payments | NFC cashless payment |

If you are planning an event and want to talk through the right setup, [book a demo](/demo) with our team.`
  },
  {
    title: 'Planning onsite registration: a checklist for fast check-in',
    slug: 'onsite-registration-checklist',
    category: 'onsite-operations',
    tags: 'Onsite registration, Badge printing, Check-in',
    excerpt: 'A practical checklist for onsite registration: pre-registration, QR e-badges, counter layout, walk-ins, kiosks and badge printing.',
    seo_title: 'Onsite Event Registration Checklist for Fast Check-in',
    meta_description: 'A practical onsite event registration checklist: QR e-badges, counter set-up, walk-in handling, self-service kiosks and badge printing within 15 seconds.',
    featured_image: '/img/blog/onsite-registration-checklist.webp',
    featured_image_alt: 'Illustration of live lunch and session counters with a collected confirmation',
    content_md: `The registration counter is the first thing attendees experience at your event. A well-planned counter checks each attendee in and hands over a printed badge within 15 seconds. This checklist covers what to plan before the doors open.

## Before the event

### Get attendees pre-registered

The more attendees who register online, the faster the counter runs on the day. Use a custom registration form or event microsite, and make sure confirmations go out automatically.

### Send every attendee a QR code

Each attendee should receive a unique QR code and personalised e-badge by email and WhatsApp. At the counter, one scan replaces typing a name.

### Share pre-event information

Send clear instructions and event details in advance: where registration is, what to bring, and when counters open.

See how this works in [online event registration](/online-event-registration).

## At the venue

### Set up event-branded counters

Organised, event-branded counters help attendees find the right desk and make a strong first impression. Each desk needs laptop or tablet and printer support.

### Plan for every type of arrival

- **Pre-registered attendees** scan their QR code or are found by name
- **Walk-ins** are registered on the spot
- **Attendees without their QR code** are checked in with search-based check-in

### Add self-service kiosks

Self-service registration kiosks let attendees scan their QR code and print badges and certificates themselves, which keeps counter queues short.

### Consider facial recognition

For pre-registered attendees, [facial recognition check-in](/face-recognition) lets them walk in and enter in 2 seconds: AI matches the face to registration data, prints the badge and logs attendance.

## After check-in

Check-in is the start of tracking, not the end. With QR, RFID or NFC badges, the same badge records meals, kits, gifts, certificates and session entry. The badge printing report keeps a log of prints and reprints, and attendance figures update live on the [event dashboard](/platform).

## Quick checklist

1. Online registration open with automated confirmations
2. QR codes and e-badges sent by email and WhatsApp
3. Pre-event information shared
4. Event-branded counters with laptops, tablets and printers
5. Walk-in and search-based check-in ready
6. Self-service kiosks placed where queues form
7. Badge stock chosen: Iberia paper with pouch, eco-friendly paper, PVC or non-tearable paper
8. Checkpoint scanning planned for meals, kits and sessions

Need help planning? [Talk to our team](/contact) about [onsite event registration](/event-registration-services).`
  },
  {
    title: 'Registration for medical conferences: compliance, attendance and certification',
    slug: 'medical-conference-registration',
    category: 'event-registration',
    tags: 'Medical conferences, Registration forms, Certificates',
    excerpt: 'Medical conferences have specific registration needs: council compliance, attendance tracking and certification point distribution. Here is how to handle them.',
    seo_title: 'Medical Conference Registration: Compliance & Certificates',
    meta_description: 'How medical conference registration handles council compliance, attendance tracking, certification point distribution and certificate collection per delegate.',
    featured_image: '/img/blog/medical-conference-registration.webp',
    featured_image_alt: 'Illustration of an event app showing session and photo notifications for conference delegates',
    content_md: `Medical conferences ask more of their registration systems than most events. Organisers need to meet council requirements, prove attendance and distribute certification points accurately. Navon has supported medical conferences including ESR India Summit, RGCON, Cancer Connect, Oncology Update, Neurotrauma, IIRSI Winter, UPORTHOCON and YUGM.

## Start with the right registration form

Medical registration forms are streamlined for medical events, ensuring compliance with council requirements, attendance tracking and certification point distribution. Collecting the right details at registration avoids chasing delegates for information later.

Read more about [online event registration](/online-event-registration) and the [registration types we support](/platform).

## Track attendance where it counts

Certification often depends on proving that a delegate attended specific sessions. With QR, RFID or NFC badges, **session and hall scanning** records entry to each session, and the **session and hall attendance** report shows participation by session and hall occupancy.

## Distribute certificates with a record

Certificate distribution is recorded per delegate, so organisers know exactly who has collected their certificate. Self-service kiosks can also print certificates for attendees.

## Keep the rest of the event running smoothly

Medical conferences also involve meals, kits and delegate materials. Navon's [delegate management solutions](/delegate-management) track:

- Food distribution with QR, RFID or NFC scans
- Kit distribution, confirming handover to every attendee
- Gift tracking per attendee

## Reports for organisers and councils

After the event, organisers have registration, attendance, session, food and kit reports, plus post-event analytics summarising registrations, badge printing, attendance and engagement. See the [event management dashboard](/platform) for the full list.

Planning a medical conference? [Book a demo](/demo) to see the registration and tracking set-up.`
  }
];

function seedIfEmpty() {
  const d = db.get();
  const insCat = d.prepare('INSERT OR IGNORE INTO categories (name, slug, description) VALUES (?, ?, ?)');
  CATEGORIES.forEach((c) => insCat.run(c.name, c.slug, c.description));
  if (d.prepare('SELECT COUNT(*) AS n FROM posts').get().n > 0) return;
  POSTS.forEach((p, i) => {
    const cat = d.prepare('SELECT id FROM categories WHERE slug = ?').get(p.category);
    const published = new Date(Date.now() - (POSTS.length - i + 10) * 86400e3).toISOString().slice(0, 19).replace('T', ' ');
    blog.save(null, {
      title: p.title, slug: p.slug, excerpt: p.excerpt, content_md: p.content_md, seo_title: p.seo_title,
      meta_description: p.meta_description, og_title: '', og_description: '', featured_image: p.featured_image,
      featured_image_alt: p.featured_image_alt, author: 'Navon Innovations', category_id: cat ? cat.id : null,
      status: 'published', published_at: published, tags: p.tags
    });
  });
  console.log(`[seed] Added ${POSTS.length} starter blog posts. Review them in Admin → Blog.`);
}

module.exports = { seedIfEmpty, CATEGORIES };
