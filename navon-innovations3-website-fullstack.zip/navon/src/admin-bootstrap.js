'use strict';
/** Creates the first admin from ADMIN_EMAIL / ADMIN_PASSWORD when no admin exists. */
const db = require('./db');
const config = require('./config');
const { hashPassword } = require('./security');

function createAdmin(email, password, name = '') {
  if (!email || !password) throw new Error('Email and password are required.');
  if (password.length < 12) throw new Error('Use a password of at least 12 characters.');
  db.get().prepare(
    `INSERT INTO admins (email, name, password_hash) VALUES (?, ?, ?)
     ON CONFLICT(email) DO UPDATE SET password_hash = excluded.password_hash, name = excluded.name`
  ).run(email.trim(), name, hashPassword(password));
}

function ensureInitialAdmin() {
  const n = db.get().prepare('SELECT COUNT(*) AS n FROM admins').get().n;
  if (n > 0) return;
  if (config.adminEmail && config.adminPassword) {
    try {
      createAdmin(config.adminEmail, config.adminPassword, 'Administrator');
      console.log(`[admin] Created admin account ${config.adminEmail}. Remove ADMIN_PASSWORD from the environment after first login.`);
    } catch (e) { console.error('[admin] Could not create admin:', e.message); }
  } else {
    console.warn('[admin] No admin account exists. Set ADMIN_EMAIL and ADMIN_PASSWORD, or run: npm run create-admin');
  }
}

module.exports = { ensureInitialAdmin, createAdmin };
