'use strict';
/**
 * SEO helpers: page metadata, canonical URLs and JSON-LD structured data.
 * Structured data uses only documented company information from content/site.js.
 */
const config = require('./config');
const settings = require('./settings');
const { company } = require('./content/site');

const DEFAULT_OG = '/img/og/navon-innovations-og.jpg';

const abs = (p) => (/^https?:\/\//.test(p) ? p : config.siteUrl + (p.startsWith('/') ? p : '/' + p));

/** Keep titles within ~60 characters and descriptions within ~160. */
function clamp(str, max) {
  const s = String(str || '').replace(/\s+/g, ' ').trim();
  if (s.length <= max) return s;
  const cut = s.slice(0, max - 1);
  return cut.slice(0, cut.lastIndexOf(' ')) + '…';
}

function organization() {
  const s = settings.all();
  const org = {
    '@type': 'Organization',
    '@id': config.siteUrl + '/#organization',
    name: company.name,
    url: config.siteUrl + '/',
    logo: { '@type': 'ImageObject', url: abs(company.logo), width: 455, height: 175 },
    slogan: company.tagline,
    description: company.description,
    contactPoint: [{
      '@type': 'ContactPoint',
      contactType: 'sales',
      email: s.contact_email,
      telephone: s.contact_phone.replace(/\s+/g, ''),
      areaServed: 'IN',
      availableLanguage: ['English']
    }]
  };
  org.foundingDate = company.foundingDate;
  org.areaServed = { '@type': 'Country', name: 'India' };
  org.knowsAbout = ['Event registration', 'Online event registration', 'Onsite event registration', 'Event check-in', 'QR code check-in', 'Facial recognition check-in', 'RFID event tracking', 'NFC cashless payments', 'Badge printing', 'Self check-in kiosks', 'Flap barriers', 'Event mobile app', 'AI photo sharing', 'Event analytics'];
  if (company.social && company.social.length) org.sameAs = company.social.map((x) => x.url);
  org.address = { '@type': 'PostalAddress', streetAddress: company.address.street, addressLocality: company.address.city, addressRegion: company.address.region, postalCode: company.address.postalCode, addressCountry: company.address.country };
  if (s.contact_email) org.email = s.contact_email;
  if (s.contact_phone) org.telephone = s.contact_phone.replace(/\s+/g, '');
  return org;
}

function website() {
  return {
    '@type': 'WebSite',
    '@id': config.siteUrl + '/#website',
    url: config.siteUrl + '/',
    name: company.name,
    description: company.descriptor,
    publisher: { '@id': config.siteUrl + '/#organization' },
    inLanguage: 'en-IN',
    potentialAction: {
      '@type': 'SearchAction',
      target: { '@type': 'EntryPoint', urlTemplate: config.siteUrl + '/blog?q={search_term_string}' },
      'query-input': 'required name=search_term_string'
    }
  };
}

function breadcrumbList(crumbs) {
  return {
    '@type': 'BreadcrumbList',
    itemListElement: crumbs.map((c, i) => ({ '@type': 'ListItem', position: i + 1, name: c.name, item: abs(c.href) }))
  };
}

function service({ name, description, path, serviceType }) {
  return {
    '@type': 'Service',
    '@id': abs(path) + '#service',
    name,
    serviceType: serviceType || name,
    description,
    url: abs(path),
    provider: { '@id': config.siteUrl + '/#organization' },
    areaServed: { '@type': 'Country', name: company.areaServed }
  };
}

function article(post) {
  const img = post.featured_image ? abs(post.featured_image) : abs(DEFAULT_OG);
  return {
    '@type': 'BlogPosting',
    '@id': abs('/blog/' + post.slug) + '#article',
    headline: clamp(post.title, 110),
    description: post.meta_description || post.excerpt,
    image: [img],
    datePublished: toIso(post.published_at),
    dateModified: toIso(post.updated_at || post.published_at),
    author: { '@type': post.author === company.name ? 'Organization' : 'Person', name: post.author },
    publisher: { '@id': config.siteUrl + '/#organization' },
    mainEntityOfPage: { '@type': 'WebPage', '@id': abs('/blog/' + post.slug) },
    articleSection: post.category_name || undefined,
    keywords: post.tags && post.tags.length ? post.tags.map((t) => t.name).join(', ') : undefined,
    inLanguage: 'en-IN'
  };
}

/** FAQPage structured data from a list of { q, a } pairs. */
function faqPage(items, url) {
  if (!items || !items.length) return null;
  return {
    '@type': 'FAQPage',
    '@id': abs(url) + '#faq',
    mainEntity: items.map((f) => ({ '@type': 'Question', name: f.q, acceptedAnswer: { '@type': 'Answer', text: f.a } }))
  };
}

/** Read "### Question" + answer pairs from a "## Frequently asked questions" section of a Markdown post. */
function faqFromMarkdown(md) {
  const m = String(md || '').match(/^##\s+(?:Frequently asked questions|FAQs?)\s*$([\s\S]*?)(?=^##\s|^---\s*$|(?![\s\S]))/mi);
  if (!m) return [];
  const out = [];
  m[1].split(/^###\s+/m).slice(1).forEach((chunk) => {
    const lines = chunk.trim().split('\n');
    const q = lines.shift().trim();
    const a = lines.join(' ').replace(/\[([^\]]+)\]\([^)]+\)/g, '$1').replace(/[*_`]/g, '').replace(/\s+/g, ' ').trim();
    if (q && a) out.push({ q, a });
  });
  return out;
}

function toIso(sqlDate) {
  if (!sqlDate) return undefined;
  const d = new Date(String(sqlDate).replace(' ', 'T') + (String(sqlDate).includes('Z') || /[+-]\d\d:?\d\d$/.test(sqlDate) ? '' : 'Z'));
  return isNaN(d) ? undefined : d.toISOString();
}

/**
 * Build the metadata object used by views/partials/head.ejs.
 * @param {object} o  title, description, path, image, imageAlt, type, noindex, crumbs, schema (extra nodes)
 */
function meta(o) {
  const title = o.rawTitle ? o.title : clamp(o.title, 65);
  const description = clamp(o.description, 160);
  const nodes = [organization(), website()];
  if (o.crumbs && o.crumbs.length) nodes.push(breadcrumbList(o.crumbs));
  if (o.schema) nodes.push(...[].concat(o.schema));
  return {
    title,
    description,
    canonical: abs(o.canonicalPath || o.path || '/'),
    image: abs(o.image || DEFAULT_OG),
    imageAlt: o.imageAlt || `${company.name}: ${company.descriptor}`,
    type: o.type || 'website',
    noindex: !!o.noindex || config.noindexSite,
    follow: !!o.follow && !config.noindexSite,
    article: o.article || null,
    jsonLd: JSON.stringify({ '@context': 'https://schema.org', '@graph': nodes }).replace(/</g, '\\u003c'),
    crumbs: o.crumbs || null
  };
}

module.exports = { meta, abs, clamp, service, article, breadcrumbList, organization, toIso, DEFAULT_OG, faqPage, faqFromMarkdown };
