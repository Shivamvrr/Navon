'use strict';
/**
 * Central configuration, read from environment variables (see .env.example).
 * Values marked "admin-editable" can also be changed later in Admin → Settings;
 * a value saved there takes precedence over the environment default.
 */
require('dotenv').config({ quiet: true });
const path = require('node:path');

const bool = (v, d = false) => (v === undefined || v === '' ? d : /^(1|true|yes|on)$/i.test(v));
const env = process.env;

const config = {
  env: env.NODE_ENV || 'development',
  isProd: env.NODE_ENV === 'production',
  port: parseInt(env.PORT || '3000', 10),

  // Public URL of the site, used for canonical URLs, sitemap and structured data.
  siteUrl: (env.SITE_URL || 'https://navoninnovations.com').replace(/\/+$/, ''),
  // Only set to true on a staging copy. Production must stay indexable.
  noindexSite: bool(env.NOINDEX_SITE, false),
  trustProxy: bool(env.TRUST_PROXY, true),
  // Max form submissions per IP per 10 minutes (contact + demo combined per form).
  formRateLimit: parseInt(env.FORM_RATE_LIMIT || '6', 10),

  dbFile: env.DB_FILE || path.join(__dirname, '..', 'data', 'navon.db'),
  uploadDir: env.UPLOAD_DIR || path.join(__dirname, '..', 'public', 'uploads'),

  // Secret for signing form tokens. MUST be set to a long random value in production.
  appSecret: env.APP_SECRET || 'dev-only-insecure-secret-change-me',

  // First admin account, created on first start if no admin exists.
  adminEmail: env.ADMIN_EMAIL || '',
  adminPassword: env.ADMIN_PASSWORD || '',

  // Email (SMTP). Without SMTP_HOST, submissions are still saved but no email is sent.
  smtp: {
    host: env.SMTP_HOST || '',
    port: parseInt(env.SMTP_PORT || '587', 10),
    secure: bool(env.SMTP_SECURE, false),
    user: env.SMTP_USER || '',
    pass: env.SMTP_PASS || '',
    from: env.MAIL_FROM || '',
    ignoreTLS: bool(env.SMTP_IGNORE_TLS, false)
  },

  // Optional Cloudflare Turnstile CAPTCHA (in addition to built-in honeypot, timing and rate limits).
  turnstile: {
    siteKey: env.TURNSTILE_SITE_KEY || '',
    secretKey: env.TURNSTILE_SECRET_KEY || ''
  },

  // Admin-editable defaults
  defaults: {
    notify_email: env.NOTIFY_EMAIL || 'sales@navoninnovations.com',
    whatsapp_number: env.WHATSAPP_NUMBER || '919899445735',
    whatsapp_message: env.WHATSAPP_MESSAGE || 'Hi Navon Innovations, I am interested in your event technology solutions.',
    ga4_id: env.GA4_MEASUREMENT_ID || '',
    gtm_id: env.GTM_CONTAINER_ID || '',
    google_site_verification: env.GOOGLE_SITE_VERIFICATION || '',
    bing_site_verification: env.BING_SITE_VERIFICATION || '',
    contact_phone: env.CONTACT_PHONE || '+91 96544 96952',
    contact_email: env.CONTACT_EMAIL || 'sales@navoninnovations.com'
  }
};

if (config.isProd && config.appSecret.startsWith('dev-only')) {
  console.warn('[config] APP_SECRET is not set. Set a long random APP_SECRET before going live.');
}

module.exports = config;
