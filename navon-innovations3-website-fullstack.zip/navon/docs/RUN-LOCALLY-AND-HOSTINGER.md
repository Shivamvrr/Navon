# Navon website: apne computer par chalana aur Hostinger par live karna

Ye website **Node.js** par chalti hai (Express + SQLite database + admin panel). Isliye ye sirf PHP wali normal shared hosting par nahi chalegi. Hostinger par ise **VPS** par, ya agar aapke plan mein **Node.js Web App** ka option hai to wahan, chalaya ja sakta hai.

Zaroori: **Node.js version 22.13 ya usse naya** chahiye (site Node ka built-in SQLite use karti hai).

---

## Part 1: Apne computer (Windows / Mac) par test karna

1. **Node.js install karein**: https://nodejs.org se **22 LTS** (ya naya) version download karke install karein.
   Check karne ke liye terminal / Command Prompt mein: `node -v` (v22.13 ya upar aana chahiye).
2. **Zip unzip karein**, jaise `Desktop/navon`.
3. Terminal us folder mein kholein:
   - Windows: folder kholkar address bar mein `cmd` likhkar Enter.
   - Mac: Terminal mein `cd ` likhkar folder ko drag karein, Enter.
4. Packages install karein:
   ```
   npm install
   ```
5. `.env.example` file ki copy banakar uska naam **`.env`** rakhein, aur usmein ye do lines bharein:
   ```
   ADMIN_EMAIL=aapka-email@example.com
   ADMIN_PASSWORD=koi-strong-password
   ```
6. Site chalayein:
   ```
   npm run local
   ```
7. Browser mein kholein:
   - Website: **http://localhost:3000**
   - Admin panel: **http://localhost:3000/admin** (upar wala email/password)

Pehli baar chalne par database apne aap ban jaata hai, aur saare blogs (cover images ke saath) apne aap jud jaate hain.
`npm run local` sirf testing ke liye hai. Live server par `npm start` use hota hai (neeche dekhein).

---

## Part 2 (Recommended): Hostinger VPS par live karna

Hostinger VPS (Ubuntu 22.04 / 24.04) par poora control milta hai aur Node 22 pakka chalta hai.

### 1. Server se connect karein
hPanel → **VPS** → apna server → **SSH access** se IP aur root password lein. Phir apne computer ke terminal mein:
```
ssh root@AAPKA_SERVER_IP
```

### 2. Node.js 22, Nginx aur PM2 install karein
```
curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
apt install -y nodejs nginx unzip
npm install -g pm2
node -v
```

### 3. Website upload karein
Apne computer se zip server par bhejein (naye terminal mein, apne computer par):
```
scp navon-innovations-website-fullstack.zip root@AAPKA_SERVER_IP:/var/www/
```
Phir server par:
```
cd /var/www
unzip navon-innovations-website-fullstack.zip
cd navon
npm ci --omit=dev
cp .env.example .env
nano .env
```

### 4. `.env` mein ye bharein
```
NODE_ENV=production
PORT=3000
SITE_URL=https://navoninnovations.com
APP_SECRET=        <- is command se banayein:  node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
ADMIN_EMAIL=aapka-email
ADMIN_PASSWORD=strong-password
TRUST_PROXY=true
```
Email notifications ke liye `SMTP_HOST`, `SMTP_USER`, `SMTP_PASS` bhi bharein (Hostinger email, Google Workspace ya Zoho Mail ki SMTP details). Inke bina forms save hote hain, lekin email nahi jaata.
Save: `Ctrl+O`, Enter, `Ctrl+X`.

### 5. Site ko hamesha chalu rakhein (PM2)
```
pm2 start npm --name navon -- start
pm2 save
pm2 startup
```
(`pm2 startup` jo command dikhaye, use copy karke chalayein, taaki server restart par site apne aap chalu ho jaaye.)

### 6. Nginx set karein (domain → site)
```
nano /etc/nginx/sites-available/navon
```
Isme ye paste karein:
```
server {
    listen 80;
    server_name navoninnovations.com www.navoninnovations.com;
    client_max_body_size 10M;
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```
Phir:
```
ln -s /etc/nginx/sites-available/navon /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx
```

### 7. Domain ko server par point karein
hPanel → **Domains** → navoninnovations.com → **DNS / Nameservers**:
- `A` record, name `@` → AAPKA_SERVER_IP
- `A` record, name `www` → AAPKA_SERVER_IP

(DNS update hone mein kuch minute se kuch ghante lag sakte hain.)

### 8. Free SSL (https) lagayein
```
apt install -y certbot python3-certbot-nginx
certbot --nginx -d navoninnovations.com -d www.navoninnovations.com
```

### 9. Pehli login ke baad
- https://navoninnovations.com/admin par login karein.
- Phir `.env` se `ADMIN_PASSWORD` line hata dein aur `pm2 restart navon` chalayein.
- Admin → Settings mein WhatsApp number, notification email, Google Search Console code aur GA4 ID check karein.

### Update karna (naya zip aane par)
```
cd /var/www
pm2 stop navon
cp -r navon/data /root/navon-data-backup
cp navon/.env /root/navon-env-backup
unzip -o navon-innovations-website-fullstack.zip
cd navon && npm ci --omit=dev
pm2 restart navon
```
`data/` folder (database) aur `.env` kabhi delete na karein. Zip mein ye dono nahi hote, isliye unzip karne se ye overwrite nahi hote.

### Backup
`/var/www/navon/data/` (database) aur `/var/www/navon/public/uploads/` (blog images) ka regular backup lein.

---

## Part 3 (Option): Hostinger Node.js Web App

Kuch Hostinger plans (jaise Business web hosting / Cloud) mein hPanel ke andar **Node.js app** banane ka option hota hai. Agar aapke plan mein ye hai:

1. hPanel → Websites → **Add website** → **Node.js app** (ya "Node.js Apps").
2. Zip upload karein (ya GitHub repository connect karein).
3. Settings:
   - **Node version:** 22.x (22.13 ya naya). Agar sirf 18 ya 20 milta hai, to ye site wahan nahi chalegi; VPS use karein.
   - **Entry file:** `server.js` / **Start command:** `npm start`
   - **Install command:** `npm install` (ya `npm ci --omit=dev`)
4. **Environment variables** mein `.env.example` wali saari values bharein (`NODE_ENV=production`, `SITE_URL`, `APP_SECRET`, `ADMIN_EMAIL`, `ADMIN_PASSWORD`, SMTP etc.).
5. Deploy karein aur domain connect karein.

Dhyan rakhein: database `data/navon.db` file mein rehta hai. Redeploy karne par ye file delete nahi honi chahiye. Agar platform har deploy par folder saaf kar deta hai, to `DB_FILE` aur `UPLOAD_DIR` ko kisi permanent folder par set karein, ya VPS use karein.

Hostinger ka panel samay ke saath badalta rehta hai. Koi option na mile to Hostinger support se poochein: "Node.js 22 app with persistent storage".

---

## Live hone ke baad (SEO)

`docs/SEO-AI-VISIBILITY-PLAN.md` dekhein: Google Search Console mein sitemap submit karna, Google Business Profile, reviews aur social media.
