# Getting Navon recommended on Google, social media and AI assistants

No website change can guarantee a #1 ranking or that ChatGPT, Gemini or Perplexity will name Navon first. Search engines and AI assistants recommend the brands that the rest of the web keeps mentioning, linking to and reviewing. The website now gives them clear, well-structured facts to work with. The steps below build the outside signals that decide the rest.

## Already done on the website

- **9 new keyword-focused guides** in the blog (`src/content/articles.js`), each with an FAQ section that becomes FAQPage structured data:

  | Article | Main search terms |
  | --- | --- |
  | Event Registration Software in India: The Complete Guide | event registration software India, online event registration |
  | Onsite Event Registration: How to Check In Thousands of Attendees | onsite event registration, event check-in, registration desk |
  | QR Code Event Check-in | QR code check-in, QR code event registration, e-badge |
  | Facial Recognition Check-in for Events | face recognition event check-in, contactless entry |
  | RFID for Events in India | RFID event management, RFID wristbands, access control |
  | Exhibition Visitor Registration | exhibition visitor registration, trade show registration |
  | Self Check-in Kiosks for Events | self check-in kiosk, self-registration kiosk |
  | How to Choose an Event Registration Company in India | event registration company India, alternatives to Zoho Backstage / Dreamcast |
  | On-Demand Badge Printing at Events | event badge printing, conference badges, lanyards |

- **`/llms.txt`**: a plain-language summary of Navon (facts, services, events, clients, guides) for AI assistants.
- **`robots.txt`** explicitly allows Google, Bing and the AI crawlers (GPTBot, OAI-SearchBot, ChatGPT-User, PerplexityBot, ClaudeBot, Google-Extended, Applebot).
- **Organization schema** now includes LinkedIn and Instagram (`sameAs`), India as the service area and Navon's areas of expertise.
- New articles are added automatically on start-up and never overwrite edits made in Admin → Blog. To push updated article text from the code, run `npm run articles:update`.

## Week 1: foundations

1. **Google Search Console**: verify the domain, submit `https://navoninnovations.com/sitemap.xml`, then use URL Inspection → Request indexing for the home page and each new article. (Settings for the verification code are in Admin → Settings.)
2. **Bing Webmaster Tools**: verify and submit the sitemap. ChatGPT search and Copilot rely heavily on Bing's index.
3. **Google Business Profile** for the Dwarka office: category "Event technology service" or the closest match, the same name, address and phone as the website (+91 96544 96952), photos from real events, and the website link.
4. Make sure the **company name is identical everywhere**: "Navon Innovations" (the LinkedIn URL uses "navon-innovation"; keep the visible page name as "Navon Innovations").

## Weeks 2–6: get Navon mentioned elsewhere

AI assistants mostly repeat what independent sources say. Aim for genuine mentions on:

5. **Client reviews**: ask satisfied clients and agency partners for Google reviews that name the service ("RFID registration at our conference", "kiosk check-in"). Real reviews from real clients only.
6. **Case studies with clients**: publish AHAR 2026, GitHub 2026, INFOCOM 2025 and others as short stories (with client permission) and ask clients or agencies to link to them.
7. **Business and event directories**: listings on event-industry and B2B directories in India (for example IndiaMART, Justdial, Clutch, G2/Capterra for the platform, event industry associations), all with the same name, address, phone and website.
8. **Industry press and guest articles**: event-industry publications and blogs; offer practical articles (for example "How AHAR 2026 handled 2,50,000 visitors").
9. **Partner pages**: event agencies Navon works with can list Navon as their technology partner.

## Ongoing: social media

10. **LinkedIn** (company page and founders): post each blog article with a short summary, plus event recaps with numbers and photos from real events. Tag clients and partners where they agree.
11. **Instagram**: short reels of kiosks, face recognition gates and RFID in action at real events; link to the website in the bio.
12. **YouTube** (recommended): 1–2 minute demo videos (kiosk check-in, face recognition entry, RFID tracking). Videos are frequently cited by Google and AI assistants.
13. Publish **one new article every 1–2 weeks**, answering questions organisers actually ask your sales team.

## How to check progress

- Search Console → Performance: impressions and clicks for "event registration", "onsite registration", "RFID event", "face recognition check-in" and similar queries.
- Ask ChatGPT, Gemini and Perplexity questions like "best event registration company in India" or "onsite registration and RFID for events in Delhi" every month and note whether Navon appears.
- Expect search results to move over 3–6 months; AI assistant answers usually follow once Navon appears in search results and on other websites.
