# SEO setup and launch checklist

SEO work improves how well Google can find, understand and present the site. It does **not** guarantee first-page rankings: those depend on competition, content quality over time, links from other sites and Google's own algorithms. This site gives you a correct technical foundation; the steps below make sure Google can use it.

---

## 1. What is already built in

| Area | Implementation |
|---|---|
| URLs | Short, descriptive, hyphenated (`/rfid-tracking`). Trailing slashes redirect to the canonical form. |
| Titles & descriptions | Unique per page (tested), titles about 60 characters or less, descriptions 120–160. Blog posts have their own SEO fields. |
| Headings | Exactly one H1 per page (tested), with H2/H3 sections. Blog content demotes `#` to H2 automatically. |
| Canonical URLs | Every page, built from `SITE_URL`. |
| XML sitemap | `/sitemap.xml`, generated live from the database: publishing or unpublishing a post updates it immediately. |
| robots.txt | `/robots.txt` allows everything except `/admin`, `/thank-you` and search results, and links the sitemap. |
| Structured data | Organization and WebSite (every page), Service (service pages), BlogPosting (posts), BreadcrumbList (all inner pages). Company data only: no address or claims that aren't in the company profile. |
| Social | Open Graph and X/Twitter card tags on every page; posts use their featured image and article tags. Default 1200×630 share image included. |
| Images | WebP, descriptive file names, `alt` text on every image (tested), lazy-loading below the fold, uploads auto-resized to 1600 px. |
| Internal links | Service pages link to related services; blog posts link to service pages; the Services and Products menus and the footer link every page. |
| Indexing | All public pages are `index, follow` (tested). Thank-you, admin, search results and tag archives are `noindex`; tag archives keep `follow`. |
| 404 | Custom page with search and useful links; returns a real 404 status. |
| Performance | Server-side rendering, gzip compression, long-lived caching for images, no front-end framework, fonts with `display=swap`, hero image prioritised. |
| Mobile | Responsive, mobile-first layouts; tested at 390 px wide. |

### Pages targeting search terms

| Search term | Page |
|---|---|
| Event registration services / onsite registration | `/event-registration-services` |
| Self-service registration kiosk | `/smart-kiosks` |
| Event registration desk | `/registration-desk` |
| Mobile POS badge printing | `/mobile-pos` |
| Face recognition event check-in | `/face-recognition` |
| RFID event tracking | `/rfid-tracking` |
| Flap barrier event access | `/automated-flap-barriers` |
| QR code event check-in | `/qr-code-tracking` |
| NFC cashless payments for events | `/nfc-payments` |
| Event badge printing | `/badge-printing` |
| Event registration and ticketing platform | `/platform` |
| Event mobile app | `/event-mobile-app` |
| AI event photo sharing | `/ai-photo-sharing` |
| Online event registration | `/online-event-registration` |
| Event check-in software | `/event-check-in-software` |
| Delegate management | `/delegate-management` |
| Corporate event technology | `/corporate-event-technology` |
| AI event engagement | `/ai-experiences` |

The service and product URLs match the live navoninnovations.com site, so existing search rankings carry over. URLs from earlier drafts redirect permanently (301) to these pages.

Each page has its own angle and content from Navon's documented services (tables, step-by-step explanations, FAQs and real project figures) rather than reworded copies of each other.

---

## 2. Google Search Console (do this on launch day)

1. Go to <https://search.google.com/search-console> and sign in with the company Google account.
2. **Add property → URL prefix** → enter `https://navoninnovations.com` (exactly your `SITE_URL`).
   - Alternatively choose **Domain** and verify with a DNS TXT record at your domain registrar; this covers `www` and all subdomains.
3. For URL-prefix verification choose **HTML tag**. Copy the tag, then paste it (or just its `content` value) into **Admin → Settings → Google Search Console verification code** and save.
4. Back in Search Console click **Verify**.
5. Open **Sitemaps**, enter `sitemap.xml` and click **Submit**. Status should change to "Success" within a day or so.
6. Use **URL inspection** on the home page and two or three service pages, and click **Request indexing**.
7. Check **Pages** (indexing report) after a week. Expect admin, thank-you and tag pages under "Excluded by noindex"; that is intentional.
8. Optional: repeat for Bing at <https://www.bing.com/webmasters> (you can import from Search Console) and paste its code into the Bing field.

## 3. Google Analytics 4

1. At <https://analytics.google.com> create a property for Navon Innovations, then a **Web** data stream for `https://navoninnovations.com`.
2. Copy the **Measurement ID** (`G-XXXXXXXXXX`) into **Admin → Settings → Google Analytics 4 measurement ID**.
3. Open the site in another tab and check **Reports → Realtime** to confirm you appear.
4. In GA4 **Admin → Events**, mark these as **key events** (conversions):
   - `generate_lead_demo`: a demo request was submitted
   - `generate_lead_contact`: a contact enquiry was submitted
   - `whatsapp_click`: someone clicked a WhatsApp button (`location` parameter says which one)
5. Link GA4 to Search Console (**GA4 Admin → Search Console links**) to see search queries alongside behaviour.

If you use Google Tag Manager instead, enter the `GTM-` ID; the GA4 field is then ignored and the same events are pushed to the data layer.

**Consent:** if you market to visitors in regions with cookie-consent laws (for example the EU or UK), add a consent banner and Google Consent Mode before enabling analytics. India's DPDP Act also requires clear notice about personal data use.

---

## 4. Launch checklist

### Before going live
- [ ] `SITE_URL` is the final `https://` domain; `NOINDEX_SITE` is `false`
- [ ] `APP_SECRET` set to a long random value
- [ ] HTTPS certificate active; `http://` and `www` redirect to the canonical host
- [ ] SMTP configured; **Admin → Settings → Send test email** succeeds; SPF/DKIM/DMARC set up
- [ ] Notification email address confirmed in Admin → Settings
- [ ] WhatsApp number confirmed active on WhatsApp; **Test the link** in Settings opens a chat
- [ ] Submit a real contact enquiry and a demo request; both appear in the admin and arrive by email
- [ ] Review the three starter blog articles; edit or unpublish as needed
- [ ] Privacy policy published and linked in the footer
- [ ] Admin password changed from the initial one; `ADMIN_PASSWORD` removed from `.env`
- [ ] Database and uploads backups scheduled

### Launch day
- [ ] Search Console verified and `sitemap.xml` submitted
- [ ] Request indexing for the home page and key service pages
- [ ] GA4 Realtime shows visits; key events marked
- [ ] Test sharing a page on LinkedIn and WhatsApp to check the preview image and title
- [ ] Validate structured data with <https://search.google.com/test/rich-results> and <https://validator.schema.org> for the home page, one service page and one blog post
- [ ] Run PageSpeed Insights (<https://pagespeed.web.dev>) on mobile for the home page and one service page

### First three months
- [ ] Publish useful articles regularly (event guides, case write-ups with real figures, how-tos), each linking to the relevant service page
- [ ] Turn completed projects into case studies with client permission
- [ ] Create or claim a **Google Business Profile** if the company has a public business address or service area (add address details there, and to `src/content/site.js` only once confirmed)
- [ ] Keep company details (name, phone, email, website) identical everywhere online: LinkedIn, directories, event-industry listings
- [ ] Earn links from event partners, venues, associations and clients' event pages
- [ ] Check Search Console monthly: Pages (indexing), Performance (queries, click-through rate), Core Web Vitals, Enhancements
- [ ] Improve titles and descriptions of pages that get impressions but few clicks

### International readiness
The site is in English (`en-IN`), uses Indian number formatting from the company profile and declares India as the service area, based on the company's documented vision and projects. If Navon starts serving other countries, update `company.areaServed` in `src/content/site.js`, and add translated pages with `hreflang` tags if you publish content in other languages.
