'use strict';
/**
 * End-to-end tests against the real app, a temporary SQLite database
 * and a local SMTP server that captures outgoing email.
 *   npm test
 */
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { SMTPServer } = require('smtp-server');
const { simpleParser } = require('mailparser');

/* ---------- Environment (must be set before the app modules load) ---------- */
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'navon-test-'));
const SMTP_PORT = 2600 + Math.floor(Math.random() * 300);
Object.assign(process.env, {
  NODE_ENV: 'test', SITE_URL: 'https://navoninnovations.com', DB_FILE: path.join(tmp, 'test.db'), UPLOAD_DIR: path.join(tmp, 'uploads'),
  APP_SECRET: 'test-secret-1234567890-abcdefghijklmnop', ADMIN_EMAIL: 'admin@test.local', ADMIN_PASSWORD: 'Correct-Horse-123',
  SMTP_HOST: '127.0.0.1', SMTP_PORT: String(SMTP_PORT), SMTP_SECURE: 'false', SMTP_IGNORE_TLS: 'true', MAIL_FROM: 'website@navoninnovations.com',
  NOTIFY_EMAIL: 'sales@navon.test', FORM_RATE_LIMIT: '1000', TRUST_PROXY: 'false'
});

const { createApp } = require('../src/app');
const { ensureInitialAdmin } = require('../src/admin-bootstrap');
const { seedIfEmpty } = require('../src/seed');
const security = require('../src/security');
const { pages } = require('../src/content/catalog');
const { legal } = require('../src/content/legal');
const db = require('../src/db');

let server, base, smtp;
const mails = [];

before(async () => {
  smtp = new SMTPServer({
    authOptional: true, disabledCommands: ['STARTTLS'], logger: false,
    onData(stream, _session, cb) { simpleParser(stream).then((m) => { mails.push(m); cb(); }).catch(cb); }
  });
  await new Promise((r) => smtp.listen(SMTP_PORT, '127.0.0.1', r));
  const app = createApp();
  ensureInitialAdmin();
  seedIfEmpty();
  await new Promise((r) => { server = app.listen(0, '127.0.0.1', r); });
  base = `http://127.0.0.1:${server.address().port}`;
});

after(async () => {
  await new Promise((r) => server.close(r));
  await new Promise((r) => smtp.close(r));
  db.close();
  fs.rmSync(tmp, { recursive: true, force: true });
});

/* ---------- Helpers ---------- */
const get = (p, opts = {}) => fetch(base + p, { redirect: 'manual', ...opts });
const token = () => security.issueFormToken(Date.now() - 5000);
const waitFor = async (fn, ms = 3000) => { const t = Date.now(); while (Date.now() - t < ms) { const v = fn(); if (v) return v; await new Promise((r) => setTimeout(r, 50)); } return fn(); };

function postForm(p, data, { json = true, cookie } = {}) {
  return fetch(base + p, {
    method: 'POST', redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: json ? 'application/json' : 'text/html', ...(cookie ? { Cookie: cookie } : {}) },
    body: new URLSearchParams(data).toString()
  });
}

const futureDate = () => new Date(Date.now() + 7 * 86400e3).toISOString().slice(0, 10);
const contactData = (o = {}) => ({ _ft: token(), website: '', name: 'Test Person', company: 'Test Co', email: 'test@example.com', phone: '+91 98765 43210', event_type: 'Corporate event', attendees: '500 – 2,000', event_date: futureDate(), message: 'We need onsite registration for a summit.', _source: '/contact', ...o });
const demoData = (o = {}) => ({ _ft: token(), website: '', name: 'Demo Person', company: 'Demo Co', email: 'demo@example.com', phone: '9876543210', event_type: 'Medical conference', delegates: '2,000 – 10,000', preferred_date: futureDate(), preferred_time: 'Any time', requirements: 'Facial recognition and RFID.', _source: '/demo', ...o });

const decode = (s) => s.replace(/&amp;/g, '&').replace(/&#39;/g, "'").replace(/&quot;/g, '"');

function extract(html) {
  const one = (re) => (html.match(re) || [])[1];
  return {
    title: decode(one(/<title>([^<]*)<\/title>/) || ''),
    description: decode(one(/<meta name="description" content="([^"]*)"/) || ''),
    canonical: one(/<link rel="canonical" href="([^"]*)"/),
    robots: one(/<meta name="robots" content="([^"]*)"/),
    ogTitle: one(/<meta property="og:title" content="([^"]*)"/),
    ogImage: one(/<meta property="og:image" content="([^"]*)"/),
    ogType: one(/<meta property="og:type" content="([^"]*)"/),
    twitterCard: one(/<meta name="twitter:card" content="([^"]*)"/),
    h1s: (html.match(/<h1[\s>]/g) || []).length,
    jsonLd: JSON.parse(one(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/)),
    imgsWithoutAlt: (html.match(/<img(?![^>]*\balt=)[^>]*>/g) || []).length
  };
}

async function adminLogin() {
  const r = await postForm('/admin/login', { email: 'admin@test.local', password: 'Correct-Horse-123' }, { json: false });
  assert.equal(r.status, 302);
  const cookie = r.headers.get('set-cookie').split(';')[0];
  const html = await (await get('/admin', { headers: { Cookie: cookie } })).text();
  const csrf = html.match(/name="_csrf" value="([^"]+)"/)[1];
  return { cookie, csrf };
}

/* ---------- SEO on every public page ---------- */
const LEGAL_INDEXABLE = Object.entries(legal).filter(([, l]) => !l.noindex).map(([slug]) => '/' + slug);
const PUBLIC_PATHS = ['/', '/services', '/products', '/ai-experiences', ...Object.values(pages).map((p) => p.path), '/about', '/industries', '/case-studies', '/contact', '/demo', ...LEGAL_INDEXABLE, '/blog', '/blog/qr-rfid-nfc-at-events', '/blog/category/event-technology'];

test('every public page returns 200 with complete, unique SEO metadata', async () => {
  const titles = new Map(); const descs = new Map();
  for (const p of PUBLIC_PATHS) {
    const r = await get(p);
    assert.equal(r.status, 200, `${p} status`);
    const m = extract(await r.text());
    assert.ok(m.title && m.title.length <= 70, `${p} title length ${m.title && m.title.length}`);
    assert.ok(m.description && m.description.length >= 50 && m.description.length <= 160, `${p} description length ${m.description && m.description.length}`);
    assert.equal(m.canonical, 'https://navoninnovations.com' + p, `${p} canonical`);
    assert.match(m.robots, /^index, follow/, `${p} must be indexable`);
    assert.equal(m.h1s, 1, `${p} must have exactly one H1`);
    assert.ok(m.ogTitle && m.ogImage.startsWith('https://navoninnovations.com/'), `${p} Open Graph`);
    assert.equal(m.twitterCard, 'summary_large_image', `${p} Twitter card`);
    assert.equal(m.imgsWithoutAlt, 0, `${p} images without alt`);
    const types = m.jsonLd['@graph'].map((n) => n['@type']);
    assert.ok(types.includes('Organization') && types.includes('WebSite'), `${p} Organization + WebSite schema`);
    if (p !== '/') assert.ok(types.includes('BreadcrumbList'), `${p} BreadcrumbList schema`);
    assert.ok(!titles.has(m.title), `${p} duplicate title with ${titles.get(m.title)}`);
    assert.ok(!descs.has(m.description), `${p} duplicate description with ${descs.get(m.description)}`);
    titles.set(m.title, p); descs.set(m.description, p);
  }
});

test('service pages carry Service schema; blog posts carry Article schema', async () => {
  for (const p of Object.values(pages).filter((x) => x.serviceType)) {
    const m = extract(await (await get(p.path)).text());
    const svc = m.jsonLd['@graph'].find((n) => n['@type'] === 'Service');
    assert.ok(svc, `${p.path} Service schema`);
    assert.equal(svc.provider['@id'], 'https://navoninnovations.com/#organization');
  }
  const m = extract(await (await get('/blog/qr-rfid-nfc-at-events')).text());
  const art = m.jsonLd['@graph'].find((n) => n['@type'] === 'BlogPosting');
  assert.ok(art && art.headline && art.datePublished && art.image, 'Article schema fields');
  assert.equal(m.ogType, 'article');
});

test('organization schema uses only documented company details', async () => {
  const m = extract(await (await get('/')).text());
  const org = m.jsonLd['@graph'].find((n) => n['@type'] === 'Organization');
  assert.equal(org.name, 'Navon Innovations');
  assert.equal(org.email, 'sales@navoninnovations.com');
  assert.equal(org.telephone, '+919654496952');
  assert.equal(org.address.addressLocality, 'New Delhi', 'address as published on navoninnovations.com');
  assert.equal(org.address.postalCode, '110075');
});

test('tag archives are noindex,follow and kept out of the sitemap', async () => {
  const r = await get('/blog/tag/rfid');
  assert.equal(r.status, 200);
  assert.equal(extract(await r.text()).robots, 'noindex, follow');
  assert.ok(!(await (await get('/sitemap.xml')).text()).includes('/blog/tag/'));
});

test('sitemap.xml lists every indexable page and robots.txt points to it', async () => {
  const xml = await (await get('/sitemap.xml')).text();
  for (const p of PUBLIC_PATHS) assert.ok(xml.includes(`<loc>https://navoninnovations.com${p === '/' ? '/' : p}</loc>`), `sitemap has ${p}`);
  assert.ok(!xml.includes('/admin') && !xml.includes('/thank-you'), 'no private URLs in sitemap');
  const robots = await (await get('/robots.txt')).text();
  assert.match(robots, /Sitemap: https:\/\/navoninnovations\.com\/sitemap\.xml/);
  assert.match(robots, /Disallow: \/admin/);
  assert.doesNotMatch(robots, /Disallow: \/\n/, 'site must not be blocked');
});

test('products and services have separate hubs; old URLs redirect permanently', async () => {
  for (const [from, to] of [['/solutions', '/services'], ['/book-a-demo', '/demo'], ['/event-management-dashboard', '/platform'], ['/facial-recognition-event-registration', '/face-recognition']]) {
    const r = await get(from);
    assert.equal(r.status, 301, from);
    assert.equal(r.headers.get('location'), to);
  }
  const products = await (await get('/products')).text();
  for (const p of Object.values(pages).filter((x) => x.section === 'product')) assert.ok(products.includes(`href="${p.path}"`), `products hub links ${p.path}`);
  const services = await (await get('/services')).text();
  for (const p of Object.values(pages).filter((x) => x.section === 'service')) assert.ok(services.includes(`href="${p.path}"`), `services hub links ${p.path}`);
  const nav = await (await get('/')).text();
  assert.match(nav, /id="services-menu"/);
  assert.match(nav, /id="products-menu"/);
  assert.equal((await get('/products/not-a-product')).status, 404);
});

test('legal pages from the live site render; GDPR placeholder stays out of search', async () => {
  for (const p of LEGAL_INDEXABLE) assert.equal((await get(p)).status, 200, p);
  const gdpr = await get('/gdpr');
  assert.equal(gdpr.status, 200);
  assert.match(extract(await gdpr.text()).robots, /noindex/);
  assert.ok(!(await (await get('/sitemap.xml')).text()).includes('/gdpr'));
});

test('product pages have product-specific WhatsApp messages and Service schema', async () => {
  const html = decode(await (await get('/event-mobile-app')).text());
  assert.ok(html.includes(encodeURIComponent('Hi Navon Innovations, I am interested in your event mobile app solutions.')));
  const m = extract(html);
  assert.ok(m.jsonLd['@graph'].some((n) => n['@type'] === 'Service'));
});

test('custom 404 page returns 404 and is noindex; trailing slashes redirect', async () => {
  const r = await get('/does-not-exist');
  assert.equal(r.status, 404);
  const html = await r.text();
  assert.match(html, /This page took a wrong turn/);
  assert.match(extract(html).robots, /noindex/);
  const s = await get('/about/');
  assert.equal(s.status, 301);
  assert.equal(s.headers.get('location'), '/about');
});

/* ---------- WhatsApp ---------- */
test('WhatsApp buttons use official click-to-chat links with pre-filled messages', async () => {
  const home = await (await get('/')).text();
  assert.ok(decode(home).includes('https://wa.me/919899445735?text=' + encodeURIComponent('Hi Navon Innovations, I am interested in your event technology solutions.')), 'default message on floating button');
  assert.match(home, /class="wa-float"/);
  const svc = decode(await (await get('/rfid-tracking')).text());
  assert.ok(svc.includes('https://wa.me/919899445735?text=' + encodeURIComponent('Hi Navon Innovations, I am interested in your RFID tracking solutions.')), 'service-specific message');
  assert.ok(!svc.includes('solutions%20solutions'), 'no doubled wording');
  const reg = decode(await (await get('/badge-printing')).text());
  assert.ok(reg.includes(encodeURIComponent('Hi Navon Innovations, I am interested in your badge printing solutions.')));
  for (const p of PUBLIC_PATHS) assert.match(await (await get(p)).text(), /class="wa-float"/, `${p} floating WhatsApp button`);
});

test('changing the WhatsApp number in admin settings updates every button', async () => {
  const { cookie, csrf } = await adminLogin();
  const r = await postForm('/admin/settings', { _csrf: csrf, whatsapp_number: '+91 90000 11111', whatsapp_message: 'Hello Navon' }, { json: false, cookie });
  assert.equal(r.status, 302);
  const home = decode(await (await get('/')).text());
  assert.ok(home.includes('https://wa.me/919000011111?text=Hello%20Navon'));
  await postForm('/admin/settings', { _csrf: csrf, whatsapp_number: '919899445735', whatsapp_message: 'Hi Navon Innovations, I am interested in your event technology solutions.' }, { json: false, cookie });
});

/* ---------- Contact form ---------- */
test('contact form: valid submission is saved and the company is emailed', async () => {
  mails.length = 0;
  const r = await postForm('/contact', contactData({ name: 'Asha Verma', email: 'asha@example.com' }));
  assert.equal(r.status, 200);
  const body = await r.json();
  assert.equal(body.ok, true);
  assert.match(body.ref, /^ENQ-\d{6}$/);
  const id = parseInt(body.ref.split('-')[1], 10);
  const row = db.get().prepare('SELECT * FROM enquiries WHERE id = ?').get(id);
  assert.equal(row.name, 'Asha Verma');
  assert.equal(row.company, 'Test Co');
  assert.equal(row.event_type, 'Corporate event');
  assert.equal(row.email_status, 'sent');
  const mail = await waitFor(() => mails.find((m) => m.subject.includes(body.ref)));
  assert.ok(mail, 'notification email received');
  assert.equal(mail.to.text, 'sales@navon.test');
  assert.equal(mail.replyTo.text, 'asha@example.com');
  assert.match(mail.text, /Asha Verma/);
});

test('contact form: validation errors are returned per field', async () => {
  const r = await postForm('/contact', contactData({ name: '', email: 'not-an-email', phone: '123', event_type: 'Wedding', message: 'hi' }));
  assert.equal(r.status, 422);
  const body = await r.json();
  assert.equal(body.ok, false);
  for (const f of ['name', 'email', 'phone', 'event_type', 'message']) assert.ok(body.errors[f], `error for ${f}`);
});

test('contact form: spam protection rejects honeypot, missing token and instant submissions', async () => {
  const before = db.get().prepare('SELECT COUNT(*) AS n FROM enquiries').get().n;
  assert.equal((await postForm('/contact', contactData({ website: 'http://spam.example' }))).status, 400);
  assert.equal((await postForm('/contact', contactData({ _ft: '' }))).status, 400);
  assert.equal((await postForm('/contact', contactData({ _ft: security.issueFormToken() }))).status, 400);
  assert.equal((await postForm('/contact', contactData({ _ft: 'abc.forged' }))).status, 400);
  assert.equal(db.get().prepare('SELECT COUNT(*) AS n FROM enquiries').get().n, before, 'nothing saved');
});

test('contact form works without JavaScript (redirects to thank-you page)', async () => {
  const r = await postForm('/contact', contactData(), { json: false });
  assert.equal(r.status, 303);
  assert.match(r.headers.get('location'), /^\/thank-you\?type=contact&ref=ENQ-\d{6}$/);
  const page = await (await get(r.headers.get('location'))).text();
  assert.match(page, /Enquiry received/);
  assert.match(extract(page).robots, /noindex/);
  const bad = await postForm('/contact', contactData({ email: 'x' }), { json: false });
  assert.equal(bad.status, 422);
  assert.match(await bad.text(), /Enter a valid email address/);
});

/* ---------- Demo requests ---------- */
test('book a demo: saved with status New and emailed', async () => {
  mails.length = 0;
  const r = await postForm('/demo', demoData());
  const body = await r.json();
  assert.equal(body.ok, true);
  assert.match(body.ref, /^DEMO-\d{6}$/);
  const row = db.get().prepare('SELECT * FROM demo_requests WHERE id = ?').get(parseInt(body.ref.split('-')[1], 10));
  assert.equal(row.status, 'new');
  assert.equal(row.preferred_time, 'Any time');
  assert.equal(row.email_status, 'sent');
  assert.ok(await waitFor(() => mails.find((m) => m.subject.includes(body.ref))), 'demo email received');
});

test('book a demo: past dates and missing fields are rejected', async () => {
  const r = await postForm('/demo', demoData({ preferred_date: '2020-01-01', company: '' }));
  assert.equal(r.status, 422);
  const body = await r.json();
  assert.ok(body.errors.preferred_date && body.errors.company);
});

test('when email delivery fails, the request is still saved and marked failed (no false success)', async () => {
  await new Promise((r) => smtp.close(r));
  require('../src/mailer').resetTransport();
  const r = await postForm('/demo', demoData({ name: 'Offline Mail' }));
  const body = await r.json();
  assert.equal(body.ok, true, 'request received');
  assert.doesNotMatch(body.message, /email/i, 'user message must not claim an email was sent');
  const row = db.get().prepare('SELECT * FROM demo_requests WHERE id = ?').get(parseInt(body.ref.split('-')[1], 10));
  assert.equal(row.email_status, 'failed');
  assert.ok(row.email_error.length > 0);
  smtp = new SMTPServer({ authOptional: true, disabledCommands: ['STARTTLS'], logger: false, onData(s, _x, cb) { simpleParser(s).then((m) => { mails.push(m); cb(); }).catch(cb); } });
  await new Promise((res) => smtp.listen(SMTP_PORT, '127.0.0.1', res));
  require('../src/mailer').resetTransport();
});

/* ---------- Admin ---------- */
test('admin requires sign-in and rejects wrong passwords', async () => {
  const r = await get('/admin/demo-requests');
  assert.equal(r.status, 302);
  assert.match(r.headers.get('location'), /^\/admin\/login/);
  const bad = await postForm('/admin/login', { email: 'admin@test.local', password: 'wrong' }, { json: false });
  assert.equal(bad.status, 401);
  const lp = await get('/admin/login');
  assert.equal(lp.headers.get('x-robots-tag'), 'noindex, nofollow');
});

test('admin: demo status can be changed through every state; CSRF is enforced', async () => {
  const { cookie, csrf } = await adminLogin();
  const id = db.get().prepare('SELECT id FROM demo_requests ORDER BY id DESC LIMIT 1').get().id;
  const noCsrf = await postForm(`/admin/demo-requests/${id}`, { status: 'contacted' }, { json: false, cookie });
  assert.equal(noCsrf.status, 403);
  for (const s of ['contacted', 'scheduled', 'completed', 'cancelled', 'new']) {
    const r = await postForm(`/admin/demo-requests/${id}`, { _csrf: csrf, status: s, admin_notes: `moved to ${s}` }, { json: false, cookie });
    assert.equal(r.status, 302);
    assert.equal(db.get().prepare('SELECT status FROM demo_requests WHERE id = ?').get(id).status, s);
  }
  const list = await (await get('/admin/demo-requests?status=new', { headers: { Cookie: cookie } })).text();
  assert.match(list, new RegExp(`DEMO-${String(id).padStart(6, '0')}`));
  const enq = await (await get('/admin/enquiries', { headers: { Cookie: cookie } })).text();
  assert.match(enq, /Asha Verma/, 'enquiries visible in admin');
  const csv = await get('/admin/demo-requests.csv', { headers: { Cookie: cookie } });
  assert.match(csv.headers.get('content-type'), /text\/csv/);
});

/* ---------- Blog CMS ---------- */
test('blog: create draft, publish, unpublish and delete; sitemap follows', async () => {
  const { cookie, csrf } = await adminLogin();
  const content = '## Why check-in speed matters\n\nA fast check-in sets the tone for the event. ' + 'Navon prints badges within 15 seconds. '.repeat(8) + '\n\n- Point one\n- Point two\n\nSee [onsite registration](/event-registration-services) and [an external reference](https://example.org).';
  const create = await postForm('/admin/posts', { _csrf: csrf, title: 'Test post about check-in', slug: '', excerpt: 'A test excerpt.', content_md: content, seo_title: 'Check-in Test Post', meta_description: 'A meta description long enough to be useful for search results in this test.', status: 'draft', author: 'Navon Innovations', tags: 'Check-in, Testing', featured_image: '/img/rfid-smart-tracking-reader.webp', featured_image_alt: 'RFID reader' }, { json: false, cookie });
  assert.equal(create.status, 302);
  const id = parseInt(create.headers.get('location').match(/posts\/(\d+)/)[1], 10);
  assert.equal((await get('/blog/test-post-about-check-in')).status, 404, 'draft hidden from public');
  assert.ok(!(await (await get('/sitemap.xml')).text()).includes('test-post-about-check-in'));
  const preview = await get('/blog/test-post-about-check-in', { headers: { Cookie: cookie } });
  assert.equal(preview.status, 200, 'admin can preview draft');
  assert.match(extract(await preview.text()).robots, /noindex/);

  assert.equal((await postForm(`/admin/posts/${id}/publish`, { _csrf: csrf }, { json: false, cookie })).status, 302);
  const live = await get('/blog/test-post-about-check-in');
  assert.equal(live.status, 200);
  const html = await live.text();
  const m = extract(html);
  assert.equal(m.title, 'Check-in Test Post');
  assert.match(m.robots, /^index/);
  assert.match(html, /<h2 id="why-check-in-speed-matters">/);
  assert.match(html, /href="https:\/\/example\.org" target="_blank" rel="noopener"/);
  assert.match(html, /href="\/event-registration-services"/);
  assert.ok((await (await get('/sitemap.xml')).text()).includes('/blog/test-post-about-check-in'), 'published post in sitemap');
  assert.ok((await (await get('/blog/tag/check-in')).text()).includes('Test post about check-in'), 'tag page lists post');
  assert.ok((await (await get('/blog?q=badges')).text()).includes('Test post about check-in'), 'search finds post');

  await postForm(`/admin/posts/${id}/unpublish`, { _csrf: csrf }, { json: false, cookie });
  assert.equal((await get('/blog/test-post-about-check-in')).status, 404);
  assert.ok(!(await (await get('/sitemap.xml')).text()).includes('test-post-about-check-in'), 'unpublished post removed from sitemap');

  await postForm(`/admin/posts/${id}/delete`, { _csrf: csrf }, { json: false, cookie });
  assert.equal(db.get().prepare('SELECT COUNT(*) AS n FROM posts WHERE id = ?').get(id).n, 0);
});

test('blog: publishing requires meta description, excerpt and real content; slugs are unique', async () => {
  const { cookie, csrf } = await adminLogin();
  const r = await postForm('/admin/posts', { _csrf: csrf, title: 'Thin post', content_md: 'Too short', status: 'published' }, { json: false, cookie });
  assert.equal(r.status, 422);
  const html = await r.text();
  assert.match(html, /at least 200 characters/);
  assert.match(html, /Add a meta description/);
  const dup = await postForm('/admin/posts', { _csrf: csrf, title: 'Duplicate', slug: 'qr-rfid-nfc-at-events', status: 'draft' }, { json: false, cookie });
  assert.equal(dup.status, 422);
  assert.match(await dup.text(), /already uses this URL/);
});

test('blog: script injection in Markdown is stripped', async () => {
  const html = require('../src/blog').renderMarkdown('# Title\n\n<script>alert(1)</script><img src=x onerror=alert(1)>\n\n[x](javascript:alert(1))');
  assert.doesNotMatch(html, /<script|onerror|javascript:/);
  assert.match(html, /<h2/, 'H1 demoted to H2');
});

test('admin image upload compresses to WebP with a descriptive filename', async () => {
  const { cookie, csrf } = await adminLogin();
  const sharp = require('sharp');
  const png = await sharp({ create: { width: 2400, height: 1200, channels: 3, background: '#6A4CF5' } }).png().toBuffer();
  const fd = new FormData();
  fd.append('image', new Blob([png], { type: 'image/png' }), 'Badge Printing Counter.png');
  fd.append('name', 'badge printing counter');
  const r = await fetch(base + '/admin/upload', { method: 'POST', headers: { Cookie: cookie, 'X-CSRF-Token': csrf }, body: fd });
  const body = await r.json();
  assert.equal(body.ok, true);
  assert.match(body.url, /^\/uploads\/badge-printing-counter-[a-f0-9]{6}\.webp$/);
  assert.equal(body.width, 1600);
  assert.ok(fs.existsSync(path.join(process.env.UPLOAD_DIR, path.basename(body.url))));
});

/* ---------- Navigation ---------- */
test('every internal link on public pages resolves', async () => {
  const seen = new Set(); const broken = [];
  for (const p of PUBLIC_PATHS) {
    const html = await (await get(p)).text();
    for (const [, href] of html.matchAll(/href="(\/[^"#?]*)/g)) {
      if (seen.has(href) || href.startsWith('/admin')) continue;
      seen.add(href);
      const r = await get(href);
      if (r.status >= 400) broken.push(`${href} (from ${p}): ${r.status}`);
    }
  }
  assert.deepEqual(broken, []);
});
