/* ==========================================================================
   Navon Innovations — site behaviour
   Vanilla JS, no dependencies. Each feature is a small init function.
   ========================================================================== */
(function () {
  'use strict';

  var root = document.documentElement;
  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var $ = function (sel, ctx) { return (ctx || document).querySelector(sel); };
  var $$ = function (sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); };
  var formatIN = function (n) { return Math.round(n).toLocaleString('en-IN'); };

  /* Run a callback once when an element scrolls into view */
  function onVisible(el, cb, opts) {
    if (!el) return;
    if (!('IntersectionObserver' in window)) { cb(el); return; }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) { if (e.isIntersecting) { cb(e.target); io.unobserve(e.target); } });
    }, opts || { threshold: 0.3 });
    io.observe(el);
  }

  /* ---------------------------------------------------------------------
     Page load: trigger the hero entrance
     --------------------------------------------------------------------- */
  function initLoad() {
    var go = function () { requestAnimationFrame(function () { root.classList.add('loaded'); }); };
    if (document.fonts && document.fonts.ready) {
      Promise.race([document.fonts.ready, new Promise(function (r) { setTimeout(r, 700); })]).then(go);
    } else { go(); }
  }

  /* ---------------------------------------------------------------------
     Header state + scroll progress bar
     --------------------------------------------------------------------- */
  function initHeader() {
    var header = $('.site-header');
    var bar = $('.scroll-progress span');
    var ticking = false;
    function update() {
      var y = window.scrollY;
      header.classList.toggle('scrolled', y > 24);
      var max = document.documentElement.scrollHeight - window.innerHeight;
      bar.style.transform = 'scaleX(' + (max > 0 ? y / max : 0) + ')';
      ticking = false;
    }
    window.addEventListener('scroll', function () { if (!ticking) { requestAnimationFrame(update); ticking = true; } }, { passive: true });
    update();
  }

  /* ---------------------------------------------------------------------
     Solutions mega menu (hover on desktop, click/keyboard everywhere)
     --------------------------------------------------------------------- */
  function initMegaMenu() {
    var items = $$('.has-menu');
    items.forEach(function (item) {
      var trigger = $('.menu-trigger', item);
      var closeTimer;
      function setOpen(open) {
        if (open) items.forEach(function (o) { if (o !== item) { o.classList.remove('open'); $('.menu-trigger', o).setAttribute('aria-expanded', 'false'); } });
        item.classList.toggle('open', open);
        trigger.setAttribute('aria-expanded', String(open));
      }
      trigger.addEventListener('click', function (e) { e.stopPropagation(); setOpen(!item.classList.contains('open')); });
      item.addEventListener('mouseenter', function () { clearTimeout(closeTimer); setOpen(true); });
      item.addEventListener('mouseleave', function () { closeTimer = setTimeout(function () { setOpen(false); }, 180); });
      $$('.mega a', item).forEach(function (a) { a.addEventListener('click', function () { setOpen(false); }); });
      document.addEventListener('click', function (e) { if (!item.contains(e.target)) setOpen(false); });
      document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && item.classList.contains('open')) { setOpen(false); trigger.focus(); }
      });
      item.addEventListener('focusout', function (e) { if (!item.contains(e.relatedTarget)) setOpen(false); });
    });
  }

  /* ---------------------------------------------------------------------
     Mobile menu
     --------------------------------------------------------------------- */
  function initMobileMenu() {
    var btn = $('.nav-toggle');
    var menu = $('#mobile-menu');
    if (!btn || !menu) return;
    function setOpen(open) {
      btn.setAttribute('aria-expanded', String(open));
      btn.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
      document.body.style.overflow = open ? 'hidden' : '';
      if (open) {
        menu.hidden = false;
        requestAnimationFrame(function () { menu.classList.add('open'); });
      } else {
        menu.classList.remove('open');
        setTimeout(function () { if (btn.getAttribute('aria-expanded') === 'false') menu.hidden = true; }, 350);
      }
    }
    btn.addEventListener('click', function () { setOpen(btn.getAttribute('aria-expanded') !== 'true'); });
    $$('a', menu).forEach(function (a) { a.addEventListener('click', function () { setOpen(false); }); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !menu.hidden) { setOpen(false); btn.focus(); } });
    window.addEventListener('resize', function () { if (window.innerWidth > 1180 && !menu.hidden) setOpen(false); });
  }

  /* ---------------------------------------------------------------------
     Scroll reveal with automatic sibling stagger
     --------------------------------------------------------------------- */
  function initReveal() {
    var els = $$('.reveal');
    if (reduceMotion || !('IntersectionObserver' in window)) { els.forEach(function (el) { el.classList.add('in'); }); return; }
    // Stagger siblings that share a parent
    els.forEach(function (el) {
      var sibs = $$(':scope > .reveal', el.parentElement);
      var i = sibs.indexOf(el);
      if (sibs.length > 1 && i > 0) el.style.setProperty('--d', Math.min(i * 0.08, 0.5) + 's');
    });
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
    els.forEach(function (el) { io.observe(el); });
  }

  /* ---------------------------------------------------------------------
     Hero: particle network canvas
     --------------------------------------------------------------------- */
  function initHeroCanvas() {
    $$('.hero-canvas').forEach(function (canvas) {
      if (!canvas.getContext) return;
      var host = canvas.parentElement;
      var ctx = canvas.getContext('2d');
      var dpr = Math.min(window.devicePixelRatio || 1, 2);
      var w, h, points = [], running = true, raf;
      var mouse = { x: -9999, y: -9999 };
      function resize() {
        var r = canvas.getBoundingClientRect();
        w = r.width; h = r.height;
        canvas.width = w * dpr; canvas.height = h * dpr;
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        var count = Math.round(Math.min(90, (w * h) / 16000));
        points = [];
        for (var i = 0; i < count; i++) {
          points.push({ x: Math.random() * w, y: Math.random() * h, vx: (Math.random() - .5) * .25, vy: (Math.random() - .5) * .25, r: Math.random() * 1.4 + .4, c: Math.random() > .55 ? '46,196,230' : '139,115,255' });
        }
      }
      function draw() {
        ctx.clearRect(0, 0, w, h);
        var maxD = 130;
        for (var i = 0; i < points.length; i++) {
          var p = points[i];
          if (!reduceMotion) {
            p.x += p.vx; p.y += p.vy;
            if (p.x < 0 || p.x > w) p.vx *= -1;
            if (p.y < 0 || p.y > h) p.vy *= -1;
            var mdx = p.x - mouse.x, mdy = p.y - mouse.y, md = Math.sqrt(mdx * mdx + mdy * mdy);
            if (md < 120 && md > 0) { p.x += mdx / md * .6; p.y += mdy / md * .6; }
          }
          for (var j = i + 1; j < points.length; j++) {
            var q = points[j], dx = p.x - q.x, dy = p.y - q.y, d = dx * dx + dy * dy;
            if (d < maxD * maxD) {
              ctx.strokeStyle = 'rgba(139,115,255,' + (0.16 * (1 - Math.sqrt(d) / maxD)) + ')';
              ctx.lineWidth = 1;
              ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y); ctx.stroke();
            }
          }
          ctx.fillStyle = 'rgba(' + p.c + ',.75)';
          ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.fill();
        }
        if (running && !reduceMotion) raf = requestAnimationFrame(draw);
      }
      resize(); draw();
      window.addEventListener('resize', function () { resize(); if (reduceMotion) draw(); });
      host.addEventListener('pointermove', function (e) { var r = canvas.getBoundingClientRect(); mouse.x = e.clientX - r.left; mouse.y = e.clientY - r.top; });
      host.addEventListener('pointerleave', function () { mouse.x = mouse.y = -9999; });
      if ('IntersectionObserver' in window && !reduceMotion) {
        new IntersectionObserver(function (en) {
          var vis = en[0].isIntersecting;
          if (vis && !running) { running = true; draw(); }
          else if (!vis) { running = false; cancelAnimationFrame(raf); }
        }).observe(host);
      }
    });
  }

  /* ---------------------------------------------------------------------
     Hero: 3D tilt + check-in chips sequence
     --------------------------------------------------------------------- */
  function initHeroStage() {
    var stage = $('.hero-stage');
    if (!stage) return;
    var tilt = $('.stage-tilt', stage);
    var chips = $$('.chip', stage);

    if (!reduceMotion && window.matchMedia('(pointer: fine)').matches) {
      var hero = $('.hero');
      hero.addEventListener('pointermove', function (e) {
        var r = stage.getBoundingClientRect();
        var x = (e.clientX - (r.left + r.width / 2)) / r.width;
        var y = (e.clientY - (r.top + r.height / 2)) / r.height;
        tilt.style.transform = 'rotateY(' + (x * 12).toFixed(2) + 'deg) rotateX(' + (-y * 10).toFixed(2) + 'deg)';
      });
      hero.addEventListener('pointerleave', function () { tilt.style.transform = ''; });
    }

    // Chips appear in check-in order, then repeat the sequence
    if (reduceMotion) { chips.forEach(function (c) { c.classList.add('show'); }); return; }
    function cycle() {
      chips.forEach(function (c, i) { setTimeout(function () { c.classList.add('show'); }, 900 + i * 650); });
      setTimeout(function () {
        chips.forEach(function (c, i) { setTimeout(function () { c.classList.remove('show'); }, i * 120); });
        setTimeout(cycle, 900);
      }, 900 + chips.length * 650 + 5200);
    }
    cycle();
  }

  /* ---------------------------------------------------------------------
     Accessible tabs (works for every [role=tablist] on the page)
     --------------------------------------------------------------------- */
  function initTabs() {
    $$('[role="tablist"]:not(.eco-steps)').forEach(function (list) {
      var tabs = $$('[role="tab"]', list);
      function select(tab, focus) {
        tabs.forEach(function (t) {
          var on = t === tab;
          t.setAttribute('aria-selected', String(on));
          t.tabIndex = on ? 0 : -1;
          var panel = document.getElementById(t.getAttribute('aria-controls'));
          if (panel) panel.hidden = !on;
        });
        if (focus) tab.focus();
      }
      tabs.forEach(function (t, i) {
        t.addEventListener('click', function () { select(t); });
        t.addEventListener('keydown', function (e) {
          var n = null;
          if (e.key === 'ArrowRight' || e.key === 'ArrowDown') n = tabs[(i + 1) % tabs.length];
          if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') n = tabs[(i - 1 + tabs.length) % tabs.length];
          if (e.key === 'Home') n = tabs[0];
          if (e.key === 'End') n = tabs[tabs.length - 1];
          if (n) { e.preventDefault(); select(n, true); }
        });
      });
    });
  }

  /* ---------------------------------------------------------------------
     Solution cards: light follows the pointer
     --------------------------------------------------------------------- */
  function initCardGlow() {
    $$('.sol-card').forEach(function (c) {
      c.addEventListener('pointermove', function (e) {
        var r = c.getBoundingClientRect();
        c.style.setProperty('--mx', (e.clientX - r.left) + 'px');
        c.style.setProperty('--my', (e.clientY - r.top) + 'px');
      });
    });
  }

  /* ---------------------------------------------------------------------
     Ecosystem: highlight each stage in turn until the user hovers
     --------------------------------------------------------------------- */
  function initEcosystem() {
    var eco = $('.eco');
    if (!eco || reduceMotion) return;
    var cols = $$('.eco-col', eco), i = 0, timer, paused = false;
    function step() {
      if (paused) return;
      cols.forEach(function (c, k) { c.classList.toggle('active', k === i); });
      i = (i + 1) % cols.length;
    }
    eco.addEventListener('mouseenter', function () { paused = true; cols.forEach(function (c) { c.classList.remove('active'); }); });
    eco.addEventListener('mouseleave', function () { paused = false; });
    onVisible(eco, function () { step(); timer = setInterval(step, 2600); });
  }

  /* ---------------------------------------------------------------------
     Count-up numbers (Indian digit grouping, e.g. 2,50,000)
     --------------------------------------------------------------------- */
  function initCounters() {
    $$('[data-count]').forEach(function (el) {
      var target = parseFloat(el.getAttribute('data-count'));
      if (isNaN(target)) return;
      var suffix = el.getAttribute('data-suffix') || '';
      var dec = parseInt(el.getAttribute('data-decimals') || '0', 10);
      var fmt = function (v) { return (dec ? v.toFixed(dec) : formatIN(v)) + suffix; };
      var final = el.textContent;
      if (reduceMotion) return;
      onVisible(el, function () {
        var start = performance.now(), dur = target > 1000 ? 1800 : 1200;
        (function tick(now) {
          var t = Math.min((now - start) / dur, 1);
          el.textContent = t < 1 ? fmt(target * (1 - Math.pow(1 - t, 4))) : final;
          if (t < 1) requestAnimationFrame(tick);
        })(start);
      }, { threshold: 0.6 });
    });
  }

  /* Flow steps light up as the section scrolls through the viewport */
  function initFlow() {
    $$('[data-flow]').forEach(function (flow) {
      var steps = $$('.flow-step', flow);
      if (!steps.length) return;
      if (reduceMotion) { flow.style.setProperty('--flow', 1); steps.forEach(function (s) { s.classList.add('on'); }); return; }
      var ticking = false;
      var update = function () {
        ticking = false;
        var r = flow.getBoundingClientRect(), vh = window.innerHeight;
        var p = Math.max(0, Math.min(1, (vh * 0.8 - r.top) / (r.height + vh * 0.3)));
        flow.style.setProperty('--flow', p.toFixed(3));
        var lit = Math.round(p * steps.length);
        steps.forEach(function (s, i) { s.classList.toggle('on', i < lit); });
      };
      window.addEventListener('scroll', function () { if (!ticking) { ticking = true; requestAnimationFrame(update); } }, { passive: true });
      update();
    });
  }

  /* Hero status chips switch on one after another */
  function initStatusCycle() {
    $$('[data-status-cycle]').forEach(function (row) {
      var chips = $$('.status', row);
      if (!chips.length) return;
      if (reduceMotion) { chips.forEach(function (c) { c.classList.add('on'); }); return; }
      chips.forEach(function (c, i) { setTimeout(function () { c.classList.add('on'); }, 700 + i * 450); });
    });
  }

  /* ---------------------------------------------------------------------
     Facial recognition demo status loop
     --------------------------------------------------------------------- */
  function initFaceDemo() {
    var status = $('.fd-status');
    if (!status) return;
    var text = $('.fd-text', status);
    var states = [
      { t: 'Scanning…', ok: false },
      { t: 'Face matched to pre-registered data', ok: true },
      { t: 'Badge printing, attendance logged', ok: true }
    ];
    var i = 0;
    function next() { var s = states[i]; text.textContent = s.t; status.classList.toggle('ok', s.ok); i = (i + 1) % states.length; }
    next();
    if (!reduceMotion) onVisible(status, function () { setInterval(next, 1900); });
  }

  /* ---------------------------------------------------------------------
     AI experiences rail: previous / next
     --------------------------------------------------------------------- */
  function initRail() {
    var rail = $('.ai-rail');
    if (!rail) return;
    $$('.rail-btn').forEach(function (b) {
      b.addEventListener('click', function () {
        var card = rail.querySelector('figure');
        var stepPx = card ? card.getBoundingClientRect().width + 18 : 300;
        rail.scrollBy({ left: stepPx * parseInt(b.getAttribute('data-dir'), 10), behavior: reduceMotion ? 'auto' : 'smooth' });
      });
    });
  }

  /* ---------------------------------------------------------------------
     Workflow: auto-advance through six steps; click to pick one
     --------------------------------------------------------------------- */
  function initWorkflow() {
    var wf = $('.wf');
    if (!wf) return;
    var steps = $$('.wf-step', wf);
    var i = 0, timer = null;
    function setActive(k) {
      steps.forEach(function (s, n) {
        s.classList.toggle('active', n === k);
        $('button', s).setAttribute('aria-expanded', String(n === k));
      });
      wf.style.setProperty('--wf', steps.length > 1 ? k / (steps.length - 1) : 1);
    }
    steps.forEach(function (s, k) {
      $('button', s).addEventListener('click', function () { clearInterval(timer); timer = null; i = k; setActive(k); });
    });
    onVisible(wf, function () {
      setActive(0);
      if (reduceMotion) return;
      timer = setInterval(function () { i = (i + 1) % steps.length; setActive(i); }, 2200);
    }, { threshold: 0.4 });
  }

  /* ---------------------------------------------------------------------
     Delegate journey illustration (any number on a page)
     --------------------------------------------------------------------- */
  function initJourneys() {
    $$('.journey').forEach(function (j) {
      var track = $('.journey-track', j);
      var items = $$('li', track);
      var log = $('.journey-log', j);
      var btn = $('[data-journey-play]', j);
      var messages = [
        'Session & hall scan recorded: entry to the main hall.',
        'Kit distribution confirmed for this delegate.',
        'Meal access scanned at the food counter.',
        'Gift collection recorded.',
        'Certificate collection recorded. Every checkpoint is in the live report.'
      ];
      var timers = [];
      function play() {
        timers.forEach(clearTimeout); timers = [];
        items.forEach(function (li) { li.classList.remove('done'); });
        track.style.setProperty('--p', 0);
        items.forEach(function (li, i) {
          timers.push(setTimeout(function () {
            li.classList.add('done');
            track.style.setProperty('--p', items.length > 1 ? i / (items.length - 1) : 1);
            log.textContent = messages[i];
          }, reduceMotion ? 0 : 500 + i * 1100));
        });
      }
      if (btn) btn.addEventListener('click', play);
      onVisible(track, play, { threshold: 0.6 });
    });
  }

  /* ---------------------------------------------------------------------
     Book a demo modal (falls back to the /book-a-demo page without JS)
     --------------------------------------------------------------------- */
  function initDemoModal() {
    var modal = $('#demo-modal');
    if (!modal) return;
    var panel = $('.modal-panel', modal);
    var lastFocus = null;
    function open(e) {
      if (e) e.preventDefault();
      lastFocus = document.activeElement;
      closeMobileMenu();
      modal.hidden = false;
      document.body.classList.add('modal-open');
      requestAnimationFrame(function () { modal.classList.add('open'); });
      var first = $('input:not([type=hidden]):not([tabindex="-1"])', modal);
      setTimeout(function () { (first || panel).focus(); }, 60);
      track('demo_modal_open', { page_path: location.pathname });
    }
    function close() {
      modal.classList.remove('open');
      document.body.classList.remove('modal-open');
      setTimeout(function () { modal.hidden = true; }, 300);
      if (lastFocus && lastFocus.focus) lastFocus.focus();
    }
    $$('[data-demo-open]').forEach(function (a) { a.addEventListener('click', open); });
    $$('[data-modal-close]', modal).forEach(function (b) { b.addEventListener('click', close); });
    document.addEventListener('keydown', function (e) {
      if (modal.hidden) return;
      if (e.key === 'Escape') close();
      if (e.key === 'Tab') { // keep focus inside the dialog
        var f = $$('a[href], button:not([disabled]), input:not([type=hidden]):not([tabindex="-1"]), select, textarea', panel).filter(function (el) { return el.offsetParent !== null; });
        if (!f.length) return;
        if (e.shiftKey && document.activeElement === f[0]) { e.preventDefault(); f[f.length - 1].focus(); }
        else if (!e.shiftKey && document.activeElement === f[f.length - 1]) { e.preventDefault(); f[0].focus(); }
      }
    });
    if (location.hash === '#book-a-demo') open();
  }
  function closeMobileMenu() {
    var btn = $('.nav-toggle');
    if (btn && btn.getAttribute('aria-expanded') === 'true') btn.click();
  }

  /* ---------------------------------------------------------------------
     Lead forms (contact + demo): client checks, then POST via fetch.
     Without JavaScript the same forms post normally and the server
     redirects to /thank-you or re-renders with errors.
     --------------------------------------------------------------------- */
  var MESSAGES = {
    name: 'Enter your full name.',
    company: 'Enter your company or organisation.',
    email: 'Enter a valid email address, like name@company.com.',
    phone: 'Enter a phone number with at least 10 digits, including country code if outside India.',
    event_type: 'Choose the type of event.',
    message: 'Tell us a little about your event (at least 10 characters).',
    preferred_date: 'Choose a preferred demo date.'
  };

  function clientCheck(form) {
    var errors = {};
    var val = function (n) { var el = form.elements[n]; return el ? String(el.value || '').trim() : null; };
    if (val('name') !== null && val('name').length < 2) errors.name = MESSAGES.name;
    if (val('company') !== null && val('company').length < 2) errors.company = MESSAGES.company;
    if (val('email') !== null && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(val('email'))) errors.email = MESSAGES.email;
    if (val('phone') !== null && val('phone').replace(/\D/g, '').length < 10) errors.phone = MESSAGES.phone;
    if (val('event_type') !== null && !val('event_type')) errors.event_type = MESSAGES.event_type;
    if (form.dataset.kind === 'contact' && val('message').length < 10) errors.message = MESSAGES.message;
    if (form.dataset.kind === 'demo' && !val('preferred_date')) errors.preferred_date = MESSAGES.preferred_date;
    return errors;
  }

  function showErrors(form, errors) {
    $$('.field', form).forEach(function (f) {
      var input = $('input, select, textarea', f);
      if (!input || !input.name) return;
      var msg = errors[input.name] || '';
      f.classList.toggle('invalid', !!msg);
      input.setAttribute('aria-invalid', String(!!msg));
      var err = $('.err', f); if (err) err.textContent = msg;
    });
  }

  function setStatus(form, type, msg) {
    var s = $('.form-status', form);
    if (!s) return;
    s.className = 'form-status' + (type ? ' is-' + type : '');
    s.textContent = msg || '';
  }

  function initLeadForms() {
    $$('[data-ajax-form]').forEach(function (form) {
      // Re-validate a field as the user corrects it
      form.addEventListener('input', function (e) {
        var f = e.target.closest('.field');
        if (f && f.classList.contains('invalid')) {
          var errs = clientCheck(form);
          var single = {}; if (errs[e.target.name]) single[e.target.name] = errs[e.target.name];
          f.classList.toggle('invalid', !!single[e.target.name]);
          var err = $('.err', f); if (err) err.textContent = single[e.target.name] || '';
        }
      });

      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var errors = clientCheck(form);
        showErrors(form, errors);
        if (Object.keys(errors).length) {
          setStatus(form, 'error', 'Some details need attention. Check the highlighted fields.');
          var first = $('.field.invalid input, .field.invalid select, .field.invalid textarea', form);
          if (first) first.focus();
          return;
        }
        var btn = $('button[type="submit"]', form);
        var label = btn.textContent;
        btn.disabled = true; btn.textContent = 'Sending…';
        setStatus(form, '', '');
        fetch(form.action, {
          method: 'POST',
          headers: { 'Accept': 'application/json', 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams(new FormData(form)).toString(),
          credentials: 'same-origin'
        }).then(function (r) {
          return r.json().catch(function () { return { ok: false, message: 'Unexpected response from the server. Try again, or contact us on WhatsApp or by phone.' }; });
        }).then(function (data) {
          if (data.ok) {
            track(form.dataset.kind === 'demo' ? 'generate_lead_demo' : 'generate_lead_contact', { reference: data.ref });
            done(form, data);
          } else {
            showErrors(form, data.errors || {});
            setStatus(form, 'error', data.message || 'Your request could not be sent. Try again.');
            var first = $('.field.invalid input, .field.invalid select, .field.invalid textarea', form);
            if (first) first.focus();
          }
        }).catch(function () {
          setStatus(form, 'error', 'We couldn\'t reach the server. Check your connection and try again, or contact us on WhatsApp or by phone.');
        }).then(function () {
          btn.disabled = false; btn.textContent = label;
          if (window.turnstile && $('.cf-turnstile', form)) { try { window.turnstile.reset($('.cf-turnstile', form)); } catch (err) { /* ignore */ } }
        });
      });
    });
  }

  function done(form, data) {
    var box = document.createElement('div');
    box.className = 'form-done';
    box.setAttribute('tabindex', '-1');
    box.innerHTML = '<div class="success-mark"><svg viewBox="0 0 52 52" aria-hidden="true"><circle cx="26" cy="26" r="24"/><path d="M15 27l7 7 15-16"/></svg></div>' +
      '<h3></h3><p></p><button type="button" class="link-btn">Send another request</button>';
    $('h3', box).textContent = form.dataset.kind === 'demo' ? 'Demo request received' : 'Enquiry received';
    $('p', box).textContent = data.message;
    form.hidden = true;
    form.parentNode.insertBefore(box, form.nextSibling);
    box.focus();
    $('.link-btn', box).addEventListener('click', function () {
      form.reset(); showErrors(form, {}); setStatus(form, '', '');
      box.remove(); form.hidden = false;
      var first = $('input:not([type=hidden]):not([tabindex="-1"])', form); if (first) first.focus();
    });
  }

  /* ---------------------------------------------------------------------
     Analytics helper: sends GA4 / GTM events only when configured
     --------------------------------------------------------------------- */
  function track(name, params) {
    try {
      if (typeof window.gtag === 'function') window.gtag('event', name, params || {});
      else if (Array.isArray(window.dataLayer)) window.dataLayer.push(Object.assign({ event: name }, params || {}));
    } catch (e) { /* analytics must never break the page */ }
  }

  function initWhatsAppTracking() {
    $$('[data-wa]').forEach(function (a) {
      a.addEventListener('click', function () { track('whatsapp_click', { location: a.getAttribute('data-wa'), page_path: location.pathname }); });
    });
  }

  /* ---------------------------------------------------------------------
     Blog: copy link + table-of-contents highlighting
     --------------------------------------------------------------------- */
  function initBlog() {
    $$('[data-copy]').forEach(function (b) {
      b.addEventListener('click', function () {
        var label = b.textContent;
        var ok = function () { b.textContent = 'Link copied'; setTimeout(function () { b.textContent = label; }, 2000); };
        var fail = function () { b.textContent = 'Copy unavailable'; setTimeout(function () { b.textContent = label; }, 2000); };
        try { navigator.clipboard.writeText(b.getAttribute('data-copy')).then(ok, fail); } catch (e) { fail(); }
      });
    });
    var links = $$('.toc a');
    if (!links.length || !('IntersectionObserver' in window)) return;
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) links.forEach(function (l) { l.classList.toggle('active', l.getAttribute('href') === '#' + en.target.id); });
      });
    }, { rootMargin: '-20% 0px -70% 0px' });
    $$('.prose h2[id]').forEach(function (h) { io.observe(h); });
  }

  /* ---------------------------------------------------------------------
     Extra motion: split titles, 3D tilt, parallax, showcase, stats,
     magnetic buttons, product filter, gallery
     --------------------------------------------------------------------- */
  function initSplit() {
    $$('[data-split]').forEach(function (el) {
      var words = el.textContent.trim().split(/\s+/);
      el.setAttribute('aria-label', el.textContent.trim());
      el.innerHTML = words.map(function (w, i) { return '<span class="w" aria-hidden="true"><span style="--i:' + i + '">' + w.replace(/&/g, '&amp;').replace(/</g, '&lt;') + '</span></span>'; }).join(' ');
    });
  }

  var finePointer = window.matchMedia('(pointer: fine)').matches;

  function initTilt() {
    if (reduceMotion || !finePointer) return;
    $$('[data-tilt]').forEach(function (el) {
      var shine = $('.pc-shine', el);
      el.addEventListener('pointermove', function (e) {
        var r = el.getBoundingClientRect();
        var x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
        el.classList.add('tilting');
        el.style.transform = 'perspective(900px) rotateX(' + ((.5 - y) * 7).toFixed(2) + 'deg) rotateY(' + ((x - .5) * 9).toFixed(2) + 'deg) translateY(-4px)';
        if (shine) { el.style.setProperty('--sx', (x * 100) + '%'); el.style.setProperty('--sy', (y * 100) + '%'); }
      });
      el.addEventListener('pointerleave', function () {
        el.classList.remove('tilting');
        el.style.transition = 'transform .6s cubic-bezier(.22,.8,.26,1)';
        el.style.transform = '';
        setTimeout(function () { el.style.transition = ''; }, 600);
      });
    });
  }

  function initParallax() {
    var els = $$('[data-parallax]');
    if (reduceMotion || !els.length) return;
    var ticking = false;
    function update() {
      els.forEach(function (el) {
        var r = el.getBoundingClientRect();
        var off = (r.top + r.height / 2 - window.innerHeight / 2) * -0.06;
        el.style.translate = '0 ' + off.toFixed(1) + 'px';
      });
      ticking = false;
    }
    window.addEventListener('scroll', function () { if (!ticking) { requestAnimationFrame(update); ticking = true; } }, { passive: true });
    update();
  }

  function initShowcase() {
    var sc = $('[data-showcase]');
    if (!sc || reduceMotion || !finePointer) return;
    var stage = $('.sc-stage', sc);
    var host = sc.closest('section');
    host.addEventListener('pointermove', function (e) {
      var r = sc.getBoundingClientRect();
      var x = (e.clientX - (r.left + r.width / 2)) / r.width, y = (e.clientY - (r.top + r.height / 2)) / r.height;
      stage.style.transform = 'translate(-50%, -50%) rotateY(' + (x * 14).toFixed(2) + 'deg) rotateX(' + (-y * 10).toFixed(2) + 'deg)';
    });
    host.addEventListener('pointerleave', function () { stage.style.transform = ''; });
  }

  function initStats() {
    $$('[data-stats] dt').forEach(function (dt) {
      var m = dt.textContent.trim().match(/^([\d,]+)(\s*s)?$/);
      if (!m || reduceMotion) return;
      var target = parseInt(m[1].replace(/,/g, ''), 10), suffix = m[2] || '';
      dt.textContent = '0' + suffix;
      onVisible(dt, function () {
        var start = performance.now(), dur = target > 1000 ? 1800 : 1100;
        (function tick(now) {
          var t = Math.min((now - start) / dur, 1);
          dt.textContent = formatIN(target * (1 - Math.pow(1 - t, 4))) + suffix;
          if (t < 1) requestAnimationFrame(tick);
        })(start);
      }, { threshold: 0.6 });
    });
  }

  function initMagnetic() {
    if (reduceMotion || !finePointer) return;
    $$('.btn-primary, .btn-wa, .btn-wa-ghost, .btn-ghost, [data-magnetic]').forEach(function (b) {
      b.addEventListener('pointermove', function (e) {
        var r = b.getBoundingClientRect();
        b.style.transform = 'translate(' + ((e.clientX - r.left - r.width / 2) * .18).toFixed(1) + 'px,' + ((e.clientY - r.top - r.height / 2) * .25 - 2).toFixed(1) + 'px)';
      });
      b.addEventListener('pointerleave', function () { b.style.transform = ''; });
    });
  }

  function initProductFilter() {
    var bar = $('.filter-bar');
    if (!bar) return;
    var btns = $$('button', bar), cats = $$('.prod-cat');
    function apply(f, scroll) {
      btns.forEach(function (b) { var on = b.dataset.filter === f; b.classList.toggle('on', on); b.setAttribute('aria-pressed', String(on)); });
      cats.forEach(function (c) {
        var show = f === 'all' || c.dataset.cat === f;
        c.classList.toggle('hide', !show);
        if (show) { c.classList.remove('fade-in'); void c.offsetWidth; c.classList.add('fade-in'); $$('.reveal', c).forEach(function (r) { r.classList.add('in'); }); }
      });
      if (scroll) bar.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'start' });
    }
    btns.forEach(function (b) { b.addEventListener('click', function () { apply(b.dataset.filter, false); }); });
    var h = location.hash.slice(1);
    if (h && btns.some(function (b) { return b.dataset.filter === h; })) apply(h, true);
  }

  function initGallery() {
    var main = $('[data-gallery-main]');
    if (!main) return;
    $$('[data-gallery-src]').forEach(function (b) {
      b.addEventListener('click', function () {
        $$('[data-gallery-src]').forEach(function (x) { x.classList.toggle('on', x === b); });
        main.classList.add('swap');
        setTimeout(function () { main.src = b.dataset.gallerySrc; main.alt = b.dataset.galleryAlt; main.classList.remove('swap'); }, 200);
      });
    });
  }


  /* Footer groups: accordions on small screens, always open on larger ones */
  function initFooterAccordion() {
    var cols = $$('.f-col');
    if (!cols.length) return;
    var mq = window.matchMedia('(max-width: 760px)');
    function apply() { cols.forEach(function (d) { if (mq.matches) d.removeAttribute('open'); else d.setAttribute('open', ''); }); }
    apply();
    if (mq.addEventListener) mq.addEventListener('change', apply); else if (mq.addListener) mq.addListener(apply);
    cols.forEach(function (d) { d.querySelector('summary').addEventListener('click', function (e) { if (!mq.matches) e.preventDefault(); }); });
  }

  /* ---------------------------------------------------------------------
     Boot
     --------------------------------------------------------------------- */
  initSplit();
  initFooterAccordion();
  initLoad();
  initHeader();
  initMegaMenu();
  initMobileMenu();
  initReveal();
  initHeroCanvas();
  initHeroStage();
  initTabs();
  initCardGlow();
  initEcosystem();
  initCounters();
  initFlow();
  initStatusCycle();
  initFaceDemo();
  initRail();
  initJourneys();
  initWorkflow();
  initDemoModal();
  initLeadForms();
  initWhatsAppTracking();
  initBlog();
  initTilt();
  initParallax();
  initShowcase();
  initStats();
  initMagnetic();
  initProductFilter();
  initGallery();
})();
