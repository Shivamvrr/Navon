/* Navon admin interactions: confirms, quick status changes, post editor tools. */
(function () {
  'use strict';
  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };
  var CSRF = window.NAVON_CSRF || '';

  // Confirmation for destructive actions (custom inline confirm to avoid browser dialogs being blocked)
  $$('form[data-confirm]').forEach(function (f) {
    f.addEventListener('submit', function (e) {
      if (f.dataset.confirmed) return;
      e.preventDefault();
      var btn = $('button[type=submit]', f);
      if (btn.dataset.armed) { f.dataset.confirmed = '1'; f.submit(); return; }
      btn.dataset.armed = '1';
      var label = btn.textContent;
      btn.textContent = 'Click again to confirm';
      setTimeout(function () { delete btn.dataset.armed; btn.textContent = label; }, 4000);
    });
  });

  // Auto-submit status selects in lists
  $$('select[data-autosubmit]').forEach(function (s) { s.addEventListener('change', function () { s.form.submit(); }); });

  /* ---------------- Post editor ---------------- */
  var form = $('#post-form');
  if (!form) return;
  var title = $('#f-title'), slug = $('#f-slug'), content = $('#f-content'), preview = $('#md-preview');

  function slugify(s) {
    return String(s || '').toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 90);
  }
  title.addEventListener('input', function () { if (!slug.dataset.touched) { slug.value = slugify(title.value); updateSerp(); } });
  slug.addEventListener('input', function () { slug.dataset.touched = '1'; updateSerp(); });
  slug.addEventListener('blur', function () { slug.value = slugify(slug.value); updateSerp(); });

  // Character counters
  $$('[data-count-for]').forEach(function (c) {
    var input = form.elements[c.dataset.countFor];
    var max = parseInt(c.dataset.max, 10);
    function upd() {
      var n = input.value.length;
      c.textContent = n + ' / ' + max;
      c.classList.toggle('over', n > max);
      c.classList.toggle('good', n >= Math.round(max * 0.6) && n <= max);
      updateSerp();
    }
    input.addEventListener('input', upd); upd();
  });

  function updateSerp() {
    var t = form.elements.seo_title.value || (title.value ? title.value + ' | Navon Innovations' : 'Post title');
    var d = form.elements.meta_description.value || form.elements.excerpt.value || 'Meta description';
    $('#serp-title').textContent = t.length > 62 ? t.slice(0, 60) + '…' : t;
    $('#serp-desc').textContent = d.length > 162 ? d.slice(0, 158) + '…' : d;
    $('#serp-slug').textContent = slug.value || 'your-post';
  }
  form.elements.excerpt.addEventListener('input', updateSerp);
  updateSerp();

  // Markdown toolbar
  function wrap(before, after, placeholder) {
    var s = content.selectionStart, e = content.selectionEnd;
    var sel = content.value.slice(s, e) || placeholder || '';
    content.setRangeText(before + sel + (after || ''), s, e, 'end');
    content.focus();
    if (!content.value.slice(s, e)) { content.selectionStart = s + before.length; content.selectionEnd = s + before.length + sel.length; }
  }
  function linePrefix(prefix, placeholder) {
    var s = content.selectionStart, e = content.selectionEnd;
    var start = content.value.lastIndexOf('\n', s - 1) + 1;
    var block = content.value.slice(start, e) || placeholder;
    var out = block.split('\n').map(function (l, i) { return (typeof prefix === 'function' ? prefix(i) : prefix) + l.replace(/^(#{1,6} |[-*] |\d+\. |> )/, ''); }).join('\n');
    content.setRangeText(out, start, Math.max(e, start), 'end');
    content.focus();
  }
  var actions = {
    h2: function () { linePrefix('## ', 'Section heading'); },
    h3: function () { linePrefix('### ', 'Sub-heading'); },
    bold: function () { wrap('**', '**', 'bold text'); },
    italic: function () { wrap('*', '*', 'italic text'); },
    ul: function () { linePrefix('- ', 'List item'); },
    ol: function () { linePrefix(function (i) { return (i + 1) + '. '; }, 'List item'); },
    quote: function () { linePrefix('> ', 'Quote'); },
    link: function () {
      var s = content.selectionStart, e = content.selectionEnd;
      var text = content.value.slice(s, e) || 'link text';
      content.setRangeText('[' + text + '](/solutions)', s, e, 'end');
      var urlStart = s + text.length + 3;
      content.focus(); content.selectionStart = urlStart; content.selectionEnd = urlStart + 10;
    },
    image: function () { $('#inline-upload').click(); }
  };
  $$('[data-md]').forEach(function (b) { b.addEventListener('click', function () { actions[b.dataset.md](); }); });

  // Write / preview toggle
  $$('[data-mode]').forEach(function (b) {
    b.addEventListener('click', function () {
      $$('[data-mode]').forEach(function (x) { x.classList.toggle('on', x === b); });
      var prev = b.dataset.mode === 'preview';
      if (prev) {
        preview.innerHTML = '<p class="muted">Rendering…</p>';
        fetch('/admin/preview', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF }, body: JSON.stringify({ content_md: content.value, _csrf: CSRF }) })
          .then(function (r) { return r.json(); })
          .then(function (d) { preview.innerHTML = d.html || '<p class="muted">Nothing to preview yet.</p>'; })
          .catch(function () { preview.innerHTML = '<p class="err">Preview failed. Check your connection.</p>'; });
      }
      preview.hidden = !prev; content.hidden = prev;
    });
  });

  // Uploads
  function upload(file, name) {
    var fd = new FormData();
    fd.append('image', file);
    fd.append('name', name || '');
    return fetch('/admin/upload', { method: 'POST', headers: { 'X-CSRF-Token': CSRF }, body: fd })
      .then(function (r) { return r.json(); });
  }
  var status = $('#upload-status');
  $$('[data-upload-target]').forEach(function (input) {
    input.addEventListener('change', function () {
      if (!input.files[0]) return;
      status.textContent = 'Uploading and compressing…';
      upload(input.files[0], slug.value || title.value).then(function (d) {
        if (!d.ok) { status.textContent = d.message; return; }
        form.elements[input.dataset.uploadTarget].value = d.url;
        $('#feat-preview').innerHTML = '<img src="' + d.url + '" alt="">';
        status.textContent = 'Uploaded: ' + d.width + '×' + d.height + ', ' + Math.round(d.bytes / 1024) + ' KB. Add alt text below.';
        form.elements.featured_image_alt.focus();
      }).catch(function () { status.textContent = 'Upload failed. Try again.'; });
      input.value = '';
    });
  });
  $('#inline-upload').addEventListener('change', function (e) {
    var file = e.target.files[0];
    if (!file) return;
    var marker = '![Uploading ' + file.name + '…]()';
    var pos = content.selectionStart;
    content.setRangeText(marker, pos, content.selectionEnd, 'end');
    upload(file, file.name.replace(/\.[^.]+$/, '')).then(function (d) {
      content.value = content.value.replace(marker, d.ok ? '![Describe this image](' + d.url + ')' : '');
      if (!d.ok) status.textContent = d.message;
    }).catch(function () { content.value = content.value.replace(marker, ''); });
    e.target.value = '';
  });
  $('#f-featured').addEventListener('change', function () {
    var v = this.value.trim();
    $('#feat-preview').innerHTML = v ? '<img src="' + v.replace(/"/g, '') + '" alt="">' : '<span>No image</span>';
  });

  // Warn before leaving with unsaved changes
  var dirty = false;
  form.addEventListener('input', function () { dirty = true; });
  form.addEventListener('submit', function () { dirty = false; });
  window.addEventListener('beforeunload', function (e) { if (dirty) { e.preventDefault(); e.returnValue = ''; } });
})();
