'use strict';
const config = require('./src/config');
const { createApp } = require('./src/app');
const { ensureInitialAdmin } = require('./src/admin-bootstrap');
const { seedIfEmpty } = require('./src/seed');
const { syncArticles } = require('./src/articles-sync');

const app = createApp();
ensureInitialAdmin();
seedIfEmpty();
syncArticles();

app.listen(config.port, () => {
  console.log(`Navon Innovations website running on http://localhost:${config.port} (${config.env})`);
  console.log(`Public URL for SEO: ${config.siteUrl}`);
  if (!config.smtp.host) console.log('Email: SMTP not configured. Submissions are saved but no notification emails are sent.');
});
