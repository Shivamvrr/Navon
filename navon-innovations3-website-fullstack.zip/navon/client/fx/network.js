/* ==========================================================================
   Connected platform globe: modules of the Navon platform as hub nodes on a
   rotating 3D sphere of attendee nodes. Drag to rotate; hover a hub label to
   highlight its connections. Canvas 2D with manual perspective projection.
   ========================================================================== */
export function initNetwork(root) {
  const canvas = root.querySelector('canvas');
  const labels = [...root.querySelectorAll('[data-hub]')];
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const mobile = matchMedia('(max-width: 760px)').matches;

  const N = mobile ? 120 : 220;
  const pts = [];
  for (let i = 0; i < N; i++) { const y = 1 - (i / (N - 1)) * 2, r = Math.sqrt(1 - y * y), th = i * 2.399963; pts.push({ x: Math.cos(th) * r, y, z: Math.sin(th) * r }); }
  /* hub positions spread around the sphere */
  const hubs = labels.map((el, i) => { const phi = Math.acos(1 - 2 * (i + 0.5) / labels.length), th = Math.PI * (1 + Math.sqrt(5)) * i; return { el, x: Math.cos(th) * Math.sin(phi), y: Math.cos(phi) * 0.9, z: Math.sin(th) * Math.sin(phi), links: [] }; });
  const d2 = (a, b) => (a.x - b.x) ** 2 + (a.y - b.y) ** 2 + (a.z - b.z) ** 2;
  const edges = [];
  pts.forEach((p, i) => { pts.map((q, j) => [j, d2(p, q)]).sort((a, b) => a[1] - b[1]).slice(1, 3).forEach(([j]) => { if (j > i) edges.push([i, j]); }); });
  hubs.forEach((h, hi) => { h.links = pts.map((p, j) => [j, d2(h, p)]).sort((a, b) => a[1] - b[1]).slice(0, 9).map((x) => x[0]); h.peers = hubs.map((o, j) => [j, d2(h, o)]).sort((a, b) => a[1] - b[1]).slice(1, 3).map((x) => x[0]); });

  let W = 0, H = 0, R = 0, dpr = Math.min(devicePixelRatio || 1, 2);
  function resize() { const r = canvas.getBoundingClientRect(); W = r.width; H = r.height; R = Math.min(W, H) * 0.38; canvas.width = W * dpr; canvas.height = H * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0); }
  resize(); addEventListener('resize', resize);

  let rotY = 0.6, rotX = -0.25, velY = reduce ? 0 : 0.0028, dragging = false, lastX = 0, lastY = 0, active = -1;
  canvas.addEventListener('pointerdown', (e) => { dragging = true; lastX = e.clientX; lastY = e.clientY; canvas.setPointerCapture(e.pointerId); root.classList.add('grabbing'); });
  canvas.addEventListener('pointermove', (e) => { if (!dragging) return; const dx = e.clientX - lastX, dy = e.clientY - lastY; rotY += dx * 0.006; rotX = Math.max(-1, Math.min(1, rotX + dy * 0.004)); velY = dx * 0.0006; lastX = e.clientX; lastY = e.clientY; if (!running) draw(); });
  const end = () => { dragging = false; root.classList.remove('grabbing'); if (!reduce && Math.abs(velY) < 0.0015) velY = 0.0028 * Math.sign(velY || 1); };
  canvas.addEventListener('pointerup', end); canvas.addEventListener('pointercancel', end);
  labels.forEach((el, i) => { const on = () => { active = i; root.classList.add('has-active'); el.classList.add('on'); if (!running) draw(); }; const off = () => { active = -1; root.classList.remove('has-active'); el.classList.remove('on'); if (!running) draw(); }; el.addEventListener('pointerenter', on); el.addEventListener('pointerleave', off); el.addEventListener('focus', on); el.addEventListener('blur', off); });

  function project(p) {
    const cy = Math.cos(rotY), sy = Math.sin(rotY), cx = Math.cos(rotX), sx = Math.sin(rotX);
    let x = p.x * cy + p.z * sy, z = -p.x * sy + p.z * cy; let y = p.y * cx - z * sx; z = p.y * sx + z * cx;
    const f = 3.2 / (3.2 - z); return { X: W / 2 + x * R * f, Y: H / 2 + y * R * f, z, f };
  }

  let t = 0;
  const pkts = Array.from({ length: mobile ? 14 : 26 }, () => ({ e: edges[(Math.random() * edges.length) | 0], t: Math.random(), s: 0.006 + Math.random() * 0.01 }));
  function draw() {
    ctx.clearRect(0, 0, W, H);
    const P = pts.map(project);
    /* atmosphere */
    const g = ctx.createRadialGradient(W / 2, H / 2, R * 0.2, W / 2, H / 2, R * 1.35); g.addColorStop(0, 'rgba(91,61,245,.16)'); g.addColorStop(1, 'rgba(91,61,245,0)'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    ctx.lineWidth = 1;
    for (const [a, b] of edges) { const A = P[a], B = P[b], depth = (A.z + B.z) / 2; ctx.strokeStyle = `rgba(140,150,255,${0.05 + 0.18 * (depth + 1) / 2})`; ctx.beginPath(); ctx.moveTo(A.X, A.Y); ctx.lineTo(B.X, B.Y); ctx.stroke(); }
    for (const p of P) { const a = 0.25 + 0.6 * (p.z + 1) / 2; ctx.fillStyle = `rgba(190,200,255,${a})`; ctx.beginPath(); ctx.arc(p.X, p.Y, 1.2 * p.f + 0.4, 0, Math.PI * 2); ctx.fill(); }
    /* packets */
    for (const k of pkts) { if (!reduce) k.t += k.s; if (k.t > 1) { k.t = 0; k.e = edges[(Math.random() * edges.length) | 0]; } const A = P[k.e[0]], B = P[k.e[1]]; const x = A.X + (B.X - A.X) * k.t, y = A.Y + (B.Y - A.Y) * k.t; ctx.fillStyle = 'rgba(110,235,255,.95)'; ctx.beginPath(); ctx.arc(x, y, 2.2, 0, Math.PI * 2); ctx.fill(); }
    /* hubs */
    const HP = hubs.map(project);
    hubs.forEach((h, i) => {
      const hp = HP[i], on = active === i, dim = active >= 0 && !on && !hubs[active].peers.includes(i);
      ctx.strokeStyle = on ? 'rgba(126,240,255,.9)' : `rgba(150,130,255,${dim ? 0.08 : 0.35})`; ctx.lineWidth = on ? 1.6 : 1;
      h.links.forEach((j) => { const q = P[j]; ctx.beginPath(); ctx.moveTo(hp.X, hp.Y); ctx.lineTo(q.X, q.Y); ctx.stroke(); });
      h.peers.forEach((j) => { const q = HP[j]; ctx.setLineDash([4, 6]); ctx.lineDashOffset = -t * 20; ctx.strokeStyle = on ? 'rgba(126,240,255,.9)' : `rgba(126,200,255,${dim ? 0.06 : 0.3})`; ctx.beginPath(); ctx.moveTo(hp.X, hp.Y); ctx.lineTo(q.X, q.Y); ctx.stroke(); ctx.setLineDash([]); });
      const pulse = 6 + 3 * Math.sin(t * 3 + i);
      ctx.fillStyle = on ? 'rgba(126,240,255,.35)' : 'rgba(139,115,255,.28)'; ctx.beginPath(); ctx.arc(hp.X, hp.Y, (on ? 14 : pulse) * hp.f, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = on ? '#7EF0FF' : '#B7A9FF'; ctx.beginPath(); ctx.arc(hp.X, hp.Y, 4.5 * hp.f, 0, Math.PI * 2); ctx.fill();
      const el = h.el; el.style.transform = `translate(${hp.X.toFixed(1)}px, ${hp.Y.toFixed(1)}px) translate(-50%, -140%) scale(${(0.82 + 0.22 * (hp.z + 1) / 2).toFixed(3)})`;
      el.style.opacity = String(dim ? 0.35 : 0.45 + 0.55 * (hp.z + 1) / 2); el.style.zIndex = String(Math.round((hp.z + 1) * 50));
    });
    t += 0.016;
  }

  let running = false, visible = false, raf = 0;
  function frame() { raf = 0; if (!dragging) { rotY += velY; velY += ((reduce ? 0 : 0.0028) * Math.sign(velY || 1) - velY) * 0.02; } draw(); if (running) raf = requestAnimationFrame(frame); }
  function update() { const should = visible && !document.hidden && !reduce; if (should && !running) { running = true; raf = requestAnimationFrame(frame); } else if (!should) { running = false; if (raf) cancelAnimationFrame(raf); raf = 0; } }
  new IntersectionObserver(([e]) => { visible = e.isIntersecting; update(); }, { rootMargin: '100px' }).observe(root);
  document.addEventListener('visibilitychange', update);
  draw();
}
