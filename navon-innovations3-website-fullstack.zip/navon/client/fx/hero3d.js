/* ==========================================================================
   Hero 3D scene: a rotating event badge, a live registration screen, a QR
   scan card, an analytics panel with 3D bars, an attendee network and
   drifting particles. Mouse-responsive, paused off-screen, lighter on mobile.
   ========================================================================== */
import {
  WebGLRenderer, Scene, PerspectiveCamera, Group, Mesh, PlaneGeometry, ExtrudeGeometry, Shape,
  MeshStandardMaterial, MeshBasicMaterial, CanvasTexture, AmbientLight, DirectionalLight, PointLight,
  BufferGeometry, Float32BufferAttribute, Points, PointsMaterial, LineSegments, LineBasicMaterial,
  SphereGeometry, IcosahedronGeometry, WireframeGeometry, TorusGeometry, Sprite, SpriteMaterial,
  SRGBColorSpace, AdditiveBlending, MathUtils
} from 'three';

const FONT = '"Manrope", "Segoe UI", system-ui, sans-serif';
const DISPLAY = FONT;

/* ---------- small canvas helpers ---------- */
function makeCanvas(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
function rr(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
function roundedShape(w, h, r) { const s = new Shape(); const x = -w / 2, y = -h / 2; s.moveTo(x + r, y); s.lineTo(x + w - r, y); s.quadraticCurveTo(x + w, y, x + w, y + r); s.lineTo(x + w, y + h - r); s.quadraticCurveTo(x + w, y + h, x + w - r, y + h); s.lineTo(x + r, y + h); s.quadraticCurveTo(x, y + h, x, y + h - r); s.lineTo(x, y + r); s.quadraticCurveTo(x, y, x + r, y); return s; }

/* A deterministic QR-like matrix with three finder patterns */
function qrMatrix(n, seed) {
  let s = seed; const rnd = () => ((s = (s * 9301 + 49297) % 233280) / 233280);
  const m = []; for (let y = 0; y < n; y++) { m.push([]); for (let x = 0; x < n; x++) m[y].push(rnd() > 0.52); }
  const finder = (ox, oy) => { for (let y = -1; y < 8; y++) for (let x = -1; x < 8; x++) { const X = ox + x, Y = oy + y; if (X < 0 || Y < 0 || X >= n || Y >= n) continue; const edge = x === 0 || x === 6 || y === 0 || y === 6; const core = x >= 2 && x <= 4 && y >= 2 && y <= 4; m[Y][X] = x >= 0 && x <= 6 && y >= 0 && y <= 6 && (edge || core); } };
  finder(0, 0); finder(n - 7, 0); finder(0, n - 7);
  return m;
}
function drawQR(ctx, x, y, size, color, seed) {
  const n = 25, m = qrMatrix(n, seed || 7), c = size / n; ctx.fillStyle = color;
  for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) if (m[j][i]) ctx.fillRect(x + i * c, y + j * c, Math.ceil(c), Math.ceil(c));
}

/* ---------- textures ---------- */
function badgeFront() {
  const W = 512, H = 736, c = makeCanvas(W, H), x = c.getContext('2d');
  rr(x, 0, 0, W, H, 44); x.save(); x.clip();
  x.fillStyle = '#FFFFFF'; x.fillRect(0, 0, W, H);
  const g = x.createLinearGradient(0, 0, W, 0); g.addColorStop(0, '#5B3DF5'); g.addColorStop(1, '#2E8CF0');
  x.fillStyle = g; x.fillRect(0, 0, W, 170);
  x.fillStyle = 'rgba(255,255,255,.18)'; for (let i = 0; i < 9; i++) { x.beginPath(); x.arc(W - 30 - i * 8, 30, 110 + i * 26, 0, Math.PI * 2); x.lineWidth = 1.5; x.strokeStyle = 'rgba(255,255,255,.10)'; x.stroke(); }
  rr(x, 196, 40, 120, 14, 7); x.fillStyle = 'rgba(11,18,64,.35)'; x.fill();
  x.fillStyle = '#fff'; x.font = `700 30px ${FONT}`; x.textAlign = 'center'; x.fillText('NAVON EVENTS', W / 2, 112);
  x.font = `600 18px ${FONT}`; x.fillStyle = 'rgba(255,255,255,.8)'; x.fillText('Annual Tech Summit', W / 2, 142);
  // avatar
  x.fillStyle = '#EEF0FB'; x.beginPath(); x.arc(W / 2, 252, 64, 0, Math.PI * 2); x.fill();
  x.fillStyle = '#C3C8E8'; x.beginPath(); x.arc(W / 2, 236, 24, 0, Math.PI * 2); x.fill();
  x.beginPath(); x.ellipse(W / 2, 296, 40, 26, 0, Math.PI, 0); x.fill();
  x.fillStyle = '#0B1240'; x.font = `700 40px ${DISPLAY}`; x.fillText('Attendee Name', W / 2, 372);
  x.fillStyle = '#6B7194'; x.font = `500 22px ${FONT}`; x.fillText('Company Name', W / 2, 406);
  rr(x, W / 2 - 78, 428, 156, 40, 20); x.fillStyle = '#EFECFF'; x.fill();
  x.fillStyle = '#4527E0'; x.font = `800 18px ${FONT}`; x.fillText('DELEGATE', W / 2, 455);
  rr(x, W / 2 - 92, 492, 184, 184, 16); x.fillStyle = '#F4F5FB'; x.fill();
  drawQR(x, W / 2 - 78, 506, 156, '#0B1240', 11);
  x.fillStyle = '#5B3DF5'; x.fillRect(0, H - 34, W, 34);
  x.fillStyle = '#fff'; x.font = `700 15px ${FONT}`; x.fillText('ALL ACCESS', W / 2, H - 12);
  x.restore();
  return c;
}
function badgeBack() {
  const W = 512, H = 736, c = makeCanvas(W, H), x = c.getContext('2d');
  rr(x, 0, 0, W, H, 44); x.save(); x.clip();
  const g = x.createLinearGradient(0, 0, W, H); g.addColorStop(0, '#141C5C'); g.addColorStop(1, '#3B1FB0');
  x.fillStyle = g; x.fillRect(0, 0, W, H);
  x.strokeStyle = 'rgba(255,255,255,.08)'; x.lineWidth = 2;
  for (let i = 0; i < 14; i++) { x.beginPath(); x.arc(W / 2, H / 2, 40 + i * 28, 0, Math.PI * 2); x.stroke(); }
  x.fillStyle = '#fff'; x.textAlign = 'center'; x.font = `700 46px ${DISPLAY}`; x.fillText('Navon', W / 2, H / 2 - 6);
  x.font = `500 24px ${FONT}`; x.fillStyle = 'rgba(255,255,255,.7)'; x.fillText('Innovations', W / 2, H / 2 + 30);
  x.font = `700 14px ${FONT}`; x.fillStyle = 'rgba(255,255,255,.5)'; x.fillText('POWERING SMARTER EVENTS', W / 2, H - 50);
  x.restore();
  return c;
}

/* Dark-glass panel base: translucent fill, hairline border, header */
function glassBase(x, W, H, title, accent) {
  x.clearRect(0, 0, W, H);
  rr(x, 2, 2, W - 4, H - 4, 34);
  const g = x.createLinearGradient(0, 0, W, H); g.addColorStop(0, 'rgba(255,255,255,.16)'); g.addColorStop(1, 'rgba(255,255,255,.05)');
  x.fillStyle = g; x.fill();
  x.lineWidth = 2; x.strokeStyle = 'rgba(255,255,255,.28)'; x.stroke();
  x.fillStyle = accent; x.beginPath(); x.arc(44, 46, 8, 0, Math.PI * 2); x.fill();
  x.fillStyle = '#fff'; x.font = `700 26px ${FONT}`; x.textAlign = 'left'; x.fillText(title, 64, 55);
}

function registrationPanel() {
  const W = 640, H = 440, c = makeCanvas(W, H), x = c.getContext('2d');
  const fields = [['Full name', 'Priya Sharma'], ['Work email', 'priya@company.com'], ['Organisation', 'Company Name']];
  let step = 0;
  function draw() {
    glassBase(x, W, H, 'Attendee registration', '#9A86FF');
    const total = fields.reduce((a, f) => a + f[1].length, 0) + 6;
    let budget = step;
    fields.forEach((f, i) => {
      const y = 92 + i * 92;
      x.fillStyle = 'rgba(255,255,255,.6)'; x.font = `600 18px ${FONT}`; x.fillText(f[0], 40, y + 4);
      rr(x, 40, y + 16, W - 80, 50, 14); x.fillStyle = 'rgba(255,255,255,.10)'; x.fill();
      const shown = Math.max(0, Math.min(f[1].length, budget)); budget -= f[1].length;
      x.fillStyle = '#fff'; x.font = `600 22px ${FONT}`; x.fillText(f[1].slice(0, shown), 58, y + 49);
      if (shown > 0 && shown < f[1].length) { const tw = x.measureText(f[1].slice(0, shown)).width; x.fillRect(60 + tw, y + 30, 2, 24); }
    });
    const done = step >= total - 6;
    rr(x, 40, H - 74, W - 80, 48, 24);
    const bg = x.createLinearGradient(40, 0, W - 40, 0); bg.addColorStop(0, done ? '#12B886' : '#8067FF'); bg.addColorStop(1, done ? '#0FA3B1' : '#246BFD');
    x.fillStyle = bg; x.fill();
    x.fillStyle = '#fff'; x.textAlign = 'center'; x.font = `700 21px ${FONT}`; x.fillText(done ? '✓  Registered, QR e-badge sent' : 'Register', W / 2, H - 43); x.textAlign = 'left';
    step = (step + 1) % (total + 10);
  }
  draw();
  return { canvas: c, tick: draw };
}

function qrPanel() {
  const W = 420, H = 500, c = makeCanvas(W, H), x = c.getContext('2d');
  let phase = 0;
  function draw() {
    glassBase(x, W, H, 'QR check-in', '#5AB2FF');
    rr(x, 70, 92, 280, 280, 22); x.fillStyle = '#fff'; x.fill();
    drawQR(x, 92, 114, 236, '#0B1240', 23);
    const ok = phase > 0.7;
    x.strokeStyle = ok ? '#12B886' : '#2EC4E6'; x.lineWidth = 6; x.lineCap = 'round';
    [[60, 82, 1, 1], [360, 82, -1, 1], [60, 382, 1, -1], [360, 382, -1, -1]].forEach(([px, py, dx, dy]) => { x.beginPath(); x.moveTo(px, py + 34 * dy); x.lineTo(px, py); x.lineTo(px + 34 * dx, py); x.stroke(); });
    rr(x, 70, 404, 280, 56, 28); x.fillStyle = ok ? 'rgba(18,184,134,.9)' : 'rgba(255,255,255,.12)'; x.fill();
    x.fillStyle = '#fff'; x.font = `700 22px ${FONT}`; x.textAlign = 'center'; x.fillText(ok ? '✓  Verified, entry granted' : 'Scanning…', W / 2, 440); x.textAlign = 'left';
  }
  draw();
  return { canvas: c, set(p) { const was = phase > 0.7; phase = p; if ((p > 0.7) !== was || Math.random() < 0.02) draw(); } };
}

/* Floating event dashboard: KPIs, a live line chart and entry-method split */
function dashboardPanel() {
  const W = 900, H = 560, c = makeCanvas(W, H), x = c.getContext('2d');
  const pts = Array.from({ length: 28 }, (_, i) => 0.3 + 0.22 * Math.sin(i / 3.2) + 0.12 * Math.sin(i / 1.4) + i * 0.012);
  let checked = 2480, t = 0;
  function draw() {
    glassBase(x, W, H, 'Event command centre', '#4DE3A8');
    x.fillStyle = 'rgba(255,255,255,.5)'; x.font = `600 18px ${FONT}`; x.textAlign = 'right'; x.fillText('Sample data', W - 40, 54); x.textAlign = 'left';
    const kpis = [['Registered', '3,200'], ['Checked in', checked.toLocaleString('en-IN')], ['In sessions', Math.round(checked * 0.62).toLocaleString('en-IN')]];
    kpis.forEach(([k, v], i) => {
      const bx = 40 + i * 280; rr(x, bx, 86, 256, 104, 18); x.fillStyle = 'rgba(255,255,255,.07)'; x.fill();
      x.fillStyle = 'rgba(255,255,255,.62)'; x.font = `600 19px ${FONT}`; x.fillText(k, bx + 20, 120);
      x.fillStyle = '#fff'; x.font = `800 40px ${FONT}`; x.fillText(v, bx + 20, 168);
    });
    const L = 40, R = 600, T = 236, B = H - 56;
    x.strokeStyle = 'rgba(255,255,255,.08)'; x.lineWidth = 1;
    for (let i = 0; i < 4; i++) { const y = T + (B - T) * i / 3; x.beginPath(); x.moveTo(L, y); x.lineTo(R, y); x.stroke(); }
    const n = pts.length, px = (i) => L + (R - L) * i / (n - 1), py = (v) => B - (B - T) * v;
    const line = new Path2D(); line.moveTo(px(0), py(pts[0]));
    for (let i = 1; i < n; i++) { const xm = (px(i - 1) + px(i)) / 2; line.bezierCurveTo(xm, py(pts[i - 1]), xm, py(pts[i]), px(i), py(pts[i])); }
    const area = new Path2D(line); area.lineTo(R, B); area.lineTo(L, B); area.closePath();
    const g = x.createLinearGradient(0, T, 0, B); g.addColorStop(0, 'rgba(36,107,253,.5)'); g.addColorStop(1, 'rgba(36,107,253,0)');
    x.fillStyle = g; x.fill(area);
    const lg = x.createLinearGradient(L, 0, R, 0); lg.addColorStop(0, '#8067FF'); lg.addColorStop(1, '#5AB2FF');
    x.strokeStyle = lg; x.lineWidth = 4; x.stroke(line);
    x.fillStyle = '#fff'; x.beginPath(); x.arc(px(n - 1), py(pts[n - 1]), 7, 0, Math.PI * 2); x.fill();
    x.fillStyle = 'rgba(90,178,255,.3)'; x.beginPath(); x.arc(px(n - 1), py(pts[n - 1]), 14 + 4 * Math.sin(t), 0, Math.PI * 2); x.fill();
    x.fillStyle = 'rgba(255,255,255,.62)'; x.font = `600 17px ${FONT}`; x.fillText('Check-ins per minute', L, T - 14);
    // donut
    const cx = 750, cy = 360, r = 86, parts = [[0.48, '#8067FF', 'QR'], [0.32, '#246BFD', 'Face'], [0.2, '#4DE3A8', 'RFID']];
    let a0 = -Math.PI / 2;
    parts.forEach(([v, col]) => { x.beginPath(); x.arc(cx, cy, r, a0, a0 + v * Math.PI * 2); x.strokeStyle = col; x.lineWidth = 22; x.stroke(); a0 += v * Math.PI * 2; });
    x.fillStyle = '#fff'; x.textAlign = 'center'; x.font = `800 30px ${FONT}`; x.fillText('3', cx, cy + 4); x.font = `600 15px ${FONT}`; x.fillStyle = 'rgba(255,255,255,.6)'; x.fillText('entry methods', cx, cy + 26); x.textAlign = 'left';
    parts.forEach(([, col, k], i) => { const lx = 668 + i * 66; x.fillStyle = col; x.fillRect(lx, H - 66, 14, 14); x.fillStyle = 'rgba(255,255,255,.75)'; x.font = `600 16px ${FONT}`; x.fillText(k, lx + 20, H - 53); });
    t += 0.7;
  }
  draw();
  return { canvas: c, tick() { pts.shift(); pts.push(MathUtils.clamp(pts[pts.length - 1] + (Math.random() - 0.42) * 0.12, 0.18, 0.92)); checked += 2 + Math.round(Math.random() * 7); draw(); } };
}

function faceCard() {
  const W = 460, H = 200, c = makeCanvas(W, H), x = c.getContext('2d');
  glassBase(x, W, H, 'Face verified', '#4DE3A8');
  x.fillStyle = 'rgba(77,227,168,.18)'; x.beginPath(); x.arc(84, 132, 40, 0, Math.PI * 2); x.fill();
  x.strokeStyle = '#4DE3A8'; x.lineWidth = 4; x.beginPath(); x.arc(84, 120, 13, 0, Math.PI * 2); x.stroke();
  x.beginPath(); x.arc(84, 156, 22, Math.PI * 1.15, Math.PI * 1.85); x.stroke();
  x.fillStyle = '#fff'; x.font = `700 26px ${FONT}`; x.fillText('Access granted', 144, 124);
  x.fillStyle = 'rgba(255,255,255,.6)'; x.font = `600 19px ${FONT}`; x.fillText('Gate 1, sub-second match', 144, 156);
  return c;
}

function glowTexture(inner, outer) {
  const c = makeCanvas(256, 256), x = c.getContext('2d');
  const g = x.createRadialGradient(128, 128, 0, 128, 128, 128);
  g.addColorStop(0, inner); g.addColorStop(0.35, outer); g.addColorStop(1, 'rgba(0,0,0,0)');
  x.fillStyle = g; x.fillRect(0, 0, 256, 256); return c;
}

/* ---------- scene ---------- */
export function initHero3D(section) {
  const canvas = section.querySelector('.h3-canvas');
  if (!canvas) return;
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const mobile = matchMedia('(max-width: 900px)').matches;
  const coarse = matchMedia('(pointer: coarse)').matches;

  let renderer;
  try { renderer = new WebGLRenderer({ canvas, antialias: !mobile, alpha: true, powerPreference: 'high-performance' }); }
  catch (e) { section.classList.add('no-gl'); return; }
  if (!renderer.getContext()) { section.classList.add('no-gl'); return; }
  renderer.setPixelRatio(Math.min(devicePixelRatio || 1, mobile ? 1.5 : 2));
  renderer.outputColorSpace = SRGBColorSpace;

  const scene = new Scene();
  const camera = new PerspectiveCamera(34, 1, 0.1, 100);
  camera.position.set(0, 0, 14);
  scene.add(new AmbientLight(0xbfd0ff, 1.1));
  const key = new DirectionalLight(0xffffff, 1.6); key.position.set(4, 6, 8); scene.add(key);
  const pV = new PointLight(0x8067ff, 50, 30); pV.position.set(-4, 2, 5); scene.add(pV);
  const pB = new PointLight(0x246bfd, 60, 30); pB.position.set(5, -3, 4); scene.add(pB);

  const world = new Group(); scene.add(world);
  const tex = (c) => { const t = new CanvasTexture(c); t.colorSpace = SRGBColorSpace; t.anisotropy = 4; return t; };
  const glassBody = new MeshStandardMaterial({ color: 0x1a2f66, transparent: true, opacity: 0.4, roughness: 0.2, metalness: 0.1 });
  function panel(w, h, texture) {
    const g = new Group();
    const body = new Mesh(new ExtrudeGeometry(roundedShape(w, h, 0.16), { depth: 0.04, bevelEnabled: true, bevelThickness: 0.02, bevelSize: 0.02, bevelSegments: 2, curveSegments: 8 }), glassBody);
    body.position.z = -0.04; g.add(body);
    const face = new Mesh(new PlaneGeometry(w, h), new MeshBasicMaterial({ map: texture, transparent: true, depthWrite: false }));
    face.position.z = 0.03; g.add(face);
    return g;
  }

  /* ---- The digital sphere ---- */
  const sphere = new Group();
  const SR = 1.75;
  const halo = new Sprite(new SpriteMaterial({ map: tex(glowTexture('rgba(120,150,255,.9)', 'rgba(60,90,230,.28)')), blending: AdditiveBlending, depthWrite: false, transparent: true }));
  halo.scale.set(SR * 4.6, SR * 4.6, 1); sphere.add(halo);
  const core = new Mesh(new SphereGeometry(SR * 0.94, 48, 48), new MeshBasicMaterial({ color: 0x173a9e, transparent: true, opacity: 0.35, depthWrite: false }));
  sphere.add(core);
  const shell = new LineSegments(new WireframeGeometry(new IcosahedronGeometry(SR, 2)), new LineBasicMaterial({ color: 0x6f8fff, transparent: true, opacity: 0.22, blending: AdditiveBlending, depthWrite: false }));
  sphere.add(shell);
  /* event data points on the surface with nearest-neighbour links */
  const N = mobile ? 70 : 120, nodes = [];
  for (let i = 0; i < N; i++) { const y = 1 - (i / (N - 1)) * 2, r = Math.sqrt(1 - y * y), th = i * 2.399963; nodes.push([Math.cos(th) * r * SR * 1.02, y * SR * 1.02, Math.sin(th) * r * SR * 1.02]); }
  const ng = new BufferGeometry(); ng.setAttribute('position', new Float32BufferAttribute(nodes.flat(), 3));
  sphere.add(new Points(ng, new PointsMaterial({ color: 0xc9d6ff, size: 0.07, transparent: true, opacity: 0.95, blending: AdditiveBlending, depthWrite: false })));
  const edges = [], lp = [];
  for (let i = 0; i < N; i++) { const d = nodes.map((n, j) => [j, (n[0] - nodes[i][0]) ** 2 + (n[1] - nodes[i][1]) ** 2 + (n[2] - nodes[i][2]) ** 2]).sort((a, b) => a[1] - b[1]); for (let k = 1; k <= 3; k++) { const j = d[k][0]; if (j > i) { edges.push([i, j]); lp.push(...nodes[i], ...nodes[j]); } } }
  const lg = new BufferGeometry(); lg.setAttribute('position', new Float32BufferAttribute(lp, 3));
  sphere.add(new LineSegments(lg, new LineBasicMaterial({ color: 0x8aa6ff, transparent: true, opacity: 0.35, blending: AdditiveBlending, depthWrite: false })));
  const P = mobile ? 14 : 28, packets = [], pk = new Float32Array(P * 3);
  const pkg = new BufferGeometry(); pkg.setAttribute('position', new Float32BufferAttribute(pk, 3));
  for (let i = 0; i < P; i++) packets.push({ e: edges[(Math.random() * edges.length) | 0], t: Math.random(), s: 0.006 + Math.random() * 0.012 });
  sphere.add(new Points(pkg, new PointsMaterial({ color: 0xffffff, size: 0.11, transparent: true, blending: AdditiveBlending, depthWrite: false })));
  /* orbit rings with travelling data points */
  const rings = [];
  [[2.45, 1.15, 0.3, 0x8067ff], [2.95, 1.35, -0.5, 0x246bfd], [3.45, 1.05, 0.9, 0x5ab2ff]].forEach(([r, tx, tz, col], i) => {
    const g = new Group(); g.rotation.set(tx, 0, tz);
    g.add(new Mesh(new TorusGeometry(r, 0.006, 6, 160), new MeshBasicMaterial({ color: col, transparent: true, opacity: 0.45, blending: AdditiveBlending, depthWrite: false })));
    const sats = new Group();
    for (let k = 0; k < 3; k++) { const dot = new Sprite(new SpriteMaterial({ map: tex(glowTexture('rgba(255,255,255,1)', 'rgba(130,170,255,.5)')), blending: AdditiveBlending, depthWrite: false, transparent: true })); const a = k * Math.PI * 2 / 3 + i; dot.position.set(Math.cos(a) * r, Math.sin(a) * r, 0); dot.scale.setScalar(0.28); sats.add(dot); }
    g.add(sats); sphere.add(g); rings.push({ g, sats, speed: 0.18 + i * 0.07 * (i % 2 ? -1 : 1) });
  });
  world.add(sphere);

  /* ---- Floating dashboard and data cards ---- */
  const dash = dashboardPanel(), dashTex = tex(dash.canvas);
  const dashP = panel(3.3, 3.3 * 560 / 900, dashTex); world.add(dashP);
  const reg = registrationPanel(), regTex = tex(reg.canvas);
  const regP = panel(2.2, 2.2 * 440 / 640, regTex); world.add(regP);
  const qr = qrPanel(), qrTex = tex(qr.canvas);
  const qrP = panel(1.3, 1.3 * 500 / 420, qrTex); world.add(qrP);
  const laser = new Mesh(new PlaneGeometry(0.95, 0.025), new MeshBasicMaterial({ color: 0x9cc8ff, transparent: true, opacity: 0.95, blending: AdditiveBlending, depthWrite: false }));
  laser.position.z = 0.06; qrP.add(laser);
  const faceP = panel(1.9, 1.9 * 200 / 460, tex(faceCard())); world.add(faceP);

  /* ---- Particles ---- */
  const PC = reduce ? 0 : (mobile ? 260 : 700);
  const pArr = new Float32Array(PC * 3), pSpeed = new Float32Array(PC);
  for (let i = 0; i < PC; i++) { pArr[i * 3] = (Math.random() - 0.5) * 26; pArr[i * 3 + 1] = (Math.random() - 0.5) * 16; pArr[i * 3 + 2] = (Math.random() - 0.5) * 14 - 3; pSpeed[i] = 0.002 + Math.random() * 0.005; }
  const pGeo = new BufferGeometry(); pGeo.setAttribute('position', new Float32BufferAttribute(pArr, 3));
  const particles = new Points(pGeo, new PointsMaterial({ color: 0xaac0ff, size: 0.04, transparent: true, opacity: 0.7, blending: AdditiveBlending, depthWrite: false }));
  scene.add(particles);

  /* ---- Layout ---- */
  const items = [
    { o: sphere, base: [0.4, 0.35, 0], m: [0, 0.9, 0], rot: null, float: 0.08, speed: 0.6 },
    { o: dashP, base: [-0.6, -1.95, 1.6], m: [0, -1.85, 1.4], rot: [-0.08, 0.22, 0], float: 0.1, speed: 0.8 },
    { o: regP, base: [-2.55, 1.45, -0.4], m: [-1.35, 2.75, -1.2], rot: [0.04, 0.42, 0.02], float: 0.12, speed: 0.7 },
    { o: qrP, base: [3.05, -0.55, 0.6], m: [1.85, 0.4, 0.4], rot: [-0.04, -0.4, 0], float: 0.14, speed: 1.1 },
    { o: faceP, base: [2.75, 2.05, -0.2], m: [1.4, 2.85, -0.8], rot: [0.05, -0.36, 0.02], float: 0.11, speed: 0.9 }
  ];
  if (mobile) { dashP.scale.setScalar(0.82); regP.scale.setScalar(0.7); qrP.scale.setScalar(0.75); faceP.scale.setScalar(0.72); sphere.scale.setScalar(0.9); }

  let offsetX = 0;
  function resize() {
    const r = canvas.parentElement.getBoundingClientRect();
    renderer.setSize(r.width, r.height, false); camera.aspect = r.width / r.height;
    const wide = r.width / r.height > 1.15 && !mobile;
    camera.fov = wide ? 34 : 44; camera.updateProjectionMatrix();
    offsetX = wide ? Math.min(3.3, (r.width / r.height) * 1.75) : 0;
    world.position.x = offsetX;
  }
  resize(); addEventListener('resize', resize);

  const pointer = { x: 0, y: 0, tx: 0, ty: 0 };
  if (!coarse) section.addEventListener('pointermove', (e) => { const r = section.getBoundingClientRect(); pointer.tx = ((e.clientX - r.left) / r.width - 0.5) * 2; pointer.ty = ((e.clientY - r.top) / r.height - 0.5) * 2; });
  section.addEventListener('pointerleave', () => { pointer.tx = 0; pointer.ty = 0; });
  const chips = [...section.querySelectorAll('[data-depth]')];

  let visible = true, running = true, last = performance.now(), t0 = last, regClock = 0, dashClock = 0, scrollP = 0, raf = 0;
  new IntersectionObserver(([en]) => { visible = en.isIntersecting; if (visible) loop(); }, { threshold: 0 }).observe(section);
  document.addEventListener('visibilitychange', () => { running = !document.hidden; if (running) { last = performance.now(); loop(); } });
  if (!mobile) addEventListener('scroll', () => { const r = section.getBoundingClientRect(); scrollP = MathUtils.clamp(-r.top / Math.max(1, r.height), 0, 1); }, { passive: true });
  const ease = (v) => 1 - Math.pow(1 - v, 4);

  function frame(now) {
    raf = 0;
    const dt = Math.min(0.05, (now - last) / 1000); last = now;
    const t = (now - t0) / 1000;
    pointer.x += (pointer.tx - pointer.x) * 0.05; pointer.y += (pointer.ty - pointer.y) * 0.05;
    world.rotation.y = pointer.x * 0.18 - scrollP * 0.4;
    world.rotation.x = pointer.y * 0.1 + scrollP * 0.2;
    camera.position.z = (mobile ? 11 : 14) + scrollP * 4;
    renderer.domElement.style.opacity = String(1 - scrollP * 0.9);

    items.forEach((it, i) => {
      const b = mobile ? it.m : it.base;
      const k = reduce ? 1 : ease(MathUtils.clamp((t - 0.1 - i * 0.12) / 1.6, 0, 1));
      it.o.position.set(b[0] * (0.5 + 0.5 * k), b[1] + Math.sin(t * it.speed + i) * it.float * (reduce ? 0 : 1), b[2] - (1 - k) * 9);
      if (it.rot) it.o.rotation.set(it.rot[0] + Math.sin(t * 0.5 + i) * 0.03, it.rot[1] + Math.cos(t * 0.4 + i) * 0.04, it.rot[2]);
      it.o.visible = k > 0.001;
    });
    const spin = reduce ? 0 : t;
    sphere.rotation.y = spin * 0.12; shell.rotation.x = spin * 0.05;
    const intro = reduce ? 1 : ease(MathUtils.clamp(t / 1.8, 0, 1));
    sphere.scale.setScalar((mobile ? 0.9 : 1) * (0.6 + 0.4 * intro));
    halo.material.opacity = 0.75 + 0.15 * Math.sin(t * 1.6);
    rings.forEach((r) => { r.sats.rotation.z = spin * r.speed; });
    for (let i = 0; i < packets.length; i++) { const p = packets[i]; if (!reduce) p.t += p.s; if (p.t > 1) { p.t = 0; p.e = edges[(Math.random() * edges.length) | 0]; } const a = nodes[p.e[0]], b2 = nodes[p.e[1]]; pk[i * 3] = a[0] + (b2[0] - a[0]) * p.t; pk[i * 3 + 1] = a[1] + (b2[1] - a[1]) * p.t; pk[i * 3 + 2] = a[2] + (b2[2] - a[2]) * p.t; }
    pkg.attributes.position.needsUpdate = true;

    const lpv = (Math.sin(t * 1.6) + 1) / 2; laser.position.y = 0.46 - lpv * 1.08 + 0.15;
    const cyc = (t % 4) / 4; qr.set(cyc); if (Math.random() < 0.08) qrTex.needsUpdate = true; laser.visible = cyc <= 0.7;
    regClock += dt; if (regClock > 0.09 && !reduce) { regClock = 0; reg.tick(); regTex.needsUpdate = true; }
    dashClock += dt; if (dashClock > 0.9 && !reduce) { dashClock = 0; dash.tick(); dashTex.needsUpdate = true; }

    if (PC) { const a = pGeo.attributes.position.array; for (let i = 0; i < PC; i++) { a[i * 3 + 1] += pSpeed[i]; if (a[i * 3 + 1] > 8) a[i * 3 + 1] = -8; } pGeo.attributes.position.needsUpdate = true; particles.rotation.y = pointer.x * 0.05; }
    chips.forEach((c) => { const d = parseFloat(c.dataset.depth); c.style.transform = `translate3d(${(-pointer.x * 14 * d).toFixed(1)}px, ${(-pointer.y * 10 * d - scrollP * 60 * d).toFixed(1)}px, 0)`; });

    renderer.render(scene, camera);
    if (reduce && t > 2.2) return;
    loop();
  }
  function loop() { if (!raf && visible && running) raf = requestAnimationFrame(frame); }
  const start = () => { section.classList.add('gl-on'); loop(); };
  if (document.fonts && document.fonts.ready) Promise.race([document.fonts.ready, new Promise((r) => setTimeout(r, 900))]).then(() => {
    reg.tick(); regTex.needsUpdate = true; dash.tick(); dashTex.needsUpdate = true; qr.set(0); qrTex.needsUpdate = true; start();
  }); else start();
}
