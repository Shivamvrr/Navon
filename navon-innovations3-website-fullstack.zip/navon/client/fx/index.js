/* Entry for public/js/fx.js (bundled with esbuild: npm run build:fx) */
import { initStagger, initSectionWipes, initScrollDepth, initJourney, initServiceVisuals, initDashboard, initHeadings, initGlare, initEcosystem, initDeviceStage, initAchievements } from './motion-fx.js';

const root = document.documentElement;
root.classList.add('fx-ready');

/* Page preloader: fades once the page has loaded (first visit per session) */
function hidePreloader() {
  const pl = document.querySelector('.preloader');
  if (!pl) return;
  const done = () => { root.classList.add('pl-done'); setTimeout(() => pl.remove(), 900); };
  if (root.classList.contains('pl-skip')) { pl.remove(); return; }
  const started = performance.now();
  const finish = () => setTimeout(done, Math.max(0, 900 - (performance.now() - started)));
  if (document.readyState === 'complete') finish(); else addEventListener('load', finish, { once: true });
  setTimeout(done, 2600); // never block the page for long
}

function safe(fn, name) { try { fn(); } catch (e) { console.warn('[fx]', name, e); } }

hidePreloader();
safe(initStagger, 'stagger');
safe(initSectionWipes, 'wipes');
safe(initScrollDepth, 'depth');
safe(initJourney, 'journey');
safe(initServiceVisuals, 'service visuals');
safe(initDashboard, 'dashboard');
safe(initHeadings, 'headings');
safe(initGlare, 'glare');
safe(initEcosystem, 'ecosystem');
safe(initDeviceStage, 'devices');
safe(initAchievements, 'achievements');

/* 3D modules load only on pages that use them */
const hero = document.querySelector('[data-hero3d]');
if (hero) import('./hero3d.js').then((m) => safe(() => m.initHero3D(hero), 'hero3d')).catch(() => hero.classList.add('no-gl'));
const net = document.querySelector('[data-network]');
if (net) import('./network.js').then((m) => safe(() => m.initNetwork(net), 'network'));
