/* ==========================================================================
   Scroll and UI motion built on Motion (the framework-free build of
   Framer Motion): staggered entrances, section wipes, scroll parallax,
   the attendee-journey path, live sample dashboards and service visuals.
   ========================================================================== */
import { animate, scroll, inView, stagger } from 'motion';

const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
const fine = matchMedia('(pointer: fine)').matches;
const EASE = [0.22, 0.8, 0.26, 1];
const $$ = (s, c = document) => [...c.querySelectorAll(s)];

/* Staggered entrances for groups of cards */
export function initStagger() {
  $$('[data-stagger]').forEach((group) => {
    const kids = [...group.children];
    if (reduce) { kids.forEach((k) => { k.style.opacity = 1; }); return; }
    inView(group, () => {
      animate(kids, { opacity: [0, 1], transform: ['translateY(36px) rotateX(10deg) scale(.97)', 'translateY(0) rotateX(0deg) scale(1)'], filter: ['blur(8px)', 'blur(0px)'] }, { duration: 0.8, delay: stagger(0.07), ease: EASE })
        .then(() => kids.forEach((k) => { k.style.transform = ''; k.style.filter = ''; }));
    }, { amount: 0.15 });
  });
}

/* Dark sections open up from a rounded inset as they scroll in */
export function initSectionWipes() {
  if (reduce) return;
  $$('[data-wipe]').forEach((el) => {
    scroll(animate(el, { clipPath: ['inset(0% 5% 0% 5% round 56px)', 'inset(0% 0% 0% 0% round 0px)'] }, { ease: 'linear' }), { target: el, offset: ['start end', 'start 0.25'] });
  });
}

/* Elements drift at different speeds while scrolling */
export function initScrollDepth() {
  if (reduce) return;
  $$('[data-scroll-depth]').forEach((el) => {
    const d = parseFloat(el.dataset.scrollDepth) || 40;
    scroll(animate(el, { transform: [`translateY(${d}px)`, `translateY(${-d}px)`] }, { ease: 'linear' }), { target: el, offset: ['start end', 'end start'] });
  });
}

/* Attendee journey: a token travels along a path through each step */
export function initJourney() {
  $$('[data-journey]').forEach((flow) => {
    const steps = $$('.flow-step', flow), nums = steps.map((s) => s.querySelector('.num'));
    if (!nums.length) return;
    const NS = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(NS, 'svg'); svg.classList.add('j-svg'); svg.setAttribute('aria-hidden', 'true');
    const base = document.createElementNS(NS, 'path'); base.classList.add('j-base');
    const prog = document.createElementNS(NS, 'path'); prog.classList.add('j-prog');
    svg.append(base, prog);
    const token = document.createElement('span'); token.className = 'j-token'; token.setAttribute('aria-hidden', 'true'); token.innerHTML = '<i class="ico ico-user-plus"></i>';
    flow.prepend(svg); flow.append(token); flow.classList.add('j-on');
    let len = 1, marks = [], p = reduce ? 1 : 0;

    function build() {
      const fr = flow.getBoundingClientRect();
      svg.setAttribute('viewBox', `0 0 ${fr.width} ${fr.height}`); svg.setAttribute('width', fr.width); svg.setAttribute('height', fr.height);
      const c = nums.map((n) => { const r = n.getBoundingClientRect(); return [r.left - fr.left + r.width / 2, r.top - fr.top + r.height / 2]; });
      let d = `M${c[0][0]} ${c[0][1]}`;
      for (let i = 1; i < c.length; i++) {
        const [x0, y0] = c[i - 1], [x1, y1] = c[i];
        if (Math.abs(x1 - x0) < 4) { const w = (i % 2 ? 1 : -1) * 16; d += ` C${x0 + w} ${y0 + (y1 - y0) / 3} ${x1 + w} ${y1 - (y1 - y0) / 3} ${x1} ${y1}`; }
        else if (Math.abs(y1 - y0) < 4) { const mx = (x0 + x1) / 2, w = (i % 2 ? -1 : 1) * 26; d += ` C${mx} ${y0 + w} ${mx} ${y1 + w} ${x1} ${y1}`; }
        else { const dir = x1 < x0 ? -1 : 1, bulge = Math.max(70, Math.abs(y1 - y0) * 0.4); d += ` C${x0 + bulge * (dir < 0 ? 1 : -1) * -1} ${y0 + (y1 - y0) * 0.1} ${x1 + bulge * (dir < 0 ? -1 : 1) * -1} ${y1 - (y1 - y0) * 0.1} ${x1} ${y1}`; }
      }
      base.setAttribute('d', d); prog.setAttribute('d', d);
      len = base.getTotalLength(); prog.style.strokeDasharray = `${len}`;
      /* arc-length position of each step centre */
      marks = c.map(([x, y]) => { let best = 0, bd = Infinity; for (let s = 0; s <= 200; s++) { const pt = base.getPointAtLength(len * s / 200); const dd = (pt.x - x) ** 2 + (pt.y - y) ** 2; if (dd < bd) { bd = dd; best = s / 200; } } return best; });
      render();
    }
    function render() {
      const pt = base.getPointAtLength(len * p);
      token.style.transform = `translate(${pt.x}px, ${pt.y}px) translate(-50%, -50%)`;
      prog.style.strokeDashoffset = `${len * (1 - p)}`;
      steps.forEach((s, i) => s.classList.toggle('on', p >= marks[i] - 0.005));
    }
    build();
    new ResizeObserver(() => build()).observe(flow);
    if (!reduce) scroll((v) => { p = v; render(); }, { target: flow, offset: ['start 0.8', 'end 0.55'] });
  });
}

/* Service visuals only animate while on screen */
export function initServiceVisuals() {
  const io = new IntersectionObserver((entries) => entries.forEach((e) => e.target.classList.toggle('sv-run', e.isIntersecting)), { threshold: 0.2 });
  $$('.sv').forEach((el) => io.observe(el));
}

/* Floating dashboard: sample values tick, panels parallax with the pointer */
export function initDashboard() {
  $$('[data-dash]').forEach((dash) => {
    const counter = dash.querySelector('[data-live-count]');
    const spark = dash.querySelector('[data-spark]');
    const bars = $$('[data-bar]', dash);
    const donut = dash.querySelector('[data-donut]');
    let count = parseInt(counter?.dataset.liveCount || '0', 10), series = Array.from({ length: 20 }, (_, i) => 40 + 18 * Math.sin(i / 2.2) + Math.random() * 10);
    function tick() {
      if (counter) { const from = count; count += 3 + Math.round(Math.random() * 9); animate(from, count, { duration: 0.8, onUpdate: (v) => { counter.textContent = Math.round(v).toLocaleString('en-IN'); } }); }
      if (spark) { series.shift(); series.push(Math.max(12, Math.min(88, series[series.length - 1] + (Math.random() - 0.45) * 16))); const w = 300, h = 90; const d = series.map((v, i) => `${i ? 'L' : 'M'}${(i / (series.length - 1) * w).toFixed(1)} ${(h - v / 100 * h).toFixed(1)}`).join(' '); spark.querySelector('.ln').setAttribute('d', d); spark.querySelector('.ar').setAttribute('d', `${d} L${w} ${h} L0 ${h}Z`); }
      bars.forEach((b) => { b.style.setProperty('--h', `${25 + Math.random() * 70}%`); });
      if (donut) { const a = 40 + Math.random() * 12, b = 28 + Math.random() * 10; donut.style.setProperty('--a', a); donut.style.setProperty('--b', a + b); }
    }
    if (!reduce) { tick(); let timer = 0; inView(dash, () => { timer = setInterval(tick, 1800); return () => clearInterval(timer); }); }
    if (fine && !reduce) {
      const layers = $$('[data-z]', dash);
      dash.addEventListener('pointermove', (e) => { const r = dash.getBoundingClientRect(); const x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5; layers.forEach((l) => { const z = parseFloat(l.dataset.z); l.style.transform = `translate3d(${(x * z * 30).toFixed(1)}px, ${(y * z * 22).toFixed(1)}px, 0) rotateY(${(x * 6).toFixed(2)}deg) rotateX(${(-y * 6).toFixed(2)}deg)`; }); });
      dash.addEventListener('pointerleave', () => layers.forEach((l) => { l.style.transform = ''; }));
    }
  });
}

/* Animated heading underline accent and section labels as they arrive */
export function initHeadings() {
  if (reduce) return;
  $$('.head .h2, .d-hero .d-title').forEach((h) => {
    inView(h, () => { animate(h, { opacity: [0, 1], transform: ['translateY(24px)', 'translateY(0)'], filter: ['blur(6px)', 'blur(0px)'] }, { duration: 0.9, ease: EASE }); }, { amount: 0.5 });
  });
}

/* Cursor-following glare on 3D tilt cards */
export function initGlare() {
  if (!fine || reduce) return;
  $$('.svc3d, .tech-card, .bento-card, .hub-card, .related-card, .ind-card').forEach((el) => {
    el.addEventListener('pointermove', (e) => { const r = el.getBoundingClientRect(); el.style.setProperty('--gx', `${((e.clientX - r.left) / r.width * 100).toFixed(1)}%`); el.style.setProperty('--gy', `${((e.clientY - r.top) / r.height * 100).toFixed(1)}%`); });
  });
}

/* Ecosystem workflow: interactive tabs that advance on their own while visible */
export function initEcosystem() {
  $$('[data-eco]').forEach((root) => {
    const tabs = $$('.eco-step', root), panels = $$('.eco-panel', root), line = root.querySelector('.eco-line span');
    if (!tabs.length) return;
    let idx = 0, timer = 0, inview = false, paused = false;
    function select(i, focus) {
      idx = (i + tabs.length) % tabs.length;
      tabs.forEach((t, k) => { const on = k === idx; t.setAttribute('aria-selected', on); t.tabIndex = on ? 0 : -1; t.classList.toggle('done', k < idx); });
      panels.forEach((p, k) => { p.hidden = k !== idx; });
      if (line) line.style.setProperty('--p', `${(idx / (tabs.length - 1)) * 100}%`);
      if (focus) tabs[idx].focus();
      const sc = root.querySelector('.eco-steps'); if (sc && sc.scrollWidth > sc.clientWidth) { const t = tabs[idx]; sc.scrollTo({ left: t.offsetLeft - sc.clientWidth / 2 + t.offsetWidth / 2, behavior: reduce ? 'auto' : 'smooth' }); }
    }
    function schedule() { clearInterval(timer); if (inview && !paused && !reduce) timer = setInterval(() => select(idx + 1), 4200); }
    tabs.forEach((t, k) => {
      t.addEventListener('click', () => { select(k); paused = true; schedule(); });
      t.addEventListener('keydown', (e) => { const d = { ArrowRight: 1, ArrowLeft: -1 }[e.key]; if (d) { e.preventDefault(); select(idx + d, true); paused = true; schedule(); } else if (e.key === 'Home') { e.preventDefault(); select(0, true); } else if (e.key === 'End') { e.preventDefault(); select(tabs.length - 1, true); } });
    });
    root.addEventListener('pointerenter', () => { paused = true; schedule(); });
    root.addEventListener('pointerleave', () => { paused = false; schedule(); });
    root.addEventListener('focusin', () => { paused = true; schedule(); });
    new IntersectionObserver(([e]) => { inview = e.isIntersecting; schedule(); }, { threshold: 0.35 }).observe(root);
    select(0);
  });
}

/* Device mockups drift with the pointer at different depths */
export function initDeviceStage() {
  if (!fine || reduce) return;
  $$('[data-pia]').forEach((stage) => {
    const devs = $$('[data-z]', stage);
    const host = stage.closest('section') || stage;
    host.addEventListener('pointermove', (e) => { const r = host.getBoundingClientRect(); const x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5; devs.forEach((d) => { const z = parseFloat(d.dataset.z); d.style.transform = `translate3d(${(x * z * 26).toFixed(1)}px, ${(y * z * 18).toFixed(1)}px, 0) rotateY(${(x * 5).toFixed(2)}deg) rotateX(${(-y * 4).toFixed(2)}deg)`; }); });
    host.addEventListener('pointerleave', () => devs.forEach((d) => { d.style.transform = ''; }));
  });
}

/* Achievement bars fill when the counters come into view */
export function initAchievements() {
  $$('.ach-grid').forEach((g) => inView(g, () => { g.classList.add('in-view'); }, { amount: 0.4 }));
}
